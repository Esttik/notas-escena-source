// Public static resources only. No pages, API, notes, authentication or responses.
const CACHE='notas-public-v1';
const PUBLIC=['/offline.html','/offline.css','/manifest.json','/icons/icon-192.png','/icons/icon-512.png','/icons/apple-touch-icon.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(PUBLIC))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('notas-public-')&&k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);if(u.origin!==self.location.origin||e.request.method!=='GET')return;
 if(PUBLIC.includes(u.pathname))e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
 else if(e.request.mode==='navigate')e.respondWith(fetch(e.request).catch(()=>caches.match('/offline.html')));
});
