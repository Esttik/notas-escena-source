import { test } from "node:test";
import assert from "node:assert/strict";
import { HttpProvider, participants } from "../lib/server/providers.ts";
const config = {
  PROVIDER_MODE: "real",
  PROVIDER_API_URL: "https://authorized.example/lookup",
  PROVIDER_API_TOKEN: "test-only-secret",
  PROVIDER_AUTHORIZED: "true",
};
const input = {
  requestId: "r",
  phone: "+34600000001",
  sessionId: "s",
  signal: new AbortController().signal,
};
test("adaptador real exige HTTPS, token y permiso sin fallback a demo", () => {
  for (const c of [
    { ...config, PROVIDER_API_TOKEN: "" },
    { ...config, PROVIDER_AUTHORIZED: "false" },
    { ...config, PROVIDER_API_URL: "http://insecure.example" },
  ])
    assert.throws(() => new HttpProvider(c));
});
test("solo autorizaciones vigentes del titular y para el artista/proveedor correctos", () => {
  const grant = {
    id: "participant-a",
    label: "Registro autorizado",
    phone: "+34600000001",
    artistId: "artist",
    consentRef: "verified-reference",
    ownershipVerifiedAt: "2026-01-01",
    expiresAt: "2099-01-01",
    scope: "lookup",
    provider: config.PROVIDER_API_URL,
  };
  for (const patch of [
    { artistId: "other" },
    { expiresAt: "2020-01-01" },
    { ownershipVerifiedAt: undefined },
    { consentRef: "" },
    { provider: "https://other.example" },
    { scope: "unrelated" },
  ])
    assert.equal(
      participants(
        {
          ...config,
          AUTHORIZED_PARTICIPANTS_JSON: JSON.stringify([
            { ...grant, ...patch },
          ]),
        },
        "artist",
      ).length,
      0,
    );
  assert.equal(
    participants(
      { ...config, AUTHORIZED_PARTICIPANTS_JSON: JSON.stringify([grant]) },
      "artist",
    ).length,
    1,
  );
});
test("API correlaciona, rechaza parcial/malicioso estructural, limita respuesta y no reintenta", async () => {
  const original = globalThis.fetch;
  let calls = 0;
  let response: unknown = {
    requestId: "r",
    phone: input.phone,
    final: true,
    name: "<img src=x onerror=alert(1)>",
  };
  globalThis.fetch = async (_url, options) => {
    calls++;
    assert.equal(
      (options?.headers as Record<string, string>)["Idempotency-Key"],
      "r",
    );
    return Response.json(response);
  };
  try {
    const provider = new HttpProvider(config);
    assert.equal(
      (await provider.lookup(input)).name,
      "<img src=x onerror=alert(1)>",
    );
    response = {
      requestId: "other",
      phone: input.phone,
      final: true,
      name: "x",
    };
    await assert.rejects(provider.lookup(input), /no corresponde/);
    response = { requestId: "r", phone: input.phone, final: false };
    await assert.rejects(provider.lookup(input), /parcial/);
    response = {
      requestId: "r",
      phone: input.phone,
      final: true,
      name: "x".repeat(10000),
    };
    await assert.rejects(provider.lookup(input), /excesiva/);
    assert.equal(calls, 4);
  } finally {
    globalThis.fetch = original;
  }
});
test("429 del proveedor no reintenta", async () => {
  const original = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => {
    calls++;
    return new Response("", { status: 429 });
  };
  try {
    await assert.rejects(
      new HttpProvider(config).lookup(input),
      /limita las consultas/,
    );
    assert.equal(calls, 1);
  } finally {
    globalThis.fetch = original;
  }
});
test("fallo HTTPS expone solo categoría fija y no reintenta ni filtra datos", async () => {
  const original = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => {
    calls++;
    throw new Error(
      "DNS lookup failed: test-only-secret +34600000001 private name",
    );
  };
  try {
    await assert.rejects(
      new HttpProvider(config).lookup(input),
      (error: unknown) => {
        const safe = JSON.stringify(error);
        assert.ok(safe.includes("PROVIDER_NETWORK_DNS"));
        for (const privateValue of [
          "test-only-secret",
          "+34600000001",
          "private name",
        ])
          assert.equal(safe.includes(privateValue), false);
        return true;
      },
    );
    assert.equal(calls, 1);
  } finally {
    globalThis.fetch = original;
  }
});
test("redirección del proveedor no sigue destino ni revela consulta de Location", async () => {
  const original = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async (_url, options) => {
    calls++;
    assert.equal(options?.redirect, "manual");
    return new Response(null, {
      status: 307,
      headers: { Location: "https://other.example/login?token=private-token" },
    });
  };
  try {
    await assert.rejects(
      new HttpProvider(config).lookup(input),
      (error: unknown) => {
        assert.ok(
          error instanceof Error && error.message.includes("other.example"),
        );
        assert.equal(JSON.stringify(error).includes("private-token"), false);
        return true;
      },
    );
    assert.equal(calls, 1);
  } finally {
    globalThis.fetch = original;
  }
});
