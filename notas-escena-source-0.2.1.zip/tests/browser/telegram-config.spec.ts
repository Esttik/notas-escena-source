import { test, expect } from "playwright/test";
// These UI cases deliberately mock configuration. PWA caching is exercised by flow.spec.ts.
test.use({ serviceWorkers: "block" });
test("área del artista: comprobación Telegram no consulta números y configuración incompleta queda bloqueada", async ({
  page,
}) => {
  let configured = true,
    checks = 0,
    queries = 0;
  await page.route("**/api/config", (route) =>
    route.fulfill({
      json: {
        mode: "real",
        transport: "telegram",
        artist: "Artista ficticio",
        artistId: "fictional-artist",
        participants: [],
        realConfigured: configured,
      },
    }),
  );
  await page.route("**/api/provider-check", (route) => {
    checks++;
    return route.fulfill({
      json: {
        transport: "telegram",
        authenticated: true,
        targetVerified: true,
        webhookAbsent: true,
        communication: "not_verified",
      },
    });
  });
  page.on("request", (request) => {
    if (request.url().endsWith("/api/query")) queries++;
  });
  const loaded = page.waitForResponse((response) =>
    response.url().endsWith("/api/config"),
  );
  await page.goto("/signin-with-chatgpt?return_to=/");
  await loaded;
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Menú y área del artista" }).click();
  await expect(
    page.getByText("Telegram · bot propio", { exact: true }),
  ).toBeVisible();
  const check = page.getByRole("button", {
    name: "Comprobar conexión del bot",
  });
  await check.click();
  await expect(page.getByRole("status")).toContainText("todavía pendientes");
  expect(checks).toBe(1);
  expect(queries).toBe(0);
  await expect(
    page.getByRole("button", { name: "Preparar sesión", exact: true }),
  ).toBeDisabled();
  // Actual local server stays in demo and rejects a Telegram check instead of contacting any provider.
  expect((await page.request.get("/api/provider-check")).status()).toBe(409);
  configured = false;
  const reloaded = page.waitForResponse((response) =>
    response.url().endsWith("/api/config"),
  );
  await page.reload();
  await reloaded;
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Menú y área del artista" }).click();
  await expect(check).toBeDisabled();
  expect(queries).toBe(0);
});
