import { test, expect } from "playwright/test";
test.use({ serviceWorkers: "block" });
test("detección estable, autorización, respuesta reservada y descarte por revisión", async ({
  page,
}) => {
  let requests = 0;
  page.on("request", (r) => {
    if (r.url().endsWith("/api/query")) requests++;
  });
  await page.goto("/signin-with-chatgpt?return_to=/");
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  const text = page.getByRole("textbox", { name: "Texto de la nota" });
  await text.fill("600000001");
  await page.waitForTimeout(1000);
  expect(requests).toBe(0); // no artist session
  await page.locator(".link-tool").tap();
  await expect(
    page.getByRole("heading", { name: "Área del artista", exact: true }),
  ).toBeVisible();
  await expect(page.getByRole("checkbox")).toHaveCount(2);
  for (const participant of await page.getByRole("checkbox").all())
    await participant.check();
  await page
    .getByRole("button", { name: "Preparar sesión", exact: true })
    .click();
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  for (const value of ["60000000", "611111111", "600000001 700000002"]) {
    await text.fill(value);
    await page.waitForTimeout(950);
  }
  expect(requests).toBe(0);
  await text.fill("600000001");
  await page.waitForTimeout(300);
  await text.fill("6000000012"); // edits before the stable timer cancel transmission
  await page.waitForTimeout(1000);
  expect(requests).toBe(0);
  await text.fill("+34 600 000 001");
  const link = page.locator(".link-tool");
  await expect(link).toHaveAttribute("aria-label", "Eslabones: recibido");
  await expect(text).toHaveText("+34 600 000 001");
  expect(requests).toBe(1);
  // Safari may commit a duplicate input event when the keyboard focus changes.
  await text.dispatchEvent("input", { bubbles: true });
  await expect(link).toHaveAttribute("aria-label", "Eslabones: recibido");
  await text.press("ControlOrMeta+End");
  await page.keyboard.insertText("\nEnsayo"); // same phone, different revision: discard, no automatic retry
  await page.waitForTimeout(1100);
  expect(requests).toBe(1);
  await expect(link).toHaveAttribute("aria-label", "Eslabones: preparado");
  const originalText = await text.innerText();
  await link.tap(); // explicit query starts, release must prevent late revelation
  await expect(link).toHaveAttribute("aria-label", "Eslabones: recibido");
  await expect(page.locator(".peek-result")).toHaveCount(0);
  expect(await text.innerText()).toBe(originalText);
  expect(requests).toBe(2);
  const position = await link.boundingBox();
  await page.mouse.move(
    position!.x + position!.width / 2,
    position!.y + position!.height / 2,
  );
  await page.mouse.down();
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Alba Ejemplo",
  );
  expect(await text.innerText()).toBe(originalText);
  expect(await text.evaluate((el) => el === document.activeElement)).toBe(true);
  await page.mouse.move(2, 2); // release outside the control is still captured
  await page.mouse.up();
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await link.dispatchEvent("pointerdown", {
    pointerId: 2,
    isPrimary: true,
    pointerType: "touch",
    button: 0,
  });
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Alba Ejemplo",
  );
  await link.dispatchEvent("pointercancel", {
    pointerId: 2,
    pointerType: "touch",
  });
  await expect(page.locator(".peek-result")).toHaveCount(0);
  expect(requests).toBe(2);
  await text.fill("700000002");
  await expect(link).toHaveAttribute("aria-label", "Eslabones: consultando");
  const box = await link.boundingBox();
  await page.mouse.move(box!.x + box!.width / 2, box!.y + box!.height / 2);
  await page.mouse.down();
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Leo Ensayo",
  );
  await expect(text).toHaveText("700000002");
  await page.mouse.up();
  await expect(page.locator(".peek-result")).toHaveCount(0);
  expect(requests).toBe(3);
  // Keyboard activation follows the same hold/release contract.
  await link.focus();
  await page.keyboard.down("Space");
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Leo Ensayo",
  );
  await page.keyboard.up("Space");
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.keyboard.down("Space");
  await expect(page.locator(".peek-result")).toBeVisible();
  await page.evaluate(() => window.dispatchEvent(new Event("blur")));
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.keyboard.up("Space");
  expect(requests).toBe(3);
});
