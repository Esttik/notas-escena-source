import { test, expect } from "playwright/test";
test("notas y actuación completa, duplicados, contexto, seguridad, deshacer y fallos", async ({
  page,
  playwright,
}, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (
      m.type() === "error" &&
      !m.text().includes("Failed to load resource") &&
      !m.text().includes("Fetch API cannot load")
    )
      errors.push(m.text());
  });
  const response = await page.goto("/signin-with-chatgpt?return_to=/");
  expect(response?.headers()["content-security-policy"]).toContain("nonce-");
  expect(
    response?.headers()["content-security-policy"].split("style-src")[0],
  ).not.toContain("unsafe-inline");
  const denied = await page.request.post("/api/session", {
    headers: { Origin: "https://untrusted.example" },
    data: { participantIds: ["demo-alba"] },
  });
  expect(denied.status()).toBe(403);
  const anonymous = await playwright.request.newContext({
    baseURL: process.env.TEST_BASE_URL ?? "http://127.0.0.1:5176",
  });
  expect((await anonymous.get("/api/config")).status()).toBe(401);
  await anonymous.dispose();
  await expect(
    page.getByRole("heading", { name: "Notas", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
  await page.screenshot({
    path: `test-results/${testInfo.project.name}-list.png`,
    fullPage: false,
    scale: "css",
  });
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  const writing = page.getByRole("textbox", { name: "Texto de la nota" });
  await writing.fill("Nota de ensayo\nUn recordatorio ficticio");
  await writing.press("ControlOrMeta+End");
  await page.keyboard.insertText(" · añadido");
  await expect(writing).toContainText("añadido");
  await page.getByRole("button", { name: "Deshacer", exact: true }).click();
  await expect(writing).toHaveText("Nota de ensayo\nUn recordatorio ficticio", {
    useInnerText: true,
  });
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page.getByRole("button", { name: "Fijar nota", exact: true }).click();
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  const search = page.getByRole("searchbox", { name: "Buscar notas" });
  await search.fill("ensayo");
  await expect(page.locator(".note-row")).toHaveCount(1);
  await page.locator(".note-row").click();
  await expect(writing).toContainText("recordatorio ficticio");
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page
    .getByRole("button", { name: "Eliminar nota", exact: true })
    .click();
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Menú y área del artista" }).click();
  await expect(
    page.getByText("Demostración · datos ficticios", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Preparar sesión", exact: true })
    .click();
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await writing.fill("600 000-001");
  let requests = 0;
  page.on("request", (r) => {
    if (r.url().endsWith("/api/query")) requests++;
  });
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-label",
    "Eslabones: recibido",
  );
  await expect(writing).toHaveText("600 000-001");
  expect(requests).toBe(1);
  const firstBox = await page.locator(".link-tool").boundingBox();
  await page.mouse.move(
    firstBox!.x + firstBox!.width / 2,
    firstBox!.y + firstBox!.height / 2,
  );
  await page.mouse.down();
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Alba Ejemplo",
  );
  await expect(writing).toHaveText("600 000-001");
  expect(requests).toBe(1);
  expect(await writing.evaluate((el) => el === document.activeElement)).toBe(
    true,
  );
  expect(
    await page.evaluate(() => localStorage.getItem("notas-escena.ordinary.v1")),
  ).not.toContain("Alba Ejemplo");
  await page.screenshot({
    path: `test-results/${testInfo.project.name}-editor.png`,
    fullPage: false,
    scale: "css",
  });
  await page.mouse.up();
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.getByRole("button", { name: "Deshacer", exact: true }).click();
  await expect(writing).toHaveText("600 000-001");
  await page.locator(".link-tool").click();
  await expect(page.locator(".link-tool")).toHaveAttribute("aria-busy", "true");
  await writing.fill("700000002");
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-label",
    "Eslabones: recibido",
  );
  await expect(writing).toHaveText("700000002");
  expect(requests).toBe(3);
  const secondBox = await page.locator(".link-tool").boundingBox();
  await page.mouse.move(
    secondBox!.x + secondBox!.width / 2,
    secondBox!.y + secondBox!.height / 2,
  );
  await page.mouse.down();
  await expect(page.locator(".peek-result")).toContainText(
    "Nombre: Leo Ensayo",
  );
  await expect(writing).toHaveText("700000002");
  await page.mouse.up();
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.getByRole("button", { name: "Deshacer", exact: true }).click();
  await page.locator(".link-tool").click();
  await expect(page.locator(".link-tool")).toHaveAttribute("aria-busy", "true");
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await writing.fill("Una nota diferente");
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-busy",
    "false",
  );
  await expect(writing).toHaveText("Una nota diferente");
  await writing.fill("611111111");
  await page.locator(".link-tool").click();
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-label",
    "Eslabones: error",
  );
  await expect(writing).toHaveText("611111111");
  await page.route("**/api/query", (route) => route.abort());
  await writing.fill("600000001");
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-label",
    "Eslabones: error",
  );
  await page.unroute("**/api/query");
  await page.route("**/api/query", async (route) => {
    const b = route.request().postDataJSON();
    await route.fulfill({
      json: {
        ...b,
        phone: "+34600000001",
        status: "completado",
        providerMs: 1,
        result: {
          requestId: b.requestId,
          phone: "+34600000001",
          final: true,
          found: true,
          name: "<script>window.COMPROMISED=true</script>",
        },
      },
    });
  });
  await page.locator(".link-tool").click();
  await expect(page.locator(".link-tool")).toHaveAttribute(
    "aria-label",
    "Eslabones: recibido",
  );
  const maliciousBox = await page.locator(".link-tool").boundingBox();
  await page.mouse.move(
    maliciousBox!.x + maliciousBox!.width / 2,
    maliciousBox!.y + maliciousBox!.height / 2,
  );
  await page.mouse.down();
  await expect(page.locator(".peek-result")).toContainText(
    "<script>window.COMPROMISED=true</script>",
  );
  await expect(writing).toHaveText("600000001");
  expect(
    (await page.locator(".peek-result").innerText()).match(/Nombre:/g),
  ).toHaveLength(1);
  expect(await page.evaluate(() => "COMPROMISED" in window)).toBe(false);
  expect(await page.locator(".peek-result script").count()).toBe(0);
  await page.mouse.up();
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.unroute("**/api/query");
  await page.getByRole("button", { name: "Deshacer", exact: true }).click();
  await expect(writing).toHaveText("600000001");
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page
    .getByRole("button", { name: "Área del artista", exact: true })
    .click();
  await expect(page.locator(".diagnostics")).toContainText(
    "Resultado retirado",
  );
  await page
    .getByRole("button", { name: "Borrar sesión y resultados" })
    .click();
  await page.getByRole("button", { name: "Volver a Notas" }).click();
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
  const cached = await page.evaluate(async () => {
    const urls: string[] = [];
    for (const name of await caches.keys()) {
      if (name.startsWith("notas-public-"))
        for (const req of await (await caches.open(name)).keys())
          urls.push(new URL(req.url).pathname);
    }
    return urls;
  });
  expect(cached.length).toBeGreaterThan(0);
  expect(
    cached.every(
      (path) =>
        path.startsWith("/icons/") ||
        ["/offline.html", "/offline.css", "/manifest.json"].includes(path),
    ),
  ).toBe(true);
  expect(errors).toEqual([]);
});
