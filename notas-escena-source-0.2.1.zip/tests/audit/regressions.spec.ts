import { test, expect } from "playwright/test";
import { prepare } from "./fixtures";
test.beforeEach(async ({ page }) => {
  await prepare(page);
});
test("N01: nota vacía se descarta al volver", async ({ page }) => {
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await expect(page.getByText("8 notas", { exact: true })).toBeVisible();
});
test("N02: recarga inmediata conserva el último texto escrito", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await page
    .getByRole("textbox", { name: "Texto de la nota" })
    .fill("Borrador inmediato ficticio");
  page.on("dialog", (d) => d.accept());
  await page.reload();
  await expect(
    page.getByRole("button", { name: /Borrador inmediato ficticio/ }),
  ).toBeVisible();
});
test("N03: búsqueda se conserva al abrir y volver", async ({ page }) => {
  await page.getByRole("searchbox").fill("Ensayo 6");
  await page.locator(".note-row").click();
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await expect(page.getByRole("searchbox")).toHaveValue("Ensayo 6");
  await expect(page.locator(".note-row")).toHaveCount(1);
});
test("N04: Escape cierra las opciones sin cambiar la nota", async ({
  page,
}) => {
  await page.locator(".note-row").first().click();
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await expect(page.locator(".note-menu")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.locator(".note-menu")).toHaveCount(0);
  await expect(
    page.getByRole("textbox", { name: "Texto de la nota" }),
  ).toContainText("Ensayo 1");
});
test("N05: eliminar se puede recuperar desde Eliminadas", async ({ page }) => {
  await page.locator(".note-row").first().click();
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page
    .getByRole("button", { name: "Eliminar nota", exact: true })
    .click();
  await page.getByRole("button", { name: "Carpetas", exact: true }).click();
  await page.getByRole("button", { name: /Eliminadas recientemente/ }).click();
  await expect(page.getByText("Ensayo 1", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: /Recuperar Ensayo 1/ }).click();
  await page.getByRole("button", { name: "Volver a Carpetas" }).click();
  await page.getByRole("button", { name: /^Notas/ }).click();
  await expect(page.locator(".note-row")).toHaveCount(8);
});
