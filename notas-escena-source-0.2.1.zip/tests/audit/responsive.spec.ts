import { test, expect } from "playwright/test";
import { prepare } from "./fixtures";
test("N06: texto al 200% conserva líneas sin recorte vertical", async ({
  page,
}) => {
  await prepare(page);
  await page.addStyleTag({ content: ":root{font-size:32px !important}" });
  const title = page.locator(".row-title").first();
  const metrics = await title.evaluate((el) => ({
    height: el.getBoundingClientRect().height,
    font: parseFloat(getComputedStyle(el).fontSize),
  }));
  expect(metrics.height).toBeGreaterThanOrEqual(metrics.font);
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth),
  ).toBeLessThanOrEqual(page.viewportSize()!.width);
});
test("N07: buscador permanece dentro de VisualViewport al abrir teclado simulado", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("searchbox").click();
  await page.evaluate(() => {
    Object.defineProperty(visualViewport, "height", {
      configurable: true,
      get: () => 300,
    });
    visualViewport?.dispatchEvent(new Event("resize"));
  });
  await expect
    .poll(() =>
      page
        .locator(".search-pill")
        .evaluate((el) => el.getBoundingClientRect().bottom),
    )
    .toBeLessThanOrEqual(300);
});

test("N08: atrás del navegador vuelve al listado conservando la nota", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await page
    .getByRole("textbox", { name: "Texto de la nota" })
    .fill("Regreso ficticio");
  await page.goBack();
  await expect(
    page.getByRole("heading", { name: "Notas", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: /Regreso ficticio/ }),
  ).toBeVisible();
});
