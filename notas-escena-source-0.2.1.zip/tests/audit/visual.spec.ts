import { test, expect } from "playwright/test";
import { fixtures, prepare } from "./fixtures";
test("V01: proporciones, controles y capturas comparables con Notas", async ({
  page,
}, info) => {
  const notes = fixtures(10);
  notes[3].pinned = true;
  await prepare(page, notes);
  const geometry = await page
    .locator(".note-card")
    .first()
    .evaluate((el) => ({
      radius: getComputedStyle(el).borderTopLeftRadius,
      x: el.getBoundingClientRect().x,
    }));
  if (info.project.name.endsWith("390")) {
    expect(geometry.radius).toBe("26px");
    expect(geometry.x).toBe(20);
  }
  await page.screenshot({
    path: info.outputPath("listado.png"),
    fullPage: false,
    scale: "css",
  });
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await page
    .getByRole("textbox", { name: "Texto de la nota" })
    .fill("600000001");
  const labels = [
    "Volver a las notas",
    "Deshacer",
    "Compartir nota",
    "Opciones de nota",
    "Finalizar escritura",
  ];
  for (const name of labels) {
    const b = (await page
      .getByRole("button", { name, exact: true })
      .boundingBox())!;
    expect(b.width).toBeGreaterThanOrEqual(44);
    expect(b.height).toBeGreaterThanOrEqual(44);
  }
  const pencil = await page
    .getByRole("button", { name: "Opciones de escritura" })
    .boundingBox();
  const link = await page.locator(".link-tool").boundingBox();
  expect(link!.x).toBeGreaterThan(pencil!.x);
  await page.screenshot({
    path: info.outputPath("editor.png"),
    fullPage: false,
    scale: "css",
  });
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page.screenshot({
    path: info.outputPath("opciones.png"),
    fullPage: false,
    scale: "css",
  });
});
