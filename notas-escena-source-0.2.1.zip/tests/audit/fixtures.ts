import type { Page } from "playwright/test";
export const key = "notas-escena.ordinary.v1";
export function fixtures(count = 8, length = 80) {
  return Array.from({ length: count }, (_, i) => ({
    id: `00000000-0000-4000-8000-${String(i + 1).padStart(12, "0")}`,
    text: `Ensayo ${i + 1}\n${"Un recuerdo imaginario. ".repeat(Math.ceil(length / 24)).slice(0, length)}`,
    pinned: i < 3,
    updated: Date.now() - (i < 3 ? i : i < 5 ? 1 : i < 7 ? 4 : 15) * 86400000,
  }));
}
export async function prepare(page: Page, notes = fixtures()) {
  const origin = new URL(process.env.AUDIT_BASE_URL ?? "http://127.0.0.1:5178");
  if (!["127.0.0.1", "localhost"].includes(origin.hostname))
    throw Error("Audit fixtures require loopback");
  await page.addInitScript(
    ({ key, notes }) => {
      if (!sessionStorage.getItem("audit-fixture-initialized")) {
        localStorage.setItem(key, JSON.stringify(notes));
        sessionStorage.setItem("audit-fixture-initialized", "yes");
      }
    },
    { key, notes },
  );
  await page.goto("/");
  await page.getByRole("heading", { name: "Notas", exact: true }).waitFor();
}
