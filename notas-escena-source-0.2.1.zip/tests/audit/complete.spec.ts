import { test, expect } from "playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { prepare, fixtures, key } from "./fixtures";

test("U01: listado, editor, opciones, artista y carpetas sin infracciones automáticas WCAG A/AA", async ({
  page,
}) => {
  await prepare(page);
  const check = async () => {
    const result = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      result.violations.map((v) => ({
        id: v.id,
        nodes: v.nodes.map((n) => n.target),
      })),
    ).toEqual([]);
  };
  await check();
  await page.locator(".note-row").first().click();
  await check();
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await check();
  await page
    .getByRole("button", { name: "Área del artista", exact: true })
    .click();
  await check();
  await page.getByRole("button", { name: "Volver" }).click();
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await page.getByRole("button", { name: "Carpetas", exact: true }).click();
  await check();
  await page.getByRole("button", { name: /Eliminadas recientemente/ }).click();
  await check();
});
test("U02: deslizar fija y elimina sin abrir la nota; recuperar y cancelación de borrado definitivo", async ({
  page,
}) => {
  await prepare(page);
  const row = page.locator(".note-row").filter({ hasText: "Ensayo 6" });
  const box = (await row.boundingBox())!;
  await row.dispatchEvent("pointerdown", {
    pointerId: 1,
    pointerType: "touch",
    clientX: box.x + 20,
    clientY: box.y + 20,
  });
  await row.dispatchEvent("pointermove", {
    pointerId: 1,
    pointerType: "touch",
    clientX: box.x + 90,
    clientY: box.y + 20,
  });
  await row.dispatchEvent("pointerup", { pointerId: 1, pointerType: "touch" });
  await page
    .getByRole("button", { name: "Fijar Ensayo 6", exact: true })
    .click();
  await expect(page.locator(".note-section").first()).toContainText("Ensayo 6");
  await row.focus();
  await page.keyboard.press("Delete");
  await page
    .getByRole("button", { name: "Eliminar Ensayo 6", exact: true })
    .click();
  await expect(page.locator(".note-row")).toHaveCount(7);
  await page.getByRole("button", { name: "Carpetas", exact: true }).click();
  await page.getByRole("button", { name: /Eliminadas recientemente/ }).click();
  await page
    .getByRole("button", {
      name: "Eliminar definitivamente Ensayo 6",
      exact: true,
    })
    .click();
  await page.getByRole("button", { name: "Cancelar", exact: true }).click();
  await expect(page.getByText("Ensayo 6", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Recuperar Ensayo 6", exact: true })
    .click();
  await expect(page.getByText("No hay notas eliminadas.")).toBeVisible();
});
test("U03: escritura multilínea, selección, deshacer/rehacer y guardado exacto", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  const area = page.getByRole("textbox", { name: "Texto de la nota" });
  await area.fill("Título imaginario\nSegunda línea");
  await area.press("ControlOrMeta+End");
  await page.keyboard.insertText(" final");
  await area.press("ControlOrMeta+z");
  await expect(area).toHaveText("Título imaginario\nSegunda línea", {
    useInnerText: true,
  });
  await area.press("ControlOrMeta+Shift+z");
  await expect(area).toHaveText("Título imaginario\nSegunda línea final", {
    useInnerText: true,
  });
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await page.reload();
  await page.getByRole("button", { name: /Título imaginario/ }).click();
  await expect(area).toHaveText("Título imaginario\nSegunda línea final", {
    useInnerText: true,
  });
});
test("U04: búsquedas, plegado y desplazamiento se conservan; menú se cierra al tocar fuera", async ({
  page,
}) => {
  await prepare(page, fixtures(40));
  await page.getByRole("button", { name: "Ocultar fijadas" }).click();
  await expect(page.locator(".note-row")).toHaveCount(37);
  await page.locator(".note-row").last().scrollIntoViewIfNeeded();
  const before = await page.evaluate(() => scrollY);
  await page.locator(".note-row").last().click();
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await page.getByRole("textbox", { name: "Texto de la nota" }).click();
  await expect(page.locator(".note-menu")).toHaveCount(0);
  await page.getByRole("button", { name: "Volver a las notas" }).click();
  await expect(page.locator(".note-row")).toHaveCount(37);
  await expect
    .poll(() => page.evaluate(() => scrollY))
    .toBeGreaterThan(before - 10);
});
test("U05: fechas extremas, duplicados y HTML no rompen el listado ni ejecutan contenido", async ({
  page,
}) => {
  const notes = fixtures();
  notes[0].text =
    "<script>window.compromised=true</script>\n<img src=x onerror=alert(1)>";
  await prepare(page, [
    ...notes,
    { ...notes[1] },
    { ...notes[2], id: "bad", updated: 1e100 },
  ]);
  await expect(page.locator(".note-row")).toHaveCount(8);
  expect(await page.evaluate(() => "compromised" in window)).toBe(false);
  await page.locator(".note-row").filter({ hasText: "<script>" }).click();
  await expect(page.getByRole("textbox")).toContainText("<script>");
  await expect(
    page.locator(".writing-area script,.writing-area img"),
  ).toHaveCount(0);
});
test("U06: límites, errores de almacenamiento y móvil sin conexión se explican", async ({
  page,
}) => {
  await prepare(page, fixtures(200));
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await expect(page.getByRole("alert")).toContainText("Límite de 200");
  await page.getByRole("button", { name: "Cerrar aviso" }).click();
  await page.locator(".note-row").first().click();
  await page.evaluate(() => {
    Storage.prototype.setItem = function () {
      throw new DOMException("Audit quota", "QuotaExceededError");
    };
  });
  await page
    .getByRole("textbox", { name: "Texto de la nota" })
    .fill("Una edición ficticia");
  await expect(page.getByRole("alert")).toContainText("No se pudieron guardar");
  await page.context().setOffline(true);
  await page
    .getByRole("button", { name: /Eslabones:/ })
    .dispatchEvent("pointerdown", { isPrimary: true, button: 0, pointerId: 1 });
  await expect(
    page.getByRole("heading", { name: "Área del artista", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate((k) => localStorage.getItem(k), key),
  ).not.toContain("Una edición ficticia");
});

test("U07: herramientas mantienen el foco, adjunto de texto seguro y cierre del formato", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  const area = page.getByRole("textbox", { name: "Texto de la nota" });
  await area.fill("Título ficticio\n");
  await area.press("ControlOrMeta+End");
  await page.getByRole("button", { name: "Añadir elemento de lista" }).click();
  await expect(area).toContainText("☐ ");
  expect(await area.evaluate((el) => el === document.activeElement)).toBe(true);
  await page.getByRole("button", { name: "Insertar tabla de texto" }).click();
  await expect(area).toContainText("Columna A | Columna B");
  await page.getByRole("button", { name: "Opciones de texto" }).click();
  await expect(page.locator(".format-menu")).toBeVisible();
  await page.getByRole("button", { name: "Opciones de texto" }).click();
  await expect(page.locator(".format-menu")).toHaveCount(0);
  await page.getByRole("button", { name: "Opciones de escritura" }).click();
  await page.getByRole("button", { name: "Añadir viñeta" }).click();
  await expect(area).toContainText("• ");
  await page.locator("input[type=file]").setInputFiles({
    name: "ensayo.txt",
    mimeType: "text/plain",
    buffer: Buffer.from("<img src=x onerror=alert(1)>"),
  });
  await expect(area).toContainText("<img src=x onerror=alert(1)>");
  await expect(page.locator(".writing-area img")).toHaveCount(0);
  await page.locator("input[type=file]").setInputFiles({
    name: "grande.txt",
    mimeType: "text/plain",
    buffer: Buffer.alloc(10001, 120),
  });
  await expect(page.locator(".editor-hint")).toContainText("menos de 10 KB");
});

test("U08: dos pestañas no pisan notas distintas ni una edición simultánea", async ({
  page,
}) => {
  await prepare(page);
  const second = await page.context().newPage();
  await second.goto("/");
  await page.locator(".note-row").filter({ hasText: "Ensayo 1" }).click();
  await second.locator(".note-row").filter({ hasText: "Ensayo 2" }).click();
  await page.getByRole("textbox").fill("Primera pestaña ficticia");
  await second.getByRole("textbox").fill("Segunda pestaña ficticia");
  page.on("dialog", (d) => d.accept());
  await page.reload();
  await expect(
    page.locator(".note-row").filter({ hasText: "Primera pestaña ficticia" }),
  ).toBeVisible();
  await expect(
    page.locator(".note-row").filter({ hasText: "Segunda pestaña ficticia" }),
  ).toBeVisible();
  await page
    .locator(".note-row")
    .filter({ hasText: "Primera pestaña ficticia" })
    .click();
  second.on("dialog", (d) => d.accept());
  await second.reload();
  await second
    .locator(".note-row")
    .filter({ hasText: "Primera pestaña ficticia" })
    .click();
  await page.getByRole("textbox").fill("Cambio concurrente ficticio");
  await second.getByRole("textbox").fill("Borrador en conflicto ficticio");
  await expect(second.getByRole("alert")).toContainText("otra pestaña");
  await page.reload();
  await expect(
    page
      .locator(".note-row")
      .filter({ hasText: "Cambio concurrente ficticio" }),
  ).toBeVisible();
  await expect(
    page
      .locator(".note-row")
      .filter({ hasText: "Borrador en conflicto ficticio" }),
  ).toHaveCount(0);
});
