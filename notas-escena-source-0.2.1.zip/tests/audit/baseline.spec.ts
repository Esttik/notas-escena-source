import { test, expect } from "playwright/test";
import { writeFileSync } from "node:fs";
import { prepare, fixtures } from "./fixtures";
test("B01: métricas y capturas de listado/editor con paquete de producción", async ({
  page,
  browserName,
}, info) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.addInitScript(() => {
    const measurements = { lcp: 0, cls: 0, longTasks: [] as number[] };
    Object.defineProperty(window, "auditMeasurements", { value: measurements });
    for (const kind of [
      "largest-contentful-paint",
      "layout-shift",
      "longtask",
    ]) {
      if (!PerformanceObserver.supportedEntryTypes.includes(kind)) continue;
      new PerformanceObserver((list) => {
        for (const e of list.getEntries()) {
          if (kind === "largest-contentful-paint")
            measurements.lcp = e.startTime;
          else if (kind === "longtask") measurements.longTasks.push(e.duration);
          else if (
            !(e as PerformanceEntry & { hadRecentInput: boolean })
              .hadRecentInput
          )
            measurements.cls += (
              e as PerformanceEntry & { value: number }
            ).value;
        }
      }).observe({ type: kind, buffered: true });
    }
  });
  await prepare(page, fixtures(200, 1000));
  await page.screenshot({
    path: info.outputPath("list.png"),
    fullPage: false,
    scale: "css",
  });
  const layout = await page.evaluate(() => ({
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    controls: [...document.querySelectorAll("button,input")]
      .filter((e) => e.getBoundingClientRect().width > 0)
      .map((e) => ({
        label: e.getAttribute("aria-label"),
        width: e.getBoundingClientRect().width,
        height: e.getBoundingClientRect().height,
      })),
    navigation: performance
      .getEntriesByType("navigation")
      .map((e) => ({
        ttfb: (e as PerformanceNavigationTiming).responseStart,
        duration: e.duration,
      })),
    resources: performance
      .getEntriesByType("resource")
      .map((e) => ({
        type: (e as PerformanceResourceTiming).initiatorType,
        size: (e as PerformanceResourceTiming).decodedBodySize,
        duration: e.duration,
      })),
  }));
  expect(layout.scrollWidth).toBeLessThanOrEqual(layout.width);
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  // At the maximum the control should refuse; use an existing note for typing.
  if (
    await page.getByRole("heading", { name: "Notas", exact: true }).isVisible()
  )
    await page.locator(".note-row").first().click();
  const text = page.getByRole("textbox", { name: "Texto de la nota" });
  await text.press("ControlOrMeta+End");
  let cdp;
  if (browserName === "chromium") {
    cdp = await page.context().newCDPSession(page);
    await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
  }
  const paints: number[] = [];
  for (let i = 0; i < 20; i++) {
    const began = performance.now();
    await page.keyboard.insertText("a");
    await page.evaluate(
      () =>
        new Promise<void>((r) =>
          requestAnimationFrame(() => requestAnimationFrame(() => r())),
        ),
    );
    paints.push(performance.now() - began);
  }
  if (cdp) await cdp.send("Emulation.setCPUThrottlingRate", { rate: 1 });
  await page.screenshot({
    path: info.outputPath("editor.png"),
    fullPage: false,
    scale: "css",
  });
  const observed = await page.evaluate(() => ({
    measurement: (window as typeof window & { auditMeasurements: unknown })
      .auditMeasurements,
    elementCount: document.querySelectorAll("*").length,
    viewport: {
      height: visualViewport?.height,
      offset: visualViewport?.offsetTop,
    },
    storedBytes:
      (localStorage.getItem("notas-escena.ordinary.v1")?.length ?? 0) * 2,
  }));
  writeFileSync(
    info.outputPath("metrics.json"),
    JSON.stringify(
      {
        environment: "loopback production build; synthetic fixtures",
        browserName,
        project: info.project.name,
        cpu:
          browserName === "chromium"
            ? "4x for typing"
            : "no CPU throttle available",
        layout,
        observed,
        typingRoundtripDoubleRafMs: paints,
        errors,
      },
      null,
      2,
    ),
  );
  expect(errors).toEqual([]);
});
