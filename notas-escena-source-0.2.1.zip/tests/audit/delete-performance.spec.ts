import { test, expect, type Page } from "playwright/test";
import { prepare, fixtures } from "./fixtures";

// Each worker uses a disposable artist: session limits stay real and isolated.
test.use({
  extraHTTPHeaders: {
    "oai-authenticated-user-id": `deletion-test-${crypto.randomUUID()}`,
    "oai-authenticated-user-email": "deletion@fiction.invalid",
  },
});

async function activateDelete(page: Page) {
  const button = page.getByRole("button", {
    name: "Eliminar nota",
    exact: true,
  });
  if ((page.viewportSize()?.width ?? 1280) < 1000) await button.tap();
  else await button.click();
}

test("D01: eliminar copia de actuación también retira el original del listado", async ({
  page,
}) => {
  const notes = fixtures();
  notes[3].text = "600000001";
  await prepare(page, notes);
  await page.getByRole("button", { name: "Menú y área del artista" }).click();
  await page
    .getByRole("button", { name: "Preparar sesión", exact: true })
    .click();
  await page.locator(".note-row").filter({ hasText: "600000001" }).click();
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await activateDelete(page);
  await expect(
    page.getByRole("heading", { name: "Notas", exact: true }),
  ).toBeVisible();
  await expect(
    page.locator(".note-row").filter({ hasText: "600000001" }),
  ).toHaveCount(0);
  await page.reload();
  await expect(
    page.locator(".note-row").filter({ hasText: "600000001" }),
  ).toHaveCount(0);
  await page.getByRole("button", { name: "Carpetas", exact: true }).click();
  await page.getByRole("button", { name: /Eliminadas recientemente/ }).click();
  await expect(page.getByText("600000001", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Recuperar 600000001", exact: true })
    .click();
  await page.getByRole("button", { name: "Volver a Carpetas" }).click();
  await page.getByRole("button", { name: /^Notas/ }).click();
  await expect(
    page.locator(".note-row").filter({ hasText: "600000001" }),
  ).toHaveCount(1);
});

test("D02: eliminar se activa por toque aunque Safari no entregue click", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  await page.getByRole("textbox").fill("Borrado de ensayo ficticio");
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  const button = page.getByRole("button", {
    name: "Eliminar nota",
    exact: true,
  });
  await button.dispatchEvent("pointerdown", {
    pointerId: 7,
    isPrimary: true,
    pointerType: "touch",
    button: 0,
    clientX: 100,
    clientY: 200,
  });
  await button.dispatchEvent("pointerup", {
    pointerId: 7,
    isPrimary: true,
    pointerType: "touch",
    button: 0,
    clientX: 100,
    clientY: 200,
  });
  await expect(
    page.getByRole("heading", { name: "Notas", exact: true }),
  ).toBeVisible();
  await expect(
    page.locator(".note-row").filter({ hasText: "Borrado de ensayo ficticio" }),
  ).toHaveCount(0);
});

test("D03: borrado de nota temporal descarta respuesta tardía y no guarda datos en papelera", async ({
  page,
}) => {
  await prepare(page);
  await page.getByRole("button", { name: "Menú y área del artista" }).click();
  await page
    .getByRole("button", { name: "Preparar sesión", exact: true })
    .click();
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route("**/api/query", async (route) => {
    const b = route.request().postDataJSON();
    await gate;
    await route.fulfill({
      json: {
        ...b,
        phone: "+34600000001",
        status: "completado",
        providerMs: 1,
        result: {
          requestId: b.requestId,
          phone: "+34600000001",
          final: true,
          found: true,
          name: "Respuesta ficticia tardía",
        },
      },
    });
  });
  await page.getByRole("button", { name: "Crear nueva nota" }).click();
  const request = page.waitForRequest("**/api/query");
  await page.getByRole("textbox").fill("600000001");
  await request;
  await page.getByRole("button", { name: "Opciones de nota" }).click();
  await activateDelete(page);
  release();
  await expect(
    page.getByRole("heading", { name: "Notas", exact: true }),
  ).toBeVisible();
  await expect(page.locator(".note-row")).toHaveCount(8);
  await expect(page.locator(".peek-result")).toHaveCount(0);
  await page.getByRole("button", { name: "Carpetas", exact: true }).click();
  await page.getByRole("button", { name: /Eliminadas recientemente/ }).click();
  await expect(page.getByText("No hay notas eliminadas.")).toBeVisible();
  expect(
    await page.evaluate(() => localStorage.getItem("notas-escena.ordinary.v1")),
  ).not.toContain("Respuesta ficticia tardía");
});
