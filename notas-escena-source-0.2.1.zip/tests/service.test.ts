import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import { Service } from "../lib/server/service.ts";
import { Store, type Database } from "../lib/server/store.ts";
import { digest, type QueryResult } from "../lib/domain.ts";
import type { Provider, ProviderInput } from "../lib/server/providers.ts";
function fixture(provider?: Provider, timeout = 200) {
  const db = new DatabaseSync(":memory:");
  db.exec(
    readFileSync(
      new URL("../drizzle/0000_bouncy_scalphunter.sql", import.meta.url),
      "utf8",
    ),
  );
  const adapter: Database = {
    prepare(sql) {
      let args: unknown[] = [];
      const stmt = db.prepare(sql);
      return {
        bind(...values: unknown[]) {
          args = values;
          return this;
        },
        async first<T>() {
          return (stmt.get(...(args as (string | number | null)[])) ??
            null) as T | null;
        },
        async all<T>() {
          return {
            results: stmt.all(...(args as (string | number | null)[])) as T[],
          };
        },
        async run() {
          return stmt.run(...(args as (string | number | null)[]));
        },
      };
    },
  };
  return {
    db,
    service: new Service(new Store(adapter), {}, provider, timeout),
  };
}
function deferredProvider() {
  let calls = 0,
    resolve!: (value: QueryResult) => void;
  let input!: ProviderInput;
  const provider: Provider = {
    mode: "demo",
    lookup(i) {
      calls++;
      input = i;
      return new Promise((r) => {
        resolve = r;
      });
    },
  };
  return {
    provider,
    get calls() {
      return calls;
    },
    get input() {
      return input;
    },
    finish(found = true) {
      resolve({
        requestId: input.requestId,
        phone: input.phone,
        final: true,
        found,
        ...(found ? { country: "España", name: "Persona inventada" } : {}),
      });
    },
  };
}
async function body(sessionId: string, text = "600 000-001") {
  return {
    sessionId,
    requestId: crypto.randomUUID(),
    noteId: crypto.randomUUID(),
    text,
    revision: await digest(text),
  };
}
const tick = () => new Promise((r) => setTimeout(r, 8));
test("consulta autorizada, duplicados bloqueados y metadatos sin resultado ni teléfono", async () => {
  const p = deferredProvider(),
    { service, db } = fixture(p.provider);
  const s = await service.start("artist", { participantIds: ["demo-alba"] });
  const b = await body(s.id);
  const first = service.query("artist", b, s.csrf);
  await tick();
  await assert.rejects(
    service.query("artist", b, s.csrf),
    /petición ya se recibió/,
  );
  assert.equal(p.calls, 1);
  p.finish();
  const r = await first;
  assert.equal(r.result?.name, "Persona inventada");
  assert.equal(r.noteId, b.noteId);
  await assert.rejects(
    service.query("artist", b, s.csrf),
    /petición ya se recibió/,
  );
  const rows = JSON.stringify(db.prepare("SELECT * FROM queries").all());
  assert.ok(!rows.includes("600000001"));
  assert.ok(!rows.includes("Persona inventada"));
  assert.ok(!rows.includes("country"));
});
test("bloquea otros artistas, CSRF incorrecto, titular no seleccionado y revisión falsa antes de proveedor", async () => {
  const p = deferredProvider(),
    { service } = fixture(p.provider),
    s = await service.start("artist", { participantIds: ["demo-alba"] }),
    b = await body(s.id);
  await assert.rejects(service.query("another", b, s.csrf), /Sesión caducada/);
  await assert.rejects(service.query("artist", b, "forged"), /Verificación/);
  await assert.rejects(
    service.query("artist", await body(s.id, "700000002"), s.csrf),
    /no está autorizado/,
  );
  await assert.rejects(
    service.query("artist", await body(s.id, "611111111"), s.csrf),
    /no está autorizado/,
  );
  await assert.rejects(
    service.query("artist", { ...b, revision: "0".repeat(64) }, s.csrf),
    /revisión no coincide/,
  );
  assert.equal(p.calls, 0);
});
test("serializa peticiones concurrentes por sesión", async () => {
  const p = deferredProvider(),
    { service } = fixture(p.provider),
    s = await service.start("artist", { participantIds: ["demo-alba"] });
  const a = service.query("artist", await body(s.id), s.csrf);
  await tick();
  await assert.rejects(
    service.query("artist", await body(s.id), s.csrf),
    /consulta pendiente/,
  );
  p.finish();
  await a;
  assert.equal(p.calls, 1);
});
test("borrar o reiniciar sesión descarta respuesta en curso", async () => {
  const p = deferredProvider(),
    { service, db } = fixture(p.provider),
    s = await service.start("artist", { participantIds: ["demo-alba"] });
  const a = service.query("artist", await body(s.id), s.csrf);
  await tick();
  await service.start("artist", { participantIds: ["demo-alba"] });
  p.finish();
  await assert.rejects(a, /sesión cambió/);
  assert.equal(db.prepare("SELECT * FROM queries").all().length, 0);
});
test("timeout con respuesta tardía no cambia el estado ni reenvía", async () => {
  const p = deferredProvider(),
    { service, db } = fixture(p.provider, 25),
    s = await service.start("artist", { participantIds: ["demo-alba"] });
  await assert.rejects(
    service.query("artist", await body(s.id), s.csrf),
    /Tiempo de espera/,
  );
  p.finish();
  await tick();
  assert.equal(
    db.prepare("SELECT status FROM queries").get()?.status,
    "tiempo agotado",
  );
  assert.equal(p.calls, 1);
});
test("sin resultado y errores de red liberan la sesión", async () => {
  const p = deferredProvider(),
    { service, db } = fixture(p.provider),
    s = await service.start("artist", { participantIds: ["demo-alba"] });
  const a = service.query("artist", await body(s.id), s.csrf);
  await tick();
  p.finish(false);
  assert.equal((await a).status, "sin resultado");
  assert.equal(
    db.prepare("SELECT active_query FROM sessions").get()?.active_query,
    null,
  );
  const network = fixture({
    mode: "demo",
    async lookup() {
      throw new Error("secret phone private provider error");
    },
  });
  const t = await network.service.start("artist", {
    participantIds: ["demo-alba"],
  });
  await assert.rejects(
    network.service.query("artist", await body(t.id), t.csrf),
    /No se pudo contactar/,
  );
  assert.ok(
    !JSON.stringify(network.db.prepare("SELECT * FROM queries").all()).includes(
      "secret",
    ),
  );
});
test("límites persistentes por artista y sesión", async () => {
  const { service } = fixture();
  for (let i = 0; i < 20; i++) await service.rate("artist", "query", 20);
  await assert.rejects(service.rate("artist", "query", 20), /Límite alcanzado/);
  const s = await service.start("second-artist", {
    participantIds: ["demo-alba"],
  });
  await service.store.run(
    "UPDATE sessions SET query_count=10 WHERE id=?",
    s.id,
  );
  await assert.rejects(
    service.query("second-artist", await body(s.id), s.csrf),
    /límite de sesión/,
  );
});
