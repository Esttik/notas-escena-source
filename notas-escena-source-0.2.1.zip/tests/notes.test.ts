import { test } from "node:test";
import assert from "node:assert/strict";
import {
  groups,
  findNotes,
  persistNotes,
  loadNotes,
  type Note,
} from "../lib/client/notes.ts";
test("agrupación por fechas reales y búsqueda sin distinguir acentos", () => {
  const now = Date.parse("2026-10-11T14:00:00Z");
  const notes = [
    {
      id: "a",
      text: "Café\nRecordatorio",
      pinned: false,
      updated: now - 86400000,
    },
    { id: "b", text: "Fijada", pinned: true, updated: now - 30 * 86400000 },
  ];
  assert.deepEqual(
    groups(notes, now).map((g) => g[0]),
    ["Fijadas", "Ayer"],
  );
  assert.equal(findNotes(notes, "cafe")[0].id, "a");
});
test("no persiste contenido de actuación ni resultados", () => {
  let stored = "";
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      setItem(_k: string, v: string) {
        stored = v;
      },
      getItem() {
        return stored;
      },
    },
  });
  const notes: Note[] = [
    { id: "ordinary", text: "Lista de la compra", updated: 1, pinned: false },
    {
      id: "performance",
      text: "Número\nNombre: DATOS-PERSONALES",
      updated: 2,
      pinned: false,
      volatile: true,
    },
  ];
  persistNotes(notes);
  assert.ok(!stored.includes("DATOS-PERSONALES"));
  assert.equal(loadNotes().length, 1);
});

test("borrado recuperable conserva texto, fechas y fijación; actuación se descarta", async () => {
  const { deleteNote, restoreNote } = await import("../lib/client/notes.ts");
  const ordinary: Note = {
    id: "ordinary",
    text: "Ficción\nSegunda línea",
    pinned: true,
    updated: 100,
  };
  const performance: Note = { ...ordinary, id: "performance", volatile: true };
  const deleted = deleteNote([ordinary, performance], "ordinary", 200);
  assert.equal(deleted[0].deleted, 200);
  assert.equal(groups(deleted, 200).flatMap((g) => g[1]).length, 1);
  assert.deepEqual(restoreNote(deleted, "ordinary")[0], ordinary);
  assert.equal(deleteNote([performance], "performance", 200).length, 0);
});
test("papelera persistente excluye actuación y caduca a los 30 días", () => {
  let stored = "";
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      setItem(_k: string, v: string) {
        stored = v;
      },
      getItem() {
        return stored;
      },
    },
  });
  const now = Date.now();
  persistNotes([
    {
      id: "recover",
      text: "Recuperable ficticio",
      updated: now,
      deleted: now - 1000,
      pinned: true,
    },
    {
      id: "expired",
      text: "Caducado ficticio",
      updated: now,
      deleted: now - 31 * 86400000,
      pinned: false,
    },
    {
      id: "secret",
      text: "RESPUESTA-PRIVADA",
      updated: now,
      deleted: now,
      volatile: true,
      pinned: false,
    },
  ]);
  assert.ok(!stored.includes("RESPUESTA-PRIVADA"));
  const loaded = loadNotes();
  assert.equal(loaded.length, 1);
  assert.equal(loaded[0].id, "recover");
  assert.equal(loaded[0].pinned, true);
});

test("agrupa por día de calendario aunque cambie el horario de verano", () => {
  const now = Date.parse("2026-03-29T01:30:00Z");
  const previousDay = Date.parse("2026-03-28T22:30:00Z");
  const sameDay = Date.parse("2026-03-28T23:30:00Z");
  const notes: Note[] = [
    {
      id: "yesterday",
      text: "Ayer ficticio",
      updated: previousDay,
      pinned: false,
    },
    { id: "today", text: "Hoy ficticio", updated: sameDay, pinned: false },
  ];
  assert.deepEqual(
    groups(notes, now).map((g) => [g[0], g[1][0].id]),
    [
      ["Hoy", "today"],
      ["Ayer", "yesterday"],
    ],
  );
});

test("guardado combina notas distintas y rechaza conflicto de la misma nota", async () => {
  const { mergeOrdinaryNotes, NoteConflict } =
    await import("../lib/client/notes.ts");
  const a: Note = { id: "a", text: "Ficción A", updated: 1, pinned: false };
  const b: Note = { ...a, id: "b", text: "Ficción B" };
  const editA = { ...a, text: "Nueva ficción A", updated: 2 };
  const editB = { ...b, text: "Nueva ficción B", updated: 3 };
  assert.deepEqual(mergeOrdinaryNotes([a, b], [a, editB], [editA, b]), [
    editA,
    editB,
  ]);
  assert.throws(
    () =>
      mergeOrdinaryNotes(
        [a, b],
        [{ ...a, text: "Otra ficción" }, b],
        [editA, b],
      ),
    NoteConflict,
  );
  assert.deepEqual(mergeOrdinaryNotes([a, b], [b], [a, editB]), [editB]);
});

test("eliminar una copia temporal borra todas sus copias y permite recuperar el original exacto", async () => {
  const { deleteNote, restoreNote } = await import("../lib/client/notes.ts");
  const original: Note = {
    id: "original",
    text: "Texto ficticio original",
    pinned: true,
    updated: 123,
  };
  const copy: Note = {
    ...original,
    id: "copy",
    sourceId: original.id,
    text: "Edición privada temporal",
    volatile: true,
  };
  const copy2: Note = { ...copy, id: "copy2" };
  const other: Note = { ...original, id: "other", text: "Otra nota" };
  const deleted = deleteNote([original, copy, copy2, other], copy.id, 456);
  assert.equal(deleted.length, 2);
  assert.deepEqual(deleted[0], { ...original, deleted: 456 });
  assert.deepEqual(restoreNote(deleted, original.id), [original, other]);
  assert.ok(!JSON.stringify(deleted).includes("Edición privada"));
  assert.deepEqual(deleteNote([original, copy], original.id, 456), [
    { ...original, deleted: 456 },
  ]);
});
