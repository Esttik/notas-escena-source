import { test } from "node:test";
import assert from "node:assert/strict";
import { EditorHistory } from "../lib/client/editor-history.ts";
test("historial conserva saltos, deshace un cambio y limita memoria", () => {
  const h = new EditorHistory({ text: "Título\nTexto", start: 12, end: 12 });
  h.record({ text: "Título\nTexto añadido", start: 20, end: 20 });
  assert.equal(h.undo()?.text, "Título\nTexto");
  assert.equal(h.redo()?.text, "Título\nTexto añadido");
  for (let i = 0; i < 80; i++)
    h.record({ text: "x".repeat(10000) + i, start: 0, end: 0 });
  assert.ok(h.depth <= 50);
  assert.ok(h.size <= 200000);
});
