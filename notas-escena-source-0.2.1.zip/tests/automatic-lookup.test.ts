import test from "node:test";
import assert from "node:assert/strict";
import {
  AutomaticLookup,
  eligiblePhone,
} from "../lib/client/automatic-lookup.ts";
const context = {
  sessionId: "session",
  noteId: "note",
  revision: 1,
  generation: 1,
};
test("detección automática exige un único móvil completo seleccionado", () => {
  const allowed = new Set(["+34600000001"]);
  assert.equal(eligiblePhone("600 000-001", allowed), "+34600000001");
  for (const text of [
    "60000000",
    "611111111",
    "600000001 700000002",
    "+34+34600000001",
    "800000001",
  ])
    assert.equal(eligiblePhone(text, allowed), null);
});
test("una consulta automática por sesión, nota y número; editar no provoca reintentos", () => {
  const lookup = new AutomaticLookup();
  assert.equal(lookup.reserve(context, "+34600000001"), true);
  assert.equal(
    lookup.reserve({ ...context, revision: 2 }, "+34600000001"),
    false,
  );
  assert.equal(
    lookup.reserve({ ...context, noteId: "other" }, "+34600000001"),
    true,
  );
  lookup.reset();
  assert.equal(lookup.reserve(context, "+34600000001"), true);
});
test("peek solo mientras se mantiene pulsado; soltar oculta y permite repetir sin consultar", () => {
  const lookup = new AutomaticLookup();
  lookup.stage(context, "\n\nNombre: Persona ficticia");
  assert.equal(lookup.peek(context), null);
  lookup.startHold(context);
  assert.equal(lookup.peek(context), "\n\nNombre: Persona ficticia");
  lookup.release();
  assert.equal(lookup.peek(context), null);
  lookup.startHold(context);
  assert.equal(lookup.peek(context), "\n\nNombre: Persona ficticia");
});
test("cambio de nota, revisión, sesión o generación descarta la respuesta reservada", () => {
  for (const changed of [
    { ...context, noteId: "other" },
    { ...context, revision: 2 },
    { ...context, sessionId: "other" },
    { ...context, generation: 2 },
  ]) {
    const lookup = new AutomaticLookup();
    lookup.stage(context, "respuesta");
    lookup.startHold(changed);
    assert.equal(lookup.peek(changed), null);
    assert.equal(lookup.result(context), null);
  }
  const lookup = new AutomaticLookup();
  lookup.stage(context, "respuesta");
  lookup.discard();
  assert.equal(lookup.result(context), null);
});
test("soltar antes de la respuesta evita que aparezca después; otro contexto nunca revela", () => {
  const lookup = new AutomaticLookup();
  lookup.startHold(context);
  lookup.release();
  lookup.stage(context, "ficticio");
  assert.equal(lookup.peek(context), null);
  lookup.startHold(context);
  assert.equal(lookup.peek(context), "ficticio");
  assert.equal(lookup.peek({ ...context, revision: 2 }), null);
  lookup.discard();
  assert.equal(lookup.peek(context), null);
});
