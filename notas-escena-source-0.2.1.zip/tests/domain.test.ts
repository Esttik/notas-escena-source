import { test } from "node:test";
import assert from "node:assert/strict";
import {
  normalizePhone,
  validateResult,
  formatResult,
  canInsert,
} from "../lib/domain.ts";
for (const input of [
  "600000001",
  "600 000-001",
  "+34 600 000 001",
  "0034-600-000-001",
]) {
  test(`normaliza ${input}`, () =>
    assert.equal(normalizePhone(input), "+34600000001"));
}
for (const input of [
  "60000000",
  "800000001",
  "+34+34600000001",
  "600000001 700000002",
  "600.000.001",
  "600000001 ext 1",
  "600000001\n600000001",
  "1234567890",
]) {
  test(`rechaza entrada ambigua/inválida ${input}`, () =>
    assert.throws(() => normalizePhone(input)));
}
test("acepta número en primera línea y preserva texto de la nota fuera de normalización", () => {
  assert.equal(
    normalizePhone("Ideas\n+34 600-000-001\nEscena"),
    "+34600000001",
  );
});
test("valida correlación y campos parciales, no inventa datos", () => {
  assert.throws(() =>
    validateResult(
      { requestId: "b", phone: "+34600000001", final: true },
      "a",
      "+34600000001",
    ),
  );
  assert.throws(() =>
    validateResult(
      { requestId: "a", phone: "+34600000001", final: false },
      "a",
      "+34600000001",
    ),
  );
  const r = validateResult(
    {
      requestId: "a",
      phone: "+34600000001",
      final: true,
      name: "<script>alert(1)</script>",
    },
    "a",
    "+34600000001",
  );
  assert.equal(
    formatResult(r),
    "Número: +34600000001\nNombre: <script>alert(1)</script>",
  );
  assert.throws(() =>
    validateResult(
      {
        requestId: "a",
        phone: "+34600000001",
        final: true,
        name: { html: "x" },
      },
      "a",
      "+34600000001",
    ),
  );
});
test("no inserta tras editar, cambiar nota o reiniciar sesión", () => {
  const a = { sessionId: "s", noteId: "n", revision: 2, generation: 1 };
  assert.equal(canInsert(a, a), true);
  for (const b of [
    { ...a, revision: 3 },
    { ...a, noteId: "m" },
    { ...a, sessionId: "t" },
    { ...a, generation: 2 },
  ])
    assert.equal(canInsert(a, b), false);
});
