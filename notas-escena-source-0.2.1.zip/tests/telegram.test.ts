import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import {
  TelegramProvider,
  parseTelegramResult,
} from "../lib/server/telegram.ts";
import { Store, type Database } from "../lib/server/store.ts";
import { Service } from "../lib/server/service.ts";
import { digest } from "../lib/domain.ts";

const config = {
  PROVIDER_MODE: "real",
  PROVIDER_TRANSPORT: "telegram",
  PROVIDER_AUTHORIZED: "true",
  TELEGRAM_BOT_TOKEN: "12345:test-only-secret",
  TELEGRAM_TARGET_BOT_ID: "54321",
  TELEGRAM_TARGET_USERNAME: "TrueCalleRobot",
  TELEGRAM_PROTOCOL_CONFIRMED: "true",
  TELEGRAM_FINAL_SUFFIX: "END OF RESULT",
  TELEGRAM_NO_RESULT_TEXT: "NO RESULT",
};
const phone = "+34600000001";
const text = `Number: ${phone}\nCountry: Spain\nCarrier: Operador ficticio\nName: Persona ficticia\nEND OF RESULT`;
function fixture() {
  const db = new DatabaseSync(":memory:");
  for (const file of [
    "0000_bouncy_scalphunter.sql",
    "0001_robust_thunderball.sql",
  ])
    db.exec(
      readFileSync(new URL(`../drizzle/${file}`, import.meta.url), "utf8"),
    );
  const database: Database = {
    prepare(sql) {
      const stmt = db.prepare(sql);
      let args: unknown[] = [];
      return {
        bind(...values: unknown[]) {
          args = values;
          return this;
        },
        async first<T>() {
          return (stmt.get(...(args as (string | number | null)[])) ??
            null) as T | null;
        },
        async all<T>() {
          return {
            results: stmt.all(...(args as (string | number | null)[])) as T[],
          };
        },
        async run() {
          return stmt.run(...(args as (string | number | null)[]));
        },
      };
    },
  };
  return { db, store: new Store(database) };
}
const ok = (result: unknown) => Response.json({ ok: true, result });
const reply = (
  id = 7,
  replyId = 40,
  body = text,
  sender = 54321,
  chat = 54321,
) => ({
  update_id: id,
  message: {
    message_id: id,
    from: { id: sender, is_bot: true },
    chat: { id: chat, type: "private" },
    reply_to_message: { message_id: replyId },
    text: body,
  },
});
function input(signal = new AbortController().signal) {
  return {
    requestId: crypto.randomUUID(),
    phone,
    sessionId: crypto.randomUUID(),
    signal,
  };
}
function harness(updates: unknown[][] = [[reply()]]) {
  const calls: { method: string; body: Record<string, unknown> }[] = [];
  const fetcher = async (url: string | URL | Request, init?: RequestInit) => {
    const method = String(url).split("/").at(-1)!;
    const body = JSON.parse(String(init?.body ?? "{}"));
    calls.push({ method, body });
    if (method === "getMe") return ok({ id: 12345, is_bot: true });
    if (method === "getWebhookInfo") return ok({ url: "" });
    if (method === "getChat")
      return ok({ id: 54321, type: "private", username: "TrueCalleRobot" });
    if (method === "sendMessage")
      return ok({ message_id: 40, chat: { id: 54321, type: "private" } });
    if (method === "getUpdates") return ok(updates.shift() ?? []);
    throw Error("unexpected method");
  };
  return { calls, fetcher };
}
test("Telegram resuelve el bot por username antes de verificar su ID estable", async () => {
  const { store } = fixture();
  const h = harness();
  const provider = new TelegramProvider(config, store, h.fetcher);
  await provider.check(new AbortController().signal);
  assert.equal(
    h.calls.find((call) => call.method === "getChat")?.body.chat_id,
    "@TrueCalleRobot",
  );
});
test("Telegram requiere configuración y permiso; parsea texto ficticio, rechaza parcial, número distinto y campos duplicados", () => {
  const { store } = fixture();
  assert.throws(() => new TelegramProvider({}, store), /configuración/);
  const r = parseTelegramResult(text, "request", phone, config);
  assert.equal(r.name, "Persona ficticia");
  assert.equal(
    parseTelegramResult(`Number: ${phone}\nNO RESULT`, "request", phone, config)
      .found,
    false,
  );
  assert.throws(
    () =>
      parseTelegramResult(
        text.replace("END OF RESULT", ""),
        "request",
        phone,
        config,
      ),
    /parcial/,
  );
  assert.throws(
    () =>
      parseTelegramResult(
        text.replace(phone, "+34700000002"),
        "request",
        phone,
        config,
      ),
    /corresponde/,
  );
  assert.throws(
    () =>
      parseTelegramResult(
        text.replace("Name:", "Name: X\nName:"),
        "request",
        phone,
        config,
      ),
    /duplicado/,
  );
  assert.equal(
    parseTelegramResult(
      text.replace("Persona ficticia", "<script>evil()</script>"),
      "request",
      phone,
      config,
    ).name,
    "<script>evil()</script>",
  );
});
test("Telegram envía +34 una sola vez y acepta únicamente respuesta correlacionada de origen/conversación fijados", async () => {
  const { store, db } = fixture(),
    h = harness([
      [
        reply(1, 39),
        reply(2, 40, text, 999),
        reply(3, 40, text, 54321, 999),
        reply(4),
      ],
    ]);
  const p = new TelegramProvider(config, store, h.fetcher),
    i = input();
  const r = await p.lookup(i);
  assert.equal(r.requestId, i.requestId);
  assert.equal(r.phone, phone);
  assert.equal(h.calls.filter((c) => c.method === "sendMessage").length, 1);
  assert.equal(
    h.calls.find((c) => c.method === "sendMessage")?.body.text,
    phone,
  );
  assert.equal(
    h.calls.find((c) => c.method === "sendMessage")?.body.chat_id,
    54321,
  );
  const persisted = JSON.stringify(
    db.prepare("SELECT * FROM telegram_state").all(),
  );
  assert.ok(
    !persisted.includes(phone) &&
      !persisted.includes("Persona ficticia") &&
      !persisted.includes(config.TELEGRAM_BOT_TOKEN),
  );
});
test("Telegram bloqueo global abarca distintas instancias; un segundo artista no envía mientras está pendiente", async () => {
  const { store } = fixture(),
    h = harness();
  let resolve!: (r: Response) => void;
  const blocked = async (url: string | URL | Request, init?: RequestInit) =>
    String(url).endsWith("getUpdates")
      ? new Promise<Response>((r) => {
          resolve = r;
        })
      : h.fetcher(url, init);
  const p = new TelegramProvider(config, store, blocked),
    i = input();
  const pending = p.lookup(i);
  while (!resolve) await new Promise((r) => setTimeout(r, 1));
  await assert.rejects(
    new TelegramProvider(config, store, h.fetcher).lookup(input()),
    /pendiente/,
  );
  await assert.rejects(
    new TelegramProvider(
      { ...config, TELEGRAM_BOT_TOKEN: "12345:rotated-test-secret" },
      store,
      h.fetcher,
    ).lookup(input()),
    /pendiente/,
  );
  resolve(ok([reply()]));
  await pending;
  assert.equal(h.calls.filter((c) => c.method === "sendMessage").length, 1);
});
test("Telegram rechaza webhook activo y destinatario distinto antes de transmitir un teléfono", async () => {
  for (const method of ["getWebhookInfo", "getChat"]) {
    const { store } = fixture(),
      h = harness();
    const f = async (url: string | URL | Request, init?: RequestInit) =>
      String(url).endsWith(method)
        ? ok(
            method === "getChat"
              ? { id: 888, type: "private", username: "OtherBot" }
              : { url: "https://other.example/webhook" },
          )
        : h.fetcher(url, init);
    await assert.rejects(
      new TelegramProvider(config, store, f).lookup(input()),
    );
    assert.equal(h.calls.filter((c) => c.method === "sendMessage").length, 0);
  }
});
test("Telegram 429 conserva cooldown y no repite el envío; errores no filtran descripción ni token", async () => {
  const { store, db } = fixture(),
    h = harness();
  const f = async (url: string | URL | Request, init?: RequestInit) =>
    String(url).endsWith("sendMessage")
      ? Response.json(
          {
            ok: false,
            error_code: 429,
            description: config.TELEGRAM_BOT_TOKEN,
            parameters: { retry_after: 60 },
          },
          { status: 429 },
        )
      : h.fetcher(url, init);
  await assert.rejects(
    new TelegramProvider(config, store, f).lookup(input()),
    (e: Error) => !e.message.includes(config.TELEGRAM_BOT_TOKEN),
  );
  await assert.rejects(
    new TelegramProvider(config, store, h.fetcher).lookup(input()),
    /espera/,
  );
  assert.ok(
    (
      db.prepare("SELECT cooldown_until FROM telegram_state").get() as {
        cooldown_until: number;
      }
    ).cooldown_until > Date.now(),
  );
});
test("Telegram tras abortar descarta una respuesta tardía y libera el bloqueo sin responder al proveedor", async () => {
  const { store, db } = fixture(),
    h = harness();
  let resolve!: (r: Response) => void;
  const f = async (url: string | URL | Request, init?: RequestInit) =>
    String(url).endsWith("getUpdates")
      ? new Promise<Response>((r) => {
          resolve = r;
        })
      : h.fetcher(url, init);
  const controller = new AbortController();
  const pending = new TelegramProvider(config, store, f).lookup(
    input(controller.signal),
  );
  while (!resolve) await new Promise((r) => setTimeout(r, 1));
  controller.abort();
  resolve(ok([reply()]));
  await assert.rejects(pending, /agotado/);
  assert.equal(
    (
      db.prepare("SELECT request_id FROM telegram_state").get() as {
        request_id: null;
      }
    ).request_id,
    null,
  );
  assert.equal(h.calls.filter((c) => c.method === "sendMessage").length, 1);
});
test("Telegram ignora mensajes parciales y duplicados; un error de capacidad no filtra descripción ni reintenta", async () => {
  const { store } = fixture(),
    h = harness([
      [reply(1, 40, text.replace("END OF RESULT", "")), reply(1), reply(2)],
    ]);
  assert.equal(
    (await new TelegramProvider(config, store, h.fetcher).lookup(input())).name,
    "Persona ficticia",
  );
  const { store: nextStore } = fixture(),
    next = harness();
  let sends = 0;
  const f = async (url: string | URL | Request, init?: RequestInit) => {
    if (String(url).endsWith("sendMessage")) {
      sends++;
      return Response.json(
        {
          ok: false,
          error_code: 400,
          description: `USER_BOT_TO_BOT_DISABLED ${config.TELEGRAM_BOT_TOKEN}`,
        },
        { status: 400 },
      );
    }
    return next.fetcher(url, init);
  };
  await assert.rejects(
    new TelegramProvider(config, nextStore, f).lookup(input()),
    (e: Error & { code?: string }) =>
      e.code === "TELEGRAM_BOT_TO_BOT_DISABLED" &&
      !e.message.includes(config.TELEGRAM_BOT_TOKEN),
  );
  assert.equal(sends, 1);
});
test("Servicio Telegram comprueba autorización antes de enviar y correlaciona la ficha con nota, revisión y sesión", async () => {
  const { store, db } = fixture(),
    h = harness();
  const realConfig = {
    ...config,
    AUTHORIZED_PARTICIPANTS_JSON: JSON.stringify([
      {
        id: "fictional-holder",
        label: "Ficha ficticia",
        phone,
        artistId: "artist",
        consentRef: "fictional-evidence",
        ownershipVerifiedAt: new Date(Date.now() - 1000).toISOString(),
        expiresAt: new Date(Date.now() + 60000).toISOString(),
        scope: "lookup",
        provider: "telegram:@TrueCalleRobot:54321",
      },
    ]),
  };
  const service = new Service(
    store,
    realConfig,
    new TelegramProvider(realConfig, store, h.fetcher),
  );
  const session = await service.start("artist", {
    participantIds: ["fictional-holder"],
  });
  const makeBody = async (text: string) => ({
    sessionId: session.id,
    requestId: crypto.randomUUID(),
    noteId: crypto.randomUUID(),
    text,
    revision: await digest(text),
  });
  await assert.rejects(
    service.query("artist", await makeBody("700000002"), session.csrf),
    /no está autorizado/,
  );
  assert.equal(h.calls.length, 0);
  const body = await makeBody("600 000-001");
  const result = await service.query("artist", body, session.csrf);
  assert.equal(result.noteId, body.noteId);
  assert.equal(result.revision, body.revision);
  assert.equal(result.sessionId, session.id);
  assert.equal(result.result?.name, "Persona ficticia");
  await assert.rejects(
    service.query("artist", body, session.csrf),
    /ya se recibió/,
  );
  assert.equal(h.calls.filter((c) => c.method === "sendMessage").length, 1);
  const rows = JSON.stringify(db.prepare("SELECT * FROM queries").all());
  assert.ok(!rows.includes(phone) && !rows.includes("Persona ficticia"));
});
