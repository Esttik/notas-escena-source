import { useEffect, useRef, useState } from "react";
import {
  dateLabel,
  excerpt,
  findNotes,
  groups,
  title,
  type Note,
} from "../lib/client/notes";
import { Icon } from "./Icon";
export function NoteList({
  notes,
  open,
  create,
  artist,
  folders,
  search,
  setSearch,
  folded,
  setFolded,
  remove,
  pin,
}: {
  notes: Note[];
  open: (id: string) => void;
  create: () => void;
  artist: () => void;
  folders: () => void;
  search: string;
  setSearch: (value: string) => void;
  folded: boolean;
  setFolded: (value: boolean) => void;
  remove: (id: string) => void;
  pin: (id: string) => void;
}) {
  const [, refreshDates] = useState(0);
  useEffect(() => {
    const refresh = () => refreshDates((n) => n + 1);
    const timer = setInterval(refresh, 60000);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      clearInterval(timer);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, []);
  const found = findNotes(notes, search);
  return (
    <section className="list-screen">
      <header className="list-header">
        <button className="round" aria-label="Carpetas" onClick={folders}>
          <Icon name="back" />
        </button>
        <div className="list-heading">
          <h1>Notas</h1>
          <p>
            {notes.length} {notes.length === 1 ? "nota" : "notas"}
          </p>
        </div>
        <button
          className="round"
          aria-label="Menú y área del artista"
          onClick={artist}
        >
          <Icon name="more" />
        </button>
      </header>
      <div className="note-groups">
        {groups(found).map(([label, items]) => (
          <section className="note-section" key={label}>
            <div className="section-heading">
              <h2>{label}</h2>
              {label === "Fijadas" && (
                <button
                  aria-label={folded ? "Mostrar fijadas" : "Ocultar fijadas"}
                  aria-expanded={!folded}
                  className={`collapse ${folded ? "folded" : ""}`}
                  onClick={() => setFolded(!folded)}
                >
                  <Icon name="chevron" />
                </button>
              )}
            </div>
            {!(label === "Fijadas" && folded) && (
              <div className="note-card">
                {items.map((n) => (
                  <NoteRow
                    key={n.id}
                    note={n}
                    open={() => open(n.id)}
                    remove={() => remove(n.id)}
                    pin={() => pin(n.id)}
                  />
                ))}
              </div>
            )}
          </section>
        ))}
        {!found.length && (
          <p className="empty">
            {search ? "No se encontraron notas." : "Todavía no hay notas."}
          </p>
        )}
      </div>
      <footer className="list-bottom">
        <label className="search-pill">
          <Icon name="search" />
          <input
            type="search"
            placeholder="Buscar"
            aria-label="Buscar notas"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          {search && (
            <button aria-label="Limpiar búsqueda" onClick={() => setSearch("")}>
              <Icon name="close" />
            </button>
          )}
        </label>
        <button
          className="round compose"
          aria-label="Crear nueva nota"
          onClick={create}
        >
          <Icon name="compose" />
        </button>
      </footer>
    </section>
  );
}

function NoteRow({
  note,
  open,
  remove,
  pin,
}: {
  note: Note;
  open: () => void;
  remove: () => void;
  pin: () => void;
}) {
  const [action, setAction] = useState<"pin" | "delete" | null>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const dragged = useRef(false);
  useEffect(() => {
    if (!action) return;
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") setAction(null);
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [action]);
  return (
    <div className={`swipe-row ${action ? `show-${action}` : ""}`}>
      {action && (
        <button
          className={`swipe-action ${action === "delete" ? "danger" : ""}`}
          aria-label={
            action === "delete"
              ? `Eliminar ${title(note)}`
              : `${note.pinned ? "Desfijar" : "Fijar"} ${title(note)}`
          }
          onClick={() => {
            (action === "delete" ? remove : pin)();
            setAction(null);
          }}
        >
          <Icon name={action === "delete" ? "trash" : "pin"} />
          <span>
            {action === "delete"
              ? "Eliminar"
              : note.pinned
                ? "Desfijar"
                : "Fijar"}
          </span>
        </button>
      )}
      <button
        className="note-row"
        aria-expanded={!!action}
        onPointerDown={(e) => {
          start.current = { x: e.clientX, y: e.clientY };
          dragged.current = false;
        }}
        onPointerMove={(e) => {
          const p = start.current;
          if (!p) return;
          const dx = e.clientX - p.x,
            dy = e.clientY - p.y;
          if (Math.abs(dy) > 24 && Math.abs(dy) > Math.abs(dx)) {
            start.current = null;
            return;
          }
          if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5) {
            dragged.current = true;
            setAction(dx < 0 ? "delete" : "pin");
          }
        }}
        onPointerUp={() => {
          start.current = null;
        }}
        onPointerCancel={() => {
          start.current = null;
        }}
        onContextMenu={(e) => {
          e.preventDefault();
          setAction(action ? null : "delete");
        }}
        onKeyDown={(e) => {
          if (e.key === "Delete") {
            e.preventDefault();
            setAction("delete");
          }
          if (e.key === "ArrowRight") {
            e.preventDefault();
            setAction("pin");
          }
        }}
        onClick={() => {
          if (dragged.current) return;
          if (action) setAction(null);
          else open();
        }}
      >
        <span className="row-title">{title(note)}</span>
        <span className="row-excerpt">
          <time>{dateLabel(note.updated)}</time> {excerpt(note)}
        </span>
      </button>
    </div>
  );
}
