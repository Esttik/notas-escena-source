import type { CSSProperties } from "react";
export type IconName =
  | "back"
  | "more"
  | "compose"
  | "search"
  | "undo"
  | "share"
  | "check"
  | "checklist"
  | "table"
  | "clip"
  | "pen"
  | "link"
  | "pin"
  | "trash"
  | "chevron"
  | "folder"
  | "close";
export function Icon({
  name,
  style,
}: {
  name: IconName;
  style?: CSSProperties;
}) {
  const paths: Record<IconName, React.ReactNode> = {
    back: <path d="m15 4-8 8 8 8" />,
    more: (
      <>
        <circle cx="5" cy="12" r="1.4" fill="currentColor" />
        <circle cx="12" cy="12" r="1.4" fill="currentColor" />
        <circle cx="19" cy="12" r="1.4" fill="currentColor" />
      </>
    ),
    compose: (
      <>
        <path d="M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6M14 5l5 5M10 14l-1 4 4-1L22 8l-4-4Z" />
      </>
    ),
    search: (
      <>
        <circle cx="10" cy="10" r="6.5" />
        <path d="m15 15 5 5" />
      </>
    ),
    undo: <path d="m9 4-6 6 6 6M3 10h10c9 0 10 11 0 11" />,
    share: (
      <>
        <path d="M8 8H5v13h14V8h-3M12 15V2m-5 5 5-5 5 5" />
      </>
    ),
    check: <path d="m4 12 6 7L21 3" />,
    checklist: (
      <>
        <circle cx="4" cy="6" r="2" />
        <path d="m3 6 1 1 2-3M10 6h11M10 17h11" />
        <circle cx="4" cy="17" r="2" />
      </>
    ),
    table: (
      <>
        <rect x="2" y="3" width="20" height="18" rx="1.5" />
        <path d="M2 9h20M2 15h20M10 3v18" />
      </>
    ),
    clip: (
      <path d="m9 15 9-9c4-4-1-9-5-5L3 11c-6 6 2 14 8 8L21 9M7 13l8-8c2-2 4 0 2 2l-9 9c-3 3-6-1-3-4" />
    ),
    pen: (
      <>
        <circle cx="12" cy="12" r="10" />
        <path d="m7 21 3-10 2-6 2 6 3 10M10 11h4M9 16h6" />
      </>
    ),
    link: (
      <>
        <path
          d="m9 14 6-6M8 16l-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0M16 8l2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0"
          transform="translate(1 0) scale(.92)"
        />
      </>
    ),
    pin: <path d="m15 3 6 6-3 1-4 4v4l-3-3-7 7 7-7-4-3h4l4-4ZM15 3Z" />,
    trash: (
      <>
        <path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7" />
      </>
    ),
    chevron: <path d="m6 9 6 6 6-6" />,
    folder: <path d="M2 6h8l2 3h10v11H2ZM2 6V3h8l2 3h9v3" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
  };
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={style}
    >
      {paths[name]}
    </svg>
  );
}
