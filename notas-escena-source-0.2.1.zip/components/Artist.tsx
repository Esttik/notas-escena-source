import { APP_VERSION } from "../lib/client/version";
import { useEffect, useState } from "react";
import { api, type Config, type Session } from "../lib/client/api";
import { Icon } from "./Icon";
type Diagnostic = {
  id: string;
  status: string;
  code: string | null;
  provider_ms: number | null;
};
export function Artist({
  config,
  session,
  status,
  detail,
  metrics,
  close,
  start,
  erase,
}: {
  config: Config | null;
  session: Session | null;
  status: string;
  detail: string;
  metrics: { ui: number; provider: number | null } | null;
  close: () => void;
  start: (ids: string[]) => Promise<void>;
  erase: () => Promise<void>;
}) {
  const [ids, setIds] = useState<string[]>(
      config?.participants.map((p) => p.id) ?? [],
    ),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [connectionMessage, setConnectionMessage] = useState(""),
    [logs, setLogs] = useState<Diagnostic[]>([]);
  useEffect(() => {
    if (session)
      api<Diagnostic[]>(
        `diagnostics?sessionId=${session.id}`,
        undefined,
        session.csrf,
      )
        .then(setLogs)
        .catch((e) => setError(e.message));
  }, [session]);
  async function action(fn: () => Promise<void>) {
    setBusy(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="artist-screen">
      <header className="plain-header">
        <button className="round" aria-label="Volver a Notas" onClick={close}>
          <Icon name="back" />
        </button>
        <h1>Área del artista</h1>
      </header>
      <div className="artist-content">
        <div className="mode-label">
          {config?.mode === "real"
            ? config.transport === "telegram"
              ? "Telegram · bot propio"
              : "Proveedor real"
            : "Demostración · datos ficticios"}
        </div>
        <h2>Prepara la sesión</h2>
        <p>
          Solo se consultan las fichas autorizadas que selecciones aquí. Entrega
          el dispositivo al participante cuando la sesión esté preparada.
        </p>
        <p className="small">
          Al detectar un único móvil autorizado, la consulta comienza después de
          una pausa de 800 ms. Mantén pulsados los eslabones para ver la
          respuesta; se oculta al soltar y la nota conserva su texto. No se
          reintenta automáticamente.
        </p>
        {!config && <p role="status">Cargando configuración…</p>}
        {config?.mode === "real" && config.transport === "telegram" && (
          <div className="notice">
            <p>
              La configuración no demuestra que el destinatario admita la
              conexión. La comprobación no envía teléfonos ni inicia consultas.
            </p>
            <button
              className="primary light"
              disabled={busy || !config.realConfigured}
              onClick={() =>
                action(async () => {
                  await api("provider-check");
                  setConnectionMessage(
                    "Token y conversación comprobados. Comunicación entre bots y protocolo todavía pendientes de una consulta autorizada real.",
                  );
                })
              }
            >
              Comprobar conexión del bot
            </button>
            {connectionMessage && <p role="status">{connectionMessage}</p>}
          </div>
        )}
        {config && (
          <>
            <p className="small">Artista: {config.artist}</p>
            {config.mode === "demo" ? (
              <p className="notice">
                Este modo no envía nada a Telegram. Los números siguientes son
                claves sintéticas del juego y sus fichas están inventadas.
              </p>
            ) : (
              <p className="notice">
                Solo aparecen altas con evidencia previa de consentimiento y
                titularidad en el registro del servidor. La respuesta del
                proveedor no acredita una identidad verificada.
              </p>
            )}
            <fieldset>
              <legend>Participantes de esta sesión</legend>
              {config.participants.map((p) => (
                <label className="participant" key={p.id}>
                  <input
                    type="checkbox"
                    checked={ids.includes(p.id)}
                    onChange={(e) =>
                      setIds(
                        e.target.checked
                          ? [...ids, p.id]
                          : ids.filter((i) => i !== p.id),
                      )
                    }
                  />
                  <span>
                    {p.label}
                    <strong>{p.phone}</strong>
                  </span>
                </label>
              ))}
              {!config.participants.length && (
                <p>No hay participantes autorizados vigentes.</p>
              )}
            </fieldset>
            <button
              className="primary"
              disabled={
                busy ||
                !ids.length ||
                (config.mode === "real" && !config.realConfigured)
              }
              onClick={() => action(() => start(ids))}
            >
              {session ? "Reiniciar sesión" : "Preparar sesión"}
            </button>
          </>
        )}
        {session && (
          <>
            <div className="session-info">
              <h2>Sesión preparada</h2>
              <p>
                Caduca a las{" "}
                {new Intl.DateTimeFormat("es", {
                  hour: "2-digit",
                  minute: "2-digit",
                  timeZone: "Europe/Andorra",
                }).format(session.expires)}
                . Las notas de actuación no se guardan en este dispositivo.
              </p>
              <button className="primary light" onClick={close}>
                Volver a las notas
              </button>
            </div>
            <button
              className="danger"
              disabled={busy}
              onClick={() => action(erase)}
            >
              Borrar sesión y resultados
            </button>
          </>
        )}
        <div className="diagnostics">
          <h2>Estado y diagnóstico</h2>
          <p className="small">Versión {APP_VERSION}</p>
          <p>
            <strong>{status}</strong>
          </p>
          <p className="small">
            {detail ||
              "La consulta empieza con un móvil autorizado. Mantén pulsados los eslabones para ver el peek; suelta para ocultarlo. Tras un error, volver a mantenerlos inicia un reintento explícito."}
          </p>
          {metrics && (
            <p className="small">
              Respuesta visual: {metrics.ui.toFixed(1)} ms · Proveedor:{" "}
              {metrics.provider === null
                ? "pendiente"
                : `${metrics.provider} ms`}
            </p>
          )}
          {logs.map((l) => (
            <p className="small" key={l.id}>
              {l.status}
              {l.code ? ` · ${l.code}` : ""}
              {l.provider_ms !== null ? ` · ${l.provider_ms} ms` : ""}
              <br />
              <span className="request-id">{l.id}</span>
            </p>
          ))}
        </div>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        <div className="help">
          <h2>Uso en iPhone</h2>
          <p>
            Abre esta dirección en Safari y elige Compartir → Añadir a la
            pantalla de inicio. El teclado es el del sistema. La consulta
            requiere mantener la app abierta y conexión a internet.
          </p>
          <p>
            El peek puede verlo quien mire la pantalla mientras mantienes
            pulsado. Se oculta al soltar. Deshacer permite descartar el
            resultado reservado.
          </p>
          <p>
            No se almacenan resultados en la PWA, analítica ni cachés. Borrar
            aquí no borra lo que pueda conservar Telegram o el proveedor;
            solicita su eliminación según su política.
          </p>
          <p>
            La barra ofrece texto, lista, tabla de texto y adjuntar texto. El
            lápiz abre las opciones de escritura. Dibujo, escaneo, bloqueo
            nativo y edición colaborativa no están implementados.
          </p>
          <p className="small">
            Tu identificación del artista en este sitio:{" "}
            <span className="request-id">{config?.artistId}</span>
          </p>
        </div>
        <a className="signout" href="/signout-with-chatgpt?return_to=/">
          Cerrar sesión de artista
        </a>
      </div>
    </section>
  );
}
