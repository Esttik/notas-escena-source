import { useState } from "react";
import { title, type Note } from "../lib/client/notes";
import { Icon } from "./Icon";

export function Trash({
  notes,
  close,
  restore,
  purge,
}: {
  notes: Note[];
  close: () => void;
  restore: (id: string) => void;
  purge: (id: string) => void;
}) {
  const [confirm, setConfirm] = useState<string | null>(null);
  return (
    <section className="folders">
      <header className="plain-header">
        <button
          className="round"
          aria-label="Volver a Carpetas"
          onClick={close}
        >
          <Icon name="back" />
        </button>
        <h1>Eliminadas recientemente</h1>
      </header>
      <p>
        Las notas ordinarias se pueden recuperar durante 30 días. Las notas de
        actuación se descartan al eliminarlas.
      </p>
      {notes.length === 0 && <p className="empty">No hay notas eliminadas.</p>}
      {notes.map((note) => (
        <article className="trash-card" key={note.id}>
          <h2>{title(note)}</h2>
          <div className="trash-actions">
            <button
              aria-label={`Recuperar ${title(note)}`}
              onClick={() => restore(note.id)}
            >
              Recuperar
            </button>
            <button
              className="danger"
              aria-label={`Eliminar definitivamente ${title(note)}`}
              onClick={() => setConfirm(note.id)}
            >
              Eliminar
            </button>
          </div>
          {confirm === note.id && (
            <div role="group" aria-label="Confirmar eliminación definitiva">
              <p>Esta nota se eliminará definitivamente de este dispositivo.</p>
              <button
                className="primary light"
                onClick={() => setConfirm(null)}
              >
                Cancelar
              </button>
              <button
                className="primary danger"
                onClick={() => {
                  purge(note.id);
                  setConfirm(null);
                }}
              >
                Eliminar definitivamente
              </button>
            </div>
          )}
        </article>
      ))}
    </section>
  );
}
