# Código fuente público · Notas Escena 0.2.1

Instantánea para lectura y revisión; no es acceso a una instalación de producción. No contiene credenciales, sesiones ni registros de titulares. Las referencias a comprobaciones históricas describen el desarrollo original y no acreditan una integración operativa al descargar esta copia.

# Notas · Escena

PWA privada de notas para iPhone, con artista autenticado y consultas autorizadas. El flujo completo funciona con fichas ficticias: prepara una sesión, crea una nota y escribe `600 000-001`. Tras una pausa de 800 ms comienza la consulta automáticamente. La respuesta se reserva en memoria y aparece como vista temporal bajo el texto solo mientras mantienes pulsados los eslabones. Al soltar se oculta; nunca modifica el contenido ni el historial de la nota.

La integración real con @TrueCalleRobot se comprobó con el teléfono propio del titular mediante una sesión nueva de su cuenta de Telegram. El transporte entre bots sigue rechazado por Telegram; es una alternativa distinta. El [puente de cliente de usuario](bridge/README.md) no extrae sesiones existentes ni utiliza el servidor de Numeria. [Acta de comprobaciones](docs/ACTIVACION-TELEGRAM.md).

El proveedor de Netlify está activo en https://your-notes-project.netlify.app/lookup y conserva las credenciales exclusivamente en Functions de producción. Una consulta real obtuvo respuesta correlacionada en 2100 ms con el puente y el túnel locales apagados; la repetición del mismo UUID fue rechazada sin nuevo envío. La web privada mantiene su dirección de Sites. [Configuración Netlify](bridge/NETLIFY.md).

## Ejecución local

Necesitas Node.js 24, npm y un navegador. Las pruebas del bloqueo de nube necesitan PostgreSQL 17; `POSTGRES_BIN` permite indicar su carpeta bin. Se usa un clúster temporal aislado. Autenticación local simulada exclusivamente en loopback; no usar el servidor de desarrollo como hosting público.

```sh
cd /path/to/notas-escena
npm ci
npm run build
npm --prefix bridge ci --ignore-scripts
npm run test:bridge
npm run typecheck:bridge
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_bouncy_scalphunter.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_robust_thunderball.sql
npm run dev -- --port 5176 --hostname 127.0.0.1
```

Aplica cada migración una sola vez por base local. Abre `http://127.0.0.1:5176/`; el inicio de sesión de desarrollo lo proporciona la plantilla Sites. Si preparas más de cinco sesiones en una hora, se aplica el límite del servidor; para ensayos automatizados usa la base local descartable de las pruebas.

No puede instalarse una PWA desde el localhost del ordenador en un iPhone remoto. Para usar un iPhone abre la dirección HTTPS publicada en Sites y autentícate con la cuenta propietaria.

## Uso

1. Menú superior de tres puntos → Área del artista.
2. Mantén seleccionadas las fichas ficticias y pulsa Preparar sesión.
3. Crea una nota con el botón de composición inferior.
4. Escribe `600000001`, `+34 600 000 001` o `0034-600-000-001` (Alba Ejemplo). La otra ficha sintética es `700000002` (Leo Ensayo).
5. Mantén pulsados los eslabones, a la derecha del lápiz circular: aparece el peek mientras sostienes el botón y se oculta al soltar. Si todavía está consultando, aparece al llegar solo si sigues manteniendo pulsado. Un toque breve no deja información visible. Puedes volver a mantener pulsado sin reenviar la consulta. En teclado, mantén Espacio o Intro sobre el botón.
6. Deshacer descarta el resultado reservado conservando el texto escrito. Borrar sesión y resultados elimina los metadatos del servidor y las notas de actuación en memoria.

Esos números son claves sintéticas: no se afirma que estén reservados ni que no correspondan a un abonado. El proveedor demo jamás los transmite fuera del servidor.

El teléfono debe ser el único contenido numérico de la nota. Se admite texto descriptivo en otras líneas; fechas, extensiones, dos números y formatos ambiguos se rechazan. No se escoge un número silenciosamente. El texto escrito permanece intacto.

La detección automática funciona solo con una sesión preparada y una ficha seleccionada. Cambiar el texto, la nota o la sesión invalida la respuesta pendiente o reservada. No se repite automáticamente la misma sesión/nota/número, ni tras un fallo o deshacer; mantener pulsado cuando falta un resultado inicia una consulta explícita. El peek puede verlo quien mire la pantalla mientras mantienes pulsado.

Las notas ordinarias se guardan en este dispositivo. Durante una actuación, abrir una nota ordinaria crea una copia temporal para proteger el original. Al cerrar o recargar se pierden los resultados y las notas de actuación. No hay sincronización de notas entre dispositivos.

## Conexión real comprobada

El sitio privado está en modo real con el teléfono propio autorizado. El titular vinculó una sesión nueva de Telegram, cifrada en el servidor. El proveedor HTTPS se ejecuta en Netlify Functions con un registro transaccional Postgres para duplicados y límites. El puente y el túnel del Mac se apagaron antes de comprobar la consulta real desde Netlify: ya no son necesarios durante una actuación.

Para usarlo en iPhone: abre tu dirección privada de Sites, autentícate, prepara la sesión en ese dispositivo y crea una nota nueva. Si pulsas los eslabones sin sesión, el área del artista se abre para prepararla. Telegram no tiene que estar abierto en el móvil. El titular confirmó en su iPhone el peek de mantener/soltar después de forzar el cierre para cargar la versión nueva. El agente no utilizó ese dispositivo; falta distinguir Safari/PWA instalada y completar los ensayos físicos ampliados.

## PWA

Manifiesto: `public/manifest.json`. Iconos PNG de 192, 512 y 180 px. En Safari: Compartir → Añadir a la pantalla de inicio. `public/sw.js` cachea solo iconos, manifiesto y pantalla estática sin conexión. Nunca cachea notas, API, respuestas, autenticación ni páginas de la app. Las consultas necesitan conexión y la app abierta; no se promete ejecución cuando iOS la suspenda o cierre.

## Configuración del servidor

El archivo `.env.example` contiene únicamente nombres y ejemplos sin credenciales. En Sites usa sus variables de entorno de servidor; para desarrollo Worker usa un `.dev.vars` ignorado. El modo por defecto es `demo`. No pongas secretos en variables `NEXT_PUBLIC_`, manifiestos o código.

Para la integración compatible consulta [PROVEEDOR.md](docs/PROVEEDOR.md). Para arquitectura, privacidad y límites consulta [SEGURIDAD.md](docs/SEGURIDAD.md).

## Verificación

```sh
npm run typecheck
npm run typecheck:bridge
npm test
npm run test:bridge
npm run test:browser
npm run build
```

Las pruebas de navegador requieren la vista previa anterior en marcha y los navegadores Playwright (`npx playwright install chromium webkit`, si aún no están disponibles). `test:browser` borra **solo** sesiones, peticiones y límites en la base local de prueba, nunca usa una conexión D1 remota. El directorio `.wrangler/state` debe ser descartable durante estos ensayos.

Consulta [PRUEBAS.md](docs/PRUEBAS.md) y [FIDELIDAD.md](docs/FIDELIDAD.md). Las pruebas WebKit con pantalla de iPhone son emulación; no acreditan teclado nativo, Safari físico o instalación real.

## Estructura

- `components/`: listado, editor, controles, artista y coordinación del flujo.
- `lib/client/`: notas ordinarias, agrupación temporal y comunicación con API.
- `lib/domain.ts`: normalización, correlación, validación y formato seguro.
- `lib/server/`: autorización, sesiones, consultas, límites, proveedores y base.
- `bridge/`: proceso Node independiente para Telegram con la cuenta autorizada; sus dependencias y comprobación de tipos son propias y no se incluyen en el Worker/frontend. Véase su README para vinculación y hosting.
- `app/api/[...path]/route.ts`: frontera autenticada, CSRF, límites de cuerpo y errores seguros.
- `db/schema.ts` y `drizzle/`: esquema y migración D1.
- `proxy.ts`: CSP con nonce, cabeceras de seguridad y no-store.
- `tests/`: pruebas unitarias, servidor y navegador.
- `SPEC.md`: decisiones y criterios verificables.

## Publicación

El proyecto se publica privado en Sites; la plataforma gestiona inicio de sesión, cookies y cabeceras de identidad. El backend vuelve a comprobar pertenencia en cada operación. No expongas el Worker fuera de ese gateway: una instalación independiente necesita un proveedor de identidad real que sustituya la confianza en las cabeceras de Sites.

El manifiesto `.openai/hosting.json` declara `DB` y la identidad del Site. Publicar una nueva versión requiere el flujo de empaquetado de Sites y aplica las migraciones incluidas. Los cambios de variables se aplican con un nuevo despliegue.

## Auditoría 0.2.0 · 12 octubre 2026

[Informe completo y límites](docs/auditoria-20261012/INFORME.md) y [matriz de recorridos](docs/auditoria-20261012/cobertura.csv). Crear y volver descarta notas vacías. Las modificaciones ordinarias se guardan inmediatamente; se conserva la búsqueda y posición al volver. Deslizar hacia la derecha ofrece fijar/desfijar; hacia la izquierda ofrece eliminar. También están las opciones del editor y las alternativas de teclado (flecha derecha/Supr sobre una fila, Escape para cerrar).

Las notas ordinarias eliminadas pasan a Carpetas → Eliminadas recientemente, recuperables durante 30 días. El borrado definitivo requiere confirmación. Las notas de actuación se descartan y nunca se conservan en esa papelera. El límite es 200 notas activas y 400 incluyendo papelera, sujeto a la cuota del navegador. Cambios independientes de dos pestañas se combinan; un conflicto en la misma nota avisa y conserva el borrador visible para evitar sobrescribir el guardado. No hay colaboración ni sincronización remota.

El Área del artista muestra la versión de la app. Los cambios ya comprobados localmente no implican que la versión publicada se haya actualizado; consulta el acta de publicación. La nueva cabecera, recuperación y teclado de búsqueda necesitan ensayo físico después de publicar.

## Borrado 0.2.1

Eliminar una copia de actuación también retira su original del listado: únicamente ese original ordinario es recuperable desde la papelera. Las copias temporales se descartan. Se corrige la activación por toque y el click posterior que podía reabrir una nota. [Reproducción y verificación](docs/BORRADO-0.2.1.md).
