# Seguridad y privacidad

## Controles implementados

- Identidad del artista autenticada por el gateway privado de Sites. El backend rechaza peticiones sin identidad y comprueba propietario de sesión. Las cookies de autenticación, su firma, expiración y atributos Secure/HttpOnly/SameSite pertenecen a la plataforma; esta app no crea tokens de login propios. Desarrollo local simulado con cookie HttpOnly/SameSite=Lax y Secure si usa HTTPS; no es autenticación de producción.
- Sesiones de actuación en servidor, máximo dos horas. UUID y CSRF aleatorio, del que solo se conserva SHA-256. Las consultas necesitan propiedad de sesión y CSRF correcto. Creación/borrado exigen Origin igual al origen de la petición y cuerpo JSON; no hay CORS permisivo.
- Autorización antes de cualquier proveedor: selección cerrada, móvil validado en servidor, artista, evidencia previa del titular, alcance, proveedor y vigencia. Demo admite únicamente las dos fichas sintéticas del almacén; nunca hace llamadas a Telegram.
- Detección automática tras 800 ms de estabilidad: solo fichas seleccionadas de una sesión preparada. Una solicitud automática por sesión/nota/número; errores y deshacer no disparan reintentos. Una respuesta reservada permanece exclusivamente en memoria y exige sesión/nota/revisión/generación vigentes al pulsar el gatillo. Cualquier edición la descarta.
- SQL parametrizado. D1 está solo en el servidor y no expone acceso público. No aplica RLS PostgreSQL: el aislamiento se comprueba en cada operación con el ID autenticado del usuario.
- Cinco preparaciones por artista/hora, veinte consultas por artista/hora, cinco por sesión/minuto y diez por sesión. Contadores persistentes D1 y adquisición atómica del turno; una consulta simultánea por sesión. No garantiza una cola global de un bot externo; el proveedor debe implementarla si la necesita.
- Cuerpo entrante limitado por lectura a 32 KB, nota a 20.000 caracteres y respuesta a 8 KB. Normalización duplicada en servidor. Las respuestas exigen requestId/teléfono exactos, `final: true`, campos de texto validados y límites.
- API sin reintentos automáticos, sin redirecciones, con HTTPS y tiempo máximo de 12 s. Resultado tardío descartado; sesión revocada revisada otra vez antes de devolverlo. Un fallo de red puede haber alcanzado el proveedor; no debe repetirse sin comprobar el ID.
- CSP con nonce aleatorio por respuesta, scripts propios y sin `unsafe-inline` en producción. Estilos inline permitidos para variables de viewport; objeto/base/form/frame restringidos. No-store, nosniff, no-referrer y política sin cámara/micrófono/geolocalización. HSTS en HTTPS. En desarrollo se añade `unsafe-eval` y WebSocket para HMR; no forma parte de la política de producción.
- Ningún token de proveedor o registro de consentimiento entra en el cliente. Las API no incluyen detalles del proveedor en errores. Los registros de aplicación emiten exclusivamente códigos de error constantes; no registran excepciones crudas, teléfonos, nombres ni resultados.
- Transporte Telegram opcional: bot propio dedicado, token solo servidor, sin webhook público ni sesiones de cuenta personal. Verificación del bot/conversación antes del envío, bloqueo global D1 por bot, cursor, reply exacto, número y marcador final confirmado; no se responde al proveedor ni se reintenta el envío. Detalles en [TELEGRAM.md](TELEGRAM.md).
- Alternativa solicitada el 12/10/2026: cliente de usuario en proceso Node independiente. Sesión nueva con consentimiento de delegación explícito, API ID/hash del titular, sesión AES-256-GCM, directorio 700/archivo 600, códigos y 2FA no persistidos. Solo admite el teléfono de getMe; no lee otros chats por su lógica. Una sesión MTProto tiene acceso técnico amplio a la cuenta y se revoca en Telegram → Dispositivos, no al borrar una actuación. Bearer solo entre servidores, URL HTTPS, sin CORS, registro durable sin resultados ni teléfonos en claro, límites y RPC sin reintentos. Los riesgos y la separación de hosting se documentan en [bridge/README.md](../bridge/README.md). Está vinculado y activo para el teléfono propio autorizado; el proveedor HTTP actual se ejecuta en Netlify Functions con registro transaccional Postgres compartido, y se comprobó con los procesos del Mac apagados. Sesión y credenciales son secretos de Functions únicamente en production; previews mantienen login de equipo.
- Respuesta renderizada como texto literal dentro del editor. Sin HTML recibido, eval, instrucciones del bot ni enlaces accionables generados por él. Los campos ausentes se omiten. No se presenta la ficha como identidad verificada.

## Datos y retención

| Dato                                                                       | Dónde                                                          | Retención/borrado                                          |
| -------------------------------------------------------------------------- | -------------------------------------------------------------- | ---------------------------------------------------------- |
| Notas ordinarias                                                           | localStorage del dispositivo                                   | Hasta eliminar la nota o los datos del sitio               |
| Notas de actuación y resultados                                            | Memoria de la página                                           | Hasta borrar sesión, reiniciar, caducar, recargar o cerrar |
| Sesión, lista de IDs autorizados, CSRF hash y sal                          | D1 servidor                                                    | Borrado explícito o purga por actividad al caducar         |
| Petición: UUID, nota, revisión, hash salado del teléfono, estado y tiempos | D1 servidor                                                    | Borrado junto a sesión; sin nombres ni respuesta           |
| Registro de consentimiento real                                            | Variable secreta del servidor + evidencia externa del operador | Gestionado según vigencia y política del operador          |
| Datos transmitidos al proveedor                                            | Servicio autorizado/Telegram si el puente lo usa               | Según su política; borrar la app no los elimina            |

No se guarda el texto de la nota en D1. El número se usa en memoria para llamar al proveedor; en metadatos se conserva solo un hash con sal de sesión. El registro real del servidor contiene los teléfonos autorizados y requiere gestión confidencial. La sal no se envía al cliente.

El historial de edición reside solo en memoria, acotado a 50 estados/200.000 caracteres. El peek temporal nunca entra en contenteditable, en el historial, en el texto de Compartir ni en el guardado. Se renderiza como texto seguro en un elemento separado mientras el gesto está activo, y se elimina del DOM al soltar/cancelar, perder foco de ventana o suspender la página. La respuesta reservada queda solo en memoria hasta editar, cambiar contexto, deshacer/descartar o borrar sesión.

El resultado no se persiste siquiera en el servidor: un duplicado devuelve un conflicto, no una copia de la respuesta. La PWA solo guarda recursos públicos estáticos; no hay analítica. Abrir una nota ordinaria durante actuación crea una copia temporal: no convierte ni sobrescribe el original. Compartir una nota es una acción explícita del usuario que puede transmitir su texto mediante el menú nativo.

La purga automática de metadatos es oportunista al preparar sesiones: si no hay actividad, los metadatos vencidos pueden permanecer en D1 hasta el próximo uso. No contienen resultados ni teléfonos en claro. Borrar sesión ejecuta revocación y borrado inmediato en la base activa; copias de seguridad del hosting se rigen por su política. No se promete borrado retroactivo de Telegram, dispositivos receptores, backups o proveedores.

No hay endpoint webhook de Telegram en esta aplicación. Para un puente externo están documentadas las verificaciones que debe implementar su operador; no se afirma que existan sin haberlo probado.

La tabla `telegram_state` conserva cursor y tiempos de transporte independientes de los resultados y de las sesiones. No contiene token, teléfono, nombre ni mensajes. Se mantiene al borrar una sesión para deduplicar respuestas antiguas y conserva el bloqueo/cooldown global del bot. Borrar en la aplicación no elimina mensajes en Telegram. Los nuevos ensayos del transporte utilizan respuestas HTTP simuladas y datos ficticios.

## Instalación fuera de Sites

Las cabeceras `oai-authenticated-user-*` son de confianza únicamente detrás del gateway autenticado de Sites, que las inyecta. Nunca expongas la app detrás de un proxy que permita falsificarlas. Para otro hosting hay que sustituir este límite por autenticación real, cookies firmadas con Secure/HttpOnly/SameSite y control de propiedad equivalente. El preview local no vale para producción.

## Verificación realizada

Se aplicaron parches a React/RSC, imágenes y herramientas. La auditoría de dependencias de producción no detecta avisos conocidos; la auditoría completa conserva 12 entradas en cadenas de construcción/desarrollo sin solución compatible aplicada. El detalle y las mitigaciones están en [PRUEBAS.md](PRUEBAS.md). No se declara una auditoría completa sin incidencias.

Pruebas con dos identidades de servidor bloquean la sesión de otro artista; CSRF falso, números ajenos y revisiones falseadas no llegan al proveedor. Pruebas de navegador verifican el contenido malicioso literal y ausencia de resultados en la clave ordinaria. Revisión del bundle cliente para nombres de secretos. Las cookies del gateway y el iPhone físico requieren comprobación en el entorno publicado/dispositivo; no se atribuyen esas pruebas al simulador.
