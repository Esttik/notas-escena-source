# Bot propio → @TrueCalleRobot

## Estado verificable

El transporte directo está implementado en `lib/server/telegram.ts`. Se ha probado con respuestas HTTP simuladas de Telegram y datos ficticios, incluyendo el servicio de sesión completo. Se ha creado @YOUR_OWN_BOT, habilitado su modo bot-to-bot, guardado el token como secreto de servidor y confirmado el ID del destino. La prueba real de `/start` fue rechazada por Telegram con 400 de comunicación entre bots. Falta aceptación del canal, permiso y protocolo del operador. [Acta de comprobaciones reales](ACTIVACION-TELEGRAM.md). **Ese transporte entre bots no está activado.** La conexión real posterior utiliza una sesión nueva del titular mediante el puente HTTP de cliente de usuario; véanse bridge/README.md y el acta.

La [documentación oficial](https://core.telegram.org/bots/features#bot-to-bot-communication) permite mensajes privados si ambos bots habilitan Bot-to-Bot Communication Mode. En grupos existen condiciones distintas; este adaptador implementa únicamente el canal privado. La compatibilidad de Telegram no demuestra que el servicio destinatario acepte consultas, ni autoriza el tratamiento de sus datos.

## Crear y preparar el bot

1. Usa el [@BotFather oficial](https://t.me/BotFather) con tu cuenta de Telegram. Envía `/newbot`, elige nombre y un usuario libre terminado en `bot`. En este proyecto ya existe **Notas Escena**, usuario **NotasEscenaEsttikBot**; no lo recrees. Si el asistente lo hace desde tu cuenta, necesita tu autorización expresa para enviar esos mensajes y crear el bot.
2. Activa **Bot-to-Bot Communication Mode** en los ajustes de ese bot en BotFather. No puede activarse el mismo ajuste de @TrueCalleRobot desde nuestra cuenta: debe tenerlo habilitado su operador.
3. Dedica el bot exclusivamente a este proyecto y usa su token solo en variables del servidor. No compartas el token en el chat ni lo introduzcas en el navegador de la app. No reutilices un bot con webhook u otro programa que consuma sus actualizaciones. El adaptador detecta un webhook y falla sin borrarlo ni modificarlo.
4. Obtén del operador el ID numérico estable de @TrueCalleRobot, el permiso de consulta y el protocolo de respuesta. Si exige un saludo inicial `/start`, debe prepararse con el bot propio según sus instrucciones; el adaptador no envía comandos de alta, acepta condiciones ni se suscribe a canales automáticamente.
5. Confirma que cada respuesta es un **reply al mensaje que contiene el número** y que incluye `Number: +34…`. Define cómo distingue resultados finales, parciales y sin resultado. Si solo entrega mensajes sueltos sin correlación o no tiene un criterio final verificable, no habilites este adaptador.
6. Da de alta únicamente a titulares previamente verificados y con consentimiento vigente para este proveedor. La ficha se trata como información del proveedor, nunca como identidad acreditada.

El canal que anuncia el bot publica [@OTPless como contacto](https://t.me/s/true_caller). Se le ha enviado la solicitud de compatibilidad con autorización del usuario. Su perfil indica soporte para @true_caller; no se ha acreditado afiliación con Truecaller.

## Variables de servidor

Mantén `PROVIDER_MODE=demo` hasta completar las comprobaciones. Para activar el transporte privado:

```dotenv
PROVIDER_MODE=real
PROVIDER_TRANSPORT=telegram
PROVIDER_AUTHORIZED=true
TELEGRAM_BOT_TOKEN=<token del bot propio>
TELEGRAM_TARGET_USERNAME=TrueCalleRobot
TELEGRAM_TARGET_BOT_ID=<ID numérico confirmado>
TELEGRAM_PROTOCOL_CONFIRMED=true
TELEGRAM_FINAL_SUFFIX=<última línea literal del resultado final confirmada>
TELEGRAM_NO_RESULT_TEXT=<última línea literal de sin resultado confirmada, opcional>
AUTHORIZED_PARTICIPANTS_JSON=<registro confidencial de titulares autorizados>
```

`PROVIDER_AUTHORIZED` y `TELEGRAM_PROTOCOL_CONFIRMED` son condiciones de activación gestionadas por el operador del servidor, no mecanismos que obtengan permiso por sí mismos. No copies el marcador ficticio de las pruebas (`END OF RESULT`) como si fuese el formato del bot real. No se ha supuesto ningún marcador real de la captura. Cada alta del registro debe tener `provider` igual a `telegram:@TrueCalleRobot:<ID numérico confirmado>` y el artista/alcance/fechas/evidencia descritos en [PROVEEDOR.md](PROVEEDOR.md).

En Sites configura estas variables con sus herramientas de servidor y publica una versión que las aplique. En desarrollo se usa `.dev.vars` ignorado. `.env.example` no contiene valores secretos. Un modo real incompleto falla y no se transforma en demo.

## Protocolo y ejecución

Antes de enviar un teléfono se verifica `getMe`, ausencia de webhook con `getWebhookInfo` y que `getChat` del username configurado devuelva el ID privado estable esperado. **Comprobar conexión del bot** en el área del artista realiza solo esas lecturas: no envía teléfonos y no certifica bot-to-bot ni la respuesta del servicio. Si Telegram no permite `getChat` para ese destino todavía, la preparación está incompleta y se falla antes de enviar datos.

Solo después de la autorización del titular/sesión se llama una vez a [`sendMessage`](https://core.telegram.org/bots/api#sendmessage) con el número normalizado y el ID privado fijo, verificando también el ID de la respuesta. Así un cambio de propietario del username no cambia el destinatario de los datos. Ese envío por ID debe comprobarse con el servicio antes de activar; el saludo de diagnóstico se realizó por username, sin teléfonos, y fue rechazado. Se recibe mediante [`getUpdates`](https://core.telegram.org/bots/api#getupdates), exclusivamente mientras dura esa consulta HTTP. No hay webhook público, apertura de Telegram, portapapeles durante actuación ni proceso continuo cuando la PWA se suspende.

Una fila D1 por bot controla turno global, cursor de actualización y espera por límites. El turno es atómico, abarca distintas sesiones/artistas y permanece estable al rotar el token. Una segunda consulta recibe conflicto sin enviar; no se acumula una cola de números. Máximo ocho lecturas por consulta, long polling de dos segundos y pausa de 300 ms entre lotes; el servicio impone un máximo de 12 segundos y aborta la lectura. No se reintenta un envío fallido: Telegram no admite nuestra clave de idempotencia en `sendMessage`.

Solo se acepta `message` cuyo `from.id` sea el bot esperado y `is_bot=true`, conversación privada fija, `reply_to_message.message_id` igual al mensaje enviado y `Number` coincidente. Las actualizaciones repetidas y respuestas antiguas se descartan con el cursor/correlación. Un mensaje sin el marcador final sigue pendiente; una respuesta con número distinto o campos duplicados se rechaza. No se responde al bot automáticamente, evitando bucles.

Parser de texto: etiquetas literales `Number`, `Country`, `Carrier`, `Name`; campos opcionales y acotados. El marcador final debe ser la última línea literal no vacía. El estado sin resultado requiere igualmente `Number` y el marcador de ausencia configurado. No se aceptan formatos inferidos, mensajes editados posteriores, respuestas distribuidas en varios fragmentos sin un mensaje final completo ni resultados basados en «el último mensaje». Si el operador tiene otro protocolo, hay que adaptar y volver a probar el parser.

## Privacidad y limitaciones

No se persisten textos ni resultados Telegram. La tabla de transporte guarda solo un identificador derivado del ID del bot propio, cursor, UUID de petición temporal y tiempos; no contiene token, número, nombre o respuesta. Es metadato técnico independiente de las sesiones y permanece tras borrarlas para descartar actualizaciones antiguas. El resultado vive en memoria y está vinculado a la sesión, nota, número y revisión existentes.

Las respuestas JSON de Telegram se limitan a 128 KiB por lote; el mensaje aceptado a 8 KiB y los campos a 200 caracteres. Los errores externos no revelan descripciones crudas, URLs que incluyen el token, nombres o teléfonos. Un 429 conserva `retry_after` en D1; los conflictos de consumidor y configuración se muestran con códigos seguros. No actives registro de URLs salientes: el token forma parte del endpoint exigido por Telegram.

Borrar sesión en la app no borra mensajes que conserven Telegram o el servicio de destino. No hay eliminación remota automática; la retención externa debe acordarse antes de utilizar datos personales.

## Acta necesaria para activar

Con un titular autorizado y configuración del operador: comprobar capacidad bot-to-bot efectiva, envío único de +34, ID de origen/conversación, reply y marcador final reales, campos disponibles, latencia/timeout, duplicados/parciales/tardíos, borrado y límites. El informe actual acredita el transporte con respuestas simuladas, no esa acta.
