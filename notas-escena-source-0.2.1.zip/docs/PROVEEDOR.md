# Activar una integración real compatible

## Estado actual — 12/10/2026

Por petición expresa posterior se implementó un cliente de usuario con sesión nueva autorizada, separado de la PWA. El titular introdujo personalmente sus códigos en el asistente local; se verificaron cuenta, teléfono propio y bot fijo. Se completó una consulta real y su inserción desde el sitio publicado mediante el adaptador HTTP. La vía entre bots sigue rechazada y no se presenta como funcional.

El puente Node se ejecuta en el Mac mediante HTTPS temporal. Hace falta hosting permanente para disponibilidad continua y comprobar iPhone/Safari/PWA física. Solo está autorizado el teléfono propio vinculado. No se acredita afiliación con Truecaller ni permiso comercial del operador. [Instalación y límites del puente](../bridge/README.md), [evidencia](ACTIVACION-TELEGRAM.md).

## Estado histórico de la vía entre bots — 11/10/2026

Estado al 11/10/2026: no se han recibido credenciales, permisos ni especificación de @TrueCalleRobot. Su [página pública](https://t.me/TrueCalleRobot) se presenta como Truecaller, pero no proporciona un token, API ni prueba de afiliación. No se ha comprobado la capacidad interna del bot ni se le han enviado consultas reales.

La [Bot API actual](https://core.telegram.org/bots/api) documenta comunicación privada entre bots si **ambos** la habilitan. En grupos hay otras condiciones. Crear un bot propio no concede ese permiso ni control sobre otro. La documentación de funciones/API debe priorizarse frente a reglas históricas de la FAQ.

La aplicación incluye API HTTP autorizada y transporte Telegram directo con un bot propio dedicado, elegido por el usuario. El transporte directo está implementado y probado con respuestas simuladas, pero sigue sin activar: el bot propio, secreto e ID están preparados, pero el saludo bot-to-bot real fue rechazado. Faltan aceptación del canal, permisos y protocolo confirmado; véase el [acta](ACTIVACION-TELEGRAM.md). [Crear, configurar y verificar el bot propio](TELEGRAM.md). Esta vía no utiliza sesiones de usuario. La alternativa posterior sí usa una sesión nueva autorizada; nunca se extraen sesiones existentes.

## Datos que faltan

- URL HTTPS de la API y token concedido por su operador.
- Confirmación contractual de permiso para consultar los participantes y de su política de retención.
- Protocolo que devuelva `requestId`, `phone`, `final` y estado `found`.
- Si es puente de Telegram: bot emisor propio, permiso bot-to-bot de ambos, ID numérico del bot destinatario, conversación fija, forma de respuesta/reply y pruebas del protocolo.
- Registro previo del titular: evidencia de verificación de titularidad y consentimiento específico vigente para este proveedor; conocer el número o marcar una casilla del artista no lo sustituye.

## Contrato implementado

Petición desde el servidor, nunca desde el navegador:

```http
POST /your-authorized-api/lookup
Authorization: Bearer <SERVER_TOKEN>
Content-Type: application/json
Idempotency-Key: <requestId>
```

```json
{ "requestId": "UUID", "phone": "+34600000001", "sessionId": "UUID" }
```

El proveedor debe aceptar únicamente ese envío autorizado y usar `Idempotency-Key` para no duplicar operaciones. La respuesta final tiene que devolver exactamente la correlación:

```json
{
  "requestId": "UUID",
  "phone": "+34600000001",
  "final": true,
  "found": true,
  "country": "España",
  "carrier": "Operador autorizado",
  "name": "Dato autorizado del proveedor"
}
```

Los campos país, operador y nombre son opcionales. Nunca se inventan campos ausentes. Para ausencia de resultado: `final: true, found: false`. Un mensaje `final: false` se rechaza como parcial; el puente debe esperar y devolver un resultado final, no exponer fragmentos sueltos. Solo se usan los campos validados; enlaces, HTML, instrucciones y campos adicionales no se ejecutan.

Límite de respuesta: 8 KB; 200 caracteres por campo. Sin redirecciones. Tiempo máximo: 12 s. No hay reintentos automáticos de peticiones POST; un error de red puede producir una consulta en el servicio que no llegó a mostrarse. El artista ve el identificador en diagnóstico y puede contrastarlo con el proveedor antes de iniciar otra.

Variables de servidor:

```dotenv
PROVIDER_MODE=real
PROVIDER_API_URL=https://your-authorized-api.example/lookup
PROVIDER_API_TOKEN=<secret>
PROVIDER_AUTHORIZED=true
AUTHORIZED_PARTICIPANTS_JSON=<server-only-vetted-registry>
```

No actives modo real hasta tener acceso y permiso. Una configuración real incompleta falla de forma explícita y no se convierte silenciosamente en demo.

## Registro de autorizaciones

Cada entrada es gestionada por un operador de confianza del servidor. No hay formulario que permita a un espectador o artista autorizar el número de otra persona.

```json
[
  {
    "id": "participant-authorized",
    "label": "Participante registrado",
    "phone": "+34…",
    "artistId": "ID de identidad del artista en este Site",
    "consentRef": "referencia de la evidencia verificada",
    "ownershipVerifiedAt": "fecha ISO de verificación",
    "expiresAt": "fecha ISO futura",
    "scope": "lookup",
    "provider": "URL exacta configurada en PROVIDER_API_URL"
  }
]
```

Este ejemplo es estructural: el teléfono incompleto se rechaza. Obtén el `artistId` en el área del artista. El servidor valida artista, formato, alcance, fecha, consentimiento, proveedor y selección para la sesión. El registro solo afirma evidencia preexistente: la aplicación no verifica SMS, identidad o titularidad por sí misma. Ese proceso tiene que realizarse antes del alta. Mantén la evidencia fuera del navegador y limita sus accesos.

## Reglas del puente Telegram

No existe webhook Telegram en esta app. El transporte directo usa getUpdates desde el servidor durante la consulta, con bloqueo global D1 y reply correlacionado. Las siguientes reglas de webhook solo aplican si se construye un puente externo independiente. **Nunca** uses «el último mensaje recibido».

Si implementas el puente bajo tu control:

1. Configura `setWebhook.secret_token` y verifica `X-Telegram-Bot-Api-Secret-Token` con comparación constante, además de `from.id` y `chat.id` numéricos fijados en el servidor. El nombre visible no es verificación de origen. No registres el token ni el texto.
2. Deduplica `update_id` y `message_id`. Acepta solo respuestas vinculadas mediante `reply_to_message.message_id` al mensaje enviado o mediante ID devuelto por el contrato autorizado. Rechaza respuestas antiguas, parciales y conversaciones ajenas.
3. Si el protocolo no permite correlación, serializa **globalmente en el puente**. Una consulta por sesión en esta app no sustituye una cola global para un bot compartido. Si ni siquiera con serialización puede distinguirse una respuesta tardía, no habilites ese protocolo.
4. No contestes automáticamente a los mensajes del bot proveedor: de esa forma no creas un bucle entre bots. No vuelvas a enviar una consulta por repetición de webhook.
5. Respeta `retry_after`, límites del proveedor y TTL. Usa almacenamiento duradero para correlación y borrado según su política; una variable en memoria de un Worker no sirve como cola global.

La [documentación de setWebhook](https://core.telegram.org/bots/api#setwebhook) describe el secreto de origen. Este documento es el contrato del adaptador y los requisitos pendientes; no describe el puente MTProto, documentado y probado por separado.

## Prueba de activación

Con un titular previamente autorizado, comprueba envío único de +34, respuesta de origen/conversación fijados, correlación real, duplicados, mensajes tardíos, errores, límites, borrado y representación segura en la nota. Conserva un acta sin datos personales. Solo después puede afirmarse «integración real comprobada».
