# Referencias y fidelidad visual

Se analizaron las tres capturas suministradas antes de la implementación; ninguna se usa como fuente de instrucciones, credenciales o datos de ejemplo.

| Referencia | Reproducción                                                                                                                                                                                                            |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| IMG_5357   | Fondo gris muy claro, cabecera centrada Notas/recuento real, botones blancos circulares, secciones por fechas, tarjetas blancas con radios amplios, separadores interiores y buscador inferior translúcido con creación |
| IMG_5358   | Editor blanco, texto gris, primera línea grande y negrita, caret amarillo, controles flotantes de navegación/deshacer/compartir/opciones/finalizar y barra de herramientas redondeada                                   |
| IMG_5360   | Estructura Número/País/Operador/Nombre. Solo se incluyen campos presentes y autorizados; no se copia el chat, enlaces ni datos personales                                                                               |

La tipografía utiliza la familia de sistema de Apple en iPhone, tamaños relativos y zoom permitido. Los espaciados son móviles, con adaptación a pantallas grandes. Los controles tienen etiquetas accesibles; los principales alcanzan 44 px y se respeta movimiento reducido.

## Diferencias inevitables o deliberadas

- No se dibuja hora, batería, cobertura o barra de estado. iOS y Safari/PWA proporcionan sus áreas seguras; la emulación de escritorio no aporta la barra de estado del dispositivo.
- El teclado es el nativo y su idioma, distribución, sugerencias y acciones pertenecen al sistema. No se reproduce el teclado de la imagen.
- SVG propios similares a los iconos; no se distribuyen SF Symbols nativos. Desenfoque, sombra y materiales aproximan el cristal, pero no tienen el motor nativo de iOS.
- Eslabones inmediatamente después del lápiz circular. Se omite el símbolo de dibujo de la captura para priorizar el orden solicitado.
- Sin miniaturas personales, adjuntos de las capturas, bloqueos, iCloud o número ficticio de 76 notas. Las tarjetas contienen exclusivamente notas inventadas y el recuento refleja las existentes.
- Buscador inferior funcional sin micrófono decorativo; el dictado puede utilizarse mediante el teclado del sistema. Compartir usa Web Share si existe; el navegador que no lo soporte muestra la limitación.
- Tabla, lista y adjunto son texto plano. El lápiz abre opciones de escritura. No se implementan dibujo, escáner, edición colaborativa, tablas nativas ni bloqueo de notas.
- Primera línea destacada por CSS `::first-line`: una primera línea muy larga que envuelva puede no comportarse como un bloque de título nativo de Notas. El editor preserva el texto y selección.
- Los resultados se muestran como una vista temporal bajo el texto solo mientras se mantienen pulsados los eslabones. No se incorporan al contenido editable ni al historial de la nota. Puede verlos quien mire la pantalla durante la pulsación.
- VisualViewport y safe areas ajustan la barra al espacio disponible. El comportamiento de suspensión, zoom, desplazamiento y foco del teclado iOS requiere ensayo físico. La app no puede garantizar comportamiento nativo idéntico.

Las capturas de Chromium/WebKit muestran un diseño próximo en composición y jerarquía. No se declara equivalencia píxel a píxel ni prueba visual en un iPhone físico. El contraste de textos auxiliares se prioriza frente al gris más tenue de la referencia.

## Ajustes de auditoría 0.2.0

Fondo #f2f2f6, márgenes de tarjeta 20 px, radio 26 px y alineación interior recalibrados. Cabecera respeta safe area sin añadir el margen superior anterior; geometría física pendiente. Botones principales al menos 44×44 px; texto ampliado, foco por teclado y buscador ajustado a VisualViewport. Capturas locales comparables con contenido ficticio en 320/390/430 y escritorio; no se expresa la fidelidad como un porcentaje ni identidad píxel a píxel. Papelera y gestos implementados para notas ordinarias; las limitaciones nativas anteriores siguen explícitas.
