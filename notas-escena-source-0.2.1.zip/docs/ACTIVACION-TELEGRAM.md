# Documento de comprobación local

El informe histórico de la instalación privada se omite en esta copia pública. El código y las pruebas reproducibles están incluidos. No se publican identificadores, resultados, permisos de cuenta ni evidencias de producción.
