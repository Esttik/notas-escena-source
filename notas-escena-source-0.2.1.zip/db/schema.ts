import {
  sqliteTable,
  text,
  integer,
  index,
  check,
} from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
export const sessions = sqliteTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    csrf: text("csrf").notNull(),
    salt: text("salt").notNull(),
    mode: text("mode").notNull(),
    participants: text("participants").notNull(),
    created: integer("created").notNull(),
    expires: integer("expires").notNull(),
    revoked: integer("revoked").notNull().default(0),
    queryCount: integer("query_count").notNull().default(0),
    activeQuery: text("active_query"),
    lease: integer("lease").notNull().default(0),
  },
  (t) => [
    index("session_user").on(t.userId),
    check("participant_size", sql`length(${t.participants}) <= 4096`),
  ],
);
export const queries = sqliteTable(
  "queries",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    noteId: text("note_id").notNull(),
    revision: text("revision").notNull(),
    phoneHash: text("phone_hash").notNull(),
    status: text("status").notNull(),
    code: text("code"),
    created: integer("created").notNull(),
    providerMs: integer("provider_ms"),
  },
  (t) => [index("query_session").on(t.sessionId)],
);
export const limits = sqliteTable("limits", {
  id: text("id").primaryKey(),
  count: integer("count").notNull(),
  expires: integer("expires").notNull(),
});
export const telegramState = sqliteTable("telegram_state", {
  id: text("id").primaryKey(),
  cursor: integer("cursor").notNull().default(0),
  lease: integer("lease").notNull().default(0),
  requestId: text("request_id"),
  cooldownUntil: integer("cooldown_until").notNull().default(0),
});
