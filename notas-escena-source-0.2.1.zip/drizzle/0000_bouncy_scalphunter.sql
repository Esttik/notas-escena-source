CREATE TABLE `limits` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `queries` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`note_id` text NOT NULL,
	`revision` text NOT NULL,
	`phone_hash` text NOT NULL,
	`status` text NOT NULL,
	`code` text,
	`created` integer NOT NULL,
	`provider_ms` integer
);
--> statement-breakpoint
CREATE INDEX `query_session` ON `queries` (`session_id`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`csrf` text NOT NULL,
	`salt` text NOT NULL,
	`mode` text NOT NULL,
	`participants` text NOT NULL,
	`created` integer NOT NULL,
	`expires` integer NOT NULL,
	`revoked` integer DEFAULT 0 NOT NULL,
	`query_count` integer DEFAULT 0 NOT NULL,
	`active_query` text,
	`lease` integer DEFAULT 0 NOT NULL,
	CONSTRAINT "participant_size" CHECK(length("sessions"."participants") <= 4096)
);
--> statement-breakpoint
CREATE INDEX `session_user` ON `sessions` (`user_id`);