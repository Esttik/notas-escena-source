CREATE TABLE `telegram_state` (
	`id` text PRIMARY KEY NOT NULL,
	`cursor` integer DEFAULT 0 NOT NULL,
	`lease` integer DEFAULT 0 NOT NULL,
	`request_id` text,
	`cooldown_until` integer DEFAULT 0 NOT NULL
);
