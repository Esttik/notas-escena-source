import { readFileSync, readdirSync, mkdirSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { join } from "node:path";
const out = process.argv[2];
if (!out) throw Error("Specify a fresh audit output directory");
mkdirSync(out, { recursive: true });
const files = [],
  actions = [];
function scan(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    const path = join(dir, entry.name);
    if (entry.isDirectory()) scan(path);
    else if (/\.(tsx?|mts|css|js|json)$/.test(path) && !path.includes("/ui/")) {
      const source = readFileSync(path, "utf8");
      files.push({
        path,
        sha256: createHash("sha256").update(source).digest("hex"),
      });
      for (const match of source.matchAll(/aria-label="([^"]+)"/g))
        actions.push({ source: path, label: match[1], status: "PENDIENTE" });
    }
  }
}
for (const dir of [
  "app",
  "components",
  "lib",
  "public",
  "bridge/src",
  "bridge/netlify/functions",
])
  scan(dir);
const commit = execFileSync("git", ["rev-parse", "HEAD"], {
  encoding: "utf8",
}).trim();
writeFileSync(
  join(out, "identity.json"),
  JSON.stringify(
    {
      commit,
      files,
      staticActions: actions,
      note: "React/Vinext static candidates; expand with live DOM and transition tests. The skill public/index.html inventory is incompatible with this SSR project. No credentials, DB records or personal content collected.",
    },
    null,
    2,
  ),
);
console.log(
  JSON.stringify({
    commit,
    sourceFiles: files.length,
    staticCandidates: actions.length,
    output: out,
  }),
);
