// Only disposable loopback preview data. Never uses a hosted D1 connection.
import { readdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
const origin = new URL(process.env.TEST_BASE_URL ?? "http://127.0.0.1:5176");
if (!["127.0.0.1", "localhost", "[::1]"].includes(origin.hostname))
  throw new Error(
    "Browser suite requires a loopback preview; local test reset refused.",
  );
const root = ".wrangler/state/v3/d1";
function visit(dir) {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, entry.name);
    if (entry.isDirectory()) visit(p);
    else if (entry.name.endsWith(".sqlite")) {
      const db = new DatabaseSync(p);
      try {
        if (
          db
            .prepare("SELECT name FROM sqlite_master WHERE name='sessions'")
            .get()
        ) {
          db.exec(
            "DELETE FROM queries; DELETE FROM sessions; DELETE FROM limits;",
          );
        }
      } finally {
        db.close();
      }
    }
  }
}
visit(root);
console.log("Disposable local test sessions reset.");
