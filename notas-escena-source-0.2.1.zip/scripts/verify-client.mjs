import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
let files = 0;
function check(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) check(p);
    else if (/\.(js|html|css|json)$/.test(name)) {
      files++;
      const s = readFileSync(p, "utf8");
      for (const marker of [
        "PROVIDER_API_TOKEN",
        "TELEGRAM_BOT_TOKEN",
        "AUTHORIZED_PARTICIPANTS_JSON",
        "test-only-secret",
        "service_role",
      ])
        if (s.includes(marker))
          throw new Error(`Server-only marker in client artifact: ${marker}`);
    }
  }
}
check("dist/client");
console.log(
  `Checked ${files} client files: no provider secrets or server registry markers.`,
);
