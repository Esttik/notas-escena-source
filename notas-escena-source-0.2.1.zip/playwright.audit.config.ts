import { defineConfig, devices } from "playwright/test";
const baseURL = process.env.AUDIT_BASE_URL ?? "http://127.0.0.1:5178";
if (!["127.0.0.1", "localhost"].includes(new URL(baseURL).hostname)) {
  throw new Error(
    "Audit requires an isolated loopback server; synthetic authentication is never sent to a hosted site.",
  );
}
export default defineConfig({
  testDir: "./tests/audit",
  timeout: 60000,
  workers: 1,
  outputDir: process.env.AUDIT_OUTPUT ?? "outputs/auditoria-20261012/runtime",
  reporter: [
    ["list"],
    [
      "json",
      {
        outputFile: `${process.env.AUDIT_OUTPUT ?? "outputs/auditoria-20261012/runtime"}/results.json`,
      },
    ],
  ],
  use: {
    baseURL,
    trace: "retain-on-failure",
    extraHTTPHeaders: {
      "oai-authenticated-user-id": "audit-loopback-only",
      "oai-authenticated-user-email": "audit@fiction.invalid",
    },
  },
  projects: ["chromium", "webkit"].flatMap((browserName) =>
    [320, 390, 430, 1280].map((width) => ({
      name: `${browserName}-${width}`,
      use: {
        ...(width < 1000 ? devices["iPhone 13"] : {}),
        browserName: browserName as "chromium" | "webkit",
        viewport: { width, height: width < 1000 ? 844 : 900 },
      },
    })),
  ),
});
