import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import {
  mkdirSync,
  chmodSync,
  readFileSync,
  writeFileSync,
  renameSync,
  lstatSync,
} from "node:fs";
import { join } from "node:path";
import { BridgeError } from "./errors.ts";
function key(value: string) {
  const bytes = Buffer.from(value, "base64");
  if (bytes.length !== 32) throw new BridgeError("VAULT_KEY", 503);
  return bytes;
}
export function seal(value: string, encodedKey: string): string {
  const iv = randomBytes(12),
    cipher = createCipheriv("aes-256-gcm", key(encodedKey), iv);
  const data = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return JSON.stringify({
    v: 1,
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64"),
    data: data.toString("base64"),
  });
}
export function unseal(value: string, encodedKey: string): string {
  try {
    const v = JSON.parse(value);
    if (
      v.v !== 1 ||
      typeof v.iv !== "string" ||
      typeof v.tag !== "string" ||
      typeof v.data !== "string" ||
      value.length > 20000
    )
      throw new Error();
    const decipher = createDecipheriv(
      "aes-256-gcm",
      key(encodedKey),
      Buffer.from(v.iv, "base64"),
    );
    decipher.setAuthTag(Buffer.from(v.tag, "base64"));
    return Buffer.concat([
      decipher.update(Buffer.from(v.data, "base64")),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    throw new BridgeError("VAULT_INVALID", 503);
  }
}
export function stateDirectory() {
  const path = process.env.BRIDGE_STATE_DIR || ".bridge-state";
  mkdirSync(path, { recursive: true, mode: 0o700 });
  if (lstatSync(path).isSymbolicLink())
    throw new BridgeError("STATE_PATH", 503);
  chmodSync(path, 0o700);
  return path;
}
export function saveSession(session: string, encodedKey: string) {
  const dir = stateDirectory(),
    temporary = join(dir, "session.new");
  writeFileSync(temporary, seal(session, encodedKey), {
    mode: 0o600,
    flag: "wx",
  });
  renameSync(temporary, join(dir, "session.enc"));
  chmodSync(join(dir, "session.enc"), 0o600);
}
export function loadSession(encodedKey: string) {
  const path = join(stateDirectory(), "session.enc");
  if (lstatSync(path).isSymbolicLink() || lstatSync(path).mode & 0o077)
    throw new BridgeError("SESSION_PERMISSIONS", 503);
  return unseal(readFileSync(path, "utf8"), encodedKey);
}
