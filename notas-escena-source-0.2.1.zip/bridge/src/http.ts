import type { IncomingMessage, ServerResponse } from "node:http";
import { createHash, timingSafeEqual } from "node:crypto";
import {
  AppError,
  normalizePhone,
  validateResult,
  type QueryResult,
} from "../../lib/domain.ts";
import { BridgeError } from "./errors.ts";
type Input = { requestId: string; sessionId: string; phone: string };
type Lookup = {
  lookup(input: Input, signal: AbortSignal): Promise<QueryResult>;
};
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function body(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks: Buffer[] = [];
    req.on("data", (chunk: Buffer) => {
      size += chunk.length;
      if (size > 2048) {
        reject(new BridgeError("BODY_LIMIT", 413));
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", () => reject(new BridgeError("INPUT", 400)));
  });
}
function send(res: ServerResponse, status: number, value: unknown) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
  });
  res.end(JSON.stringify(value));
}
export function createHandler(engine: Lookup, secret: string) {
  if (secret.length < 40) throw new BridgeError("BEARER_CONFIG", 503);
  const expected = createHash("sha256").update(`Bearer ${secret}`).digest();
  return async (req: IncomingMessage, res: ServerResponse) => {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 11000);
    res.on("close", () => {
      if (!res.writableEnded) abort.abort();
    });
    try {
      if (req.method === "GET" && req.url === "/health") {
        send(res, 200, { ok: true, service: "telegram-user-bridge" });
        return;
      }
      const supplied = createHash("sha256")
        .update(req.headers.authorization ?? "")
        .digest();
      if (!timingSafeEqual(supplied, expected))
        throw new BridgeError("UNAUTHORIZED", 401);
      if (req.headers.origin) throw new BridgeError("ORIGIN", 403);
      if (req.method !== "POST" || req.url !== "/lookup")
        throw new BridgeError("NOT_FOUND", 404);
      if (req.headers["content-type"] !== "application/json")
        throw new BridgeError("CONTENT_TYPE", 415);
      if (Number(req.headers["content-length"]) > 2048) {
        req.resume();
        throw new BridgeError("BODY_LIMIT", 413);
      }
      let value: unknown;
      try {
        value = JSON.parse(await body(req));
      } catch (e) {
        if (e instanceof BridgeError) throw e;
        throw new BridgeError("INPUT", 400);
      }
      if (!value || typeof value !== "object" || Array.isArray(value))
        throw new BridgeError("INPUT", 400);
      const input = value as Input;
      if (
        Object.keys(value).sort().join(",") !== "phone,requestId,sessionId" ||
        typeof input.phone !== "string" ||
        typeof input.requestId !== "string" ||
        typeof input.sessionId !== "string" ||
        !UUID.test(input.requestId) ||
        !UUID.test(input.sessionId) ||
        req.headers["idempotency-key"] !== input.requestId ||
        normalizePhone(input.phone) !== input.phone
      )
        throw new BridgeError("INPUT", 400);
      const result = await engine.lookup(input, abort.signal);
      if (abort.signal.aborted) throw new BridgeError("TIMEOUT", 504);
      send(res, 200, validateResult(result, input.requestId, input.phone));
    } catch (error) {
      const e =
        error instanceof BridgeError
          ? error
          : error instanceof AppError
            ? new BridgeError(error.code, error.status)
            : new BridgeError("INTERNAL", 500);
      if (!res.destroyed)
        send(res, e.status, {
          code: e.code,
          error:
            "No se pudo completar la consulta. Revisa el diagnóstico del servidor.",
        });
    } finally {
      clearTimeout(timer);
    }
  };
}
