import { createServer } from "node:http";
import { join } from "node:path";
import { chmodSync } from "node:fs";
import { makeClient, UserTransport } from "./telegram-client.ts";
import { stateDirectory, loadSession } from "./vault.ts";
import { Ledger } from "./ledger.ts";
import { BridgeEngine } from "./engine.ts";
import { BridgeError } from "./errors.ts";
import { createHandler } from "./http.ts";
async function main() {
  const key = process.env.BRIDGE_ENCRYPTION_KEY ?? "",
    secret = process.env.BRIDGE_BEARER_TOKEN ?? "";
  if (secret.length < 40) throw new BridgeError("BEARER_CONFIG", 503);
  const host = process.env.BRIDGE_HOST || "127.0.0.1",
    port = Number(process.env.PORT || 8788);
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535)
    throw new BridgeError("PORT_CONFIG", 503);
  const client = makeClient(loadSession(key));
  const dbPath = join(stateDirectory(), "ledger.sqlite"),
    ledger = new Ledger(dbPath, secret);
  chmodSync(dbPath, 0o600);
  let engine: BridgeEngine;
  try {
    engine = new BridgeEngine(new UserTransport(client), ledger, {
      finalSuffix: process.env.TELEGRAM_FINAL_SUFFIX ?? "",
      noResultText: process.env.TELEGRAM_NO_RESULT_TEXT,
    });
    await client.connect();
  } catch (e) {
    ledger.close();
    await client.disconnect();
    throw e;
  }
  const server = createServer(createHandler(engine, secret));
  server.requestTimeout = 12000;
  server.headersTimeout = 5000;
  server.maxHeadersCount = 30;
  server.keepAliveTimeout = 5000;
  server.listen(port, host, () =>
    console.log(
      `Puente disponible en ${host}:${port}. No expongas este puerto sin HTTPS.`,
    ),
  );
  server.on("error", () => {
    console.error("BRIDGE_LISTEN");
    process.exitCode = 1;
    void client.disconnect();
    ledger.close();
  });
  const stop = () => {
    server.closeAllConnections();
    server.close(() => {
      ledger.close();
      void client.disconnect().finally(() => process.exit(0));
    });
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
}
main().catch((e) => {
  console.error(e instanceof BridgeError ? e.code : "BRIDGE_START");
  process.exitCode = 1;
});
