import { BridgeError, loginError } from "./errors.ts";

export class LoginChallenge {
  id = 0;
  kind: "code" | "password" = "code";
  length: number | undefined;
  delivery = "app";
  error = "";
  failures = 0;
  pending: {
    resolve: (value: string) => void;
    reject: (error: Error) => void;
  } | null = null;

  wait(kind: "code" | "password", length?: number, delivery = "app") {
    if (this.pending) throw new BridgeError("CHALLENGE_BUSY", 409);
    this.kind = kind;
    this.length =
      Number.isSafeInteger(length) && length! > 0 && length! <= 20
        ? length
        : undefined;
    this.delivery = ["app", "sms", "call"].includes(delivery)
      ? delivery
      : "other";
    this.id++;
    return new Promise<string>((resolve, reject) => {
      this.pending = { resolve, reject };
    });
  }

  submit(id: unknown, value: unknown) {
    if (!this.pending || id !== this.id)
      throw new BridgeError("STALE_CHALLENGE", 409);
    if (typeof value !== "string" || !value || value.length > 511)
      throw new BridgeError("INPUT", 400);
    if (this.kind === "code") {
      value = value.trim().replace(/[ -]/g, "");
      if (
        !/^\d+$/.test(value as string) ||
        (this.length && (value as string).length !== this.length)
      )
        throw new BridgeError("CODE_FORMAT", 400);
    }
    const pending = this.pending;
    this.pending = null;
    this.error = "";
    pending.resolve(value as string);
  }

  recover(error: unknown) {
    const safe = loginError(error);
    if (
      ![
        "PHONE_CODE_INVALID",
        "PHONE_CODE_EMPTY",
        "PASSWORD_HASH_INVALID",
      ].includes(safe.code) ||
      ++this.failures >= 3
    )
      throw safe;
    this.error = safe.code;
  }

  cancel() {
    const pending = this.pending;
    this.pending = null;
    pending?.reject(new BridgeError("LOGIN_TIMEOUT", 504));
  }
}
