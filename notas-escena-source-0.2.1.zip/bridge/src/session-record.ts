import type { TelegramClient } from "teleproto";
import { randomUUID } from "node:crypto";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { normalizePhone } from "../../lib/domain.ts";
import { saveSession, stateDirectory } from "./vault.ts";
import { BridgeError } from "./errors.ts";
export async function recordSession(client: TelegramClient, phone: string) {
  const me = await client.getMe();
  if (me.bot || !me.phone || normalizePhone("+" + me.phone) !== phone)
    throw new BridgeError("ACCOUNT_MISMATCH", 403);
  const session = client.session.save();
  if (typeof session !== "string" || !session)
    throw new BridgeError("SESSION_SAVE", 503);
  saveSession(session, process.env.BRIDGE_ENCRYPTION_KEY ?? "");
  const holder = {
    phone,
    consentRef: "owner-login:" + randomUUID(),
    ownershipVerifiedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 7 * 86400000).toISOString(),
    scope: "lookup",
  };
  writeFileSync(join(stateDirectory(), "holder.json"), JSON.stringify(holder), {
    mode: 0o600,
  });
}
