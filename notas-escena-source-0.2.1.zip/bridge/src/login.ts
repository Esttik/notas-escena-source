import { randomBytes, randomUUID } from "node:crypto";
import { readFileSync, writeFileSync, chmodSync, existsSync } from "node:fs";
import { join } from "node:path";
import { normalizePhone } from "../../lib/domain.ts";
import { makeClient } from "./telegram-client.ts";
import { saveSession, stateDirectory } from "./vault.ts";
import { BridgeError, loginError } from "./errors.ts";
export async function hiddenInput(label: string): Promise<string> {
  if (!process.stdin.isTTY)
    throw new BridgeError("INTERACTIVE_TERMINAL_REQUIRED", 503);
  process.stdout.write(label);
  process.stdin.setRawMode(true);
  process.stdin.resume();
  return new Promise((resolve, reject) => {
    let value = "";
    const done = () => {
      process.stdin.off("data", data);
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdout.write("\n");
    };
    const data = (chunk: Buffer) => {
      for (const char of chunk.toString("utf8")) {
        if (char === "\u0003") {
          done();
          reject(new BridgeError("LOGIN_CANCELLED", 400));
          return;
        }
        if (char === "\r" || char === "\n") {
          done();
          resolve(value);
          return;
        }
        if (char === "\u007f" || char === "\b") value = value.slice(0, -1);
        else if (char >= " " && value.length < 512) value += char;
      }
    };
    process.stdin.on("data", data);
  });
}
function saveEnvironment(values: Record<string, string>) {
  let original = existsSync(".env") ? readFileSync(".env", "utf8") : "";
  for (const [name, value] of Object.entries(values)) {
    original = original.replace(new RegExp(`^${name}=.*(?:\\n|$)`, "gm"), "");
    original += `\n${name}=${JSON.stringify(value)}\n`;
    process.env[name] = value;
  }
  writeFileSync(".env", original, { mode: 0o600 });
  chmodSync(".env", 0o600);
}
async function main() {
  console.log(
    "Vincular una sesión NUEVA de tu cuenta de Telegram al puente propio. La API de usuario permite acceso amplio a tu cuenta; este programa solo consulta @TrueCalleRobot y tu teléfono. Puedes revocarla en Telegram → Ajustes → Dispositivos. No se extrae ninguna sesión existente.",
  );
  const consent = await hiddenInput(
    "Para autorizar esta sesión y la consulta de tu propio teléfono, escribe AUTORIZO: ",
  );
  if (consent !== "AUTORIZO") throw new BridgeError("LOGIN_CANCELLED", 400);
  const apiId =
    process.env.TELEGRAM_API_ID ||
    (await hiddenInput("API ID de my.telegram.org (entrada oculta): "));
  const apiHash =
    process.env.TELEGRAM_API_HASH ||
    (await hiddenInput("API hash de my.telegram.org (entrada oculta): "));
  if (!/^\d+$/.test(apiId) || !/^[a-f0-9]{32}$/i.test(apiHash))
    throw new BridgeError("APPLICATION_CREDENTIALS", 400);
  const phone = normalizePhone(
    await hiddenInput("Tu móvil español, con +34 (entrada oculta): "),
  );
  const encryptionKey =
    process.env.BRIDGE_ENCRYPTION_KEY || randomBytes(32).toString("base64");
  saveEnvironment({
    TELEGRAM_API_ID: apiId,
    TELEGRAM_API_HASH: apiHash,
    BRIDGE_ENCRYPTION_KEY: encryptionKey,
    BRIDGE_BEARER_TOKEN:
      process.env.BRIDGE_BEARER_TOKEN || randomBytes(32).toString("hex"),
  });
  const client = makeClient("", true);
  try {
    await client.start({
      phoneNumber: async () => phone,
      phoneCode: () =>
        hiddenInput("Código recibido de Telegram (entrada oculta): "),
      password: () =>
        hiddenInput(
          "Contraseña de verificación en dos pasos, si Telegram la exige (entrada oculta): ",
        ),
      firstAndLastNames: async () => {
        throw new BridgeError("EXISTING_ACCOUNT_REQUIRED", 400);
      },
      reCaptchaCallback: async () => {
        throw new BridgeError("CAPTCHA_REQUIRES_OWNER", 403);
      },
      onError: (e) => {
        throw loginError(e);
      },
    });
    const me = await client.getMe();
    if (me.bot || !me.phone || normalizePhone("+" + me.phone) !== phone)
      throw new BridgeError("ACCOUNT_MISMATCH", 403);
    saveSession(client.session.save(), encryptionKey);
    const holder = {
      phone,
      consentRef: "owner-login:" + randomUUID(),
      ownershipVerifiedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 86400000).toISOString(),
      scope: "lookup",
    };
    writeFileSync(
      join(stateDirectory(), "holder.json"),
      JSON.stringify(holder),
      { mode: 0o600 },
    );
    console.log(
      "Sesión vinculada y cifrada. No se ha enviado ningún teléfono al bot. La activación de la consulta requiere comprobar el protocolo y conectar el servidor HTTPS a Notas.",
    );
  } finally {
    await client.disconnect();
  }
}
main().catch((e) => {
  console.error(e instanceof BridgeError ? e.code : "LOGIN_FAILED");
  process.exitCode = 1;
});
