export class BridgeError extends Error {
  code: string;
  status: number;
  constructor(code: string, status = 502) {
    super(code);
    this.code = code;
    this.status = status;
  }
}
// Allowlisted RPC codes only: never expose the request, phone, code or message.
export function loginError(error: unknown): BridgeError {
  if (error instanceof BridgeError) return error;
  const code = (error as { errorMessage?: unknown } | null)?.errorMessage;
  const allowed = new Set([
    "API_ID_INVALID",
    "API_ID_PUBLISHED_FLOOD",
    "PHONE_NUMBER_INVALID",
    "PHONE_NUMBER_BANNED",
    "PHONE_CODE_INVALID",
    "PHONE_CODE_EXPIRED",
    "PHONE_CODE_EMPTY",
    "PASSWORD_HASH_INVALID",
    "AUTH_RESTART",
    "SESSION_REVOKED",
    "AUTH_KEY_UNREGISTERED",
  ]);
  if (typeof code === "string" && allowed.has(code))
    return new BridgeError(code, 503);
  if (
    typeof code === "string" &&
    /^(?:PHONE|NETWORK|USER)_MIGRATE_\d+$/.test(code)
  )
    return new BridgeError("TELEGRAM_DC_MIGRATION", 503);
  if (typeof code === "string" && /^FLOOD_WAIT_\d+$/.test(code))
    return new BridgeError("TELEGRAM_RATE_LIMIT", 429);
  return new BridgeError("TELEGRAM_LOGIN", 503);
}
