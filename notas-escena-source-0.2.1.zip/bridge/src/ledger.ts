import { DatabaseSync } from "node:sqlite";
import { createHmac } from "node:crypto";
import { BridgeError } from "./errors.ts";
export class Ledger {
  db: DatabaseSync;
  salt: string;
  constructor(path: string, salt: string) {
    this.salt = salt;
    this.db = new DatabaseSync(path);
    this.db.exec(`PRAGMA busy_timeout=3000;
      CREATE TABLE IF NOT EXISTS requests (id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, status TEXT NOT NULL, created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS lock (id INTEGER PRIMARY KEY, request_id TEXT, lease INTEGER NOT NULL DEFAULT 0, cooldown INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS limits (id INTEGER PRIMARY KEY, count INTEGER NOT NULL);
      INSERT OR IGNORE INTO lock (id) VALUES (1);`);
  }
  claim(requestId: string, phone: string, sessionId: string) {
    const now = Date.now();
    this.db.prepare("DELETE FROM requests WHERE created<?").run(now - 86400000);
    const fingerprint = createHmac("sha256", this.salt)
      .update(JSON.stringify([phone, sessionId]))
      .digest("hex");
    const old = this.db
      .prepare("SELECT fingerprint FROM requests WHERE id=?")
      .get(requestId);
    if (old)
      throw new BridgeError(
        old.fingerprint === fingerprint ? "DUPLICATE" : "PAYLOAD_MISMATCH",
        409,
      );
    const window = Math.floor(now / 3600000);
    this.db.prepare("DELETE FROM limits WHERE id<?").run(window);
    const rate = this.db
      .prepare(
        "INSERT INTO limits VALUES (?,1) ON CONFLICT(id) DO UPDATE SET count=count+1 RETURNING count",
      )
      .get(window);
    if (Number(rate?.count) > 20) throw new BridgeError("RATE_LIMIT", 429);
    try {
      this.db
        .prepare("INSERT INTO requests VALUES (?,?,'pending',?)")
        .run(requestId, fingerprint, now);
    } catch {
      throw new BridgeError("DUPLICATE", 409);
    }
    const locked = this.db
      .prepare(
        "UPDATE lock SET request_id=?,lease=? WHERE id=1 AND lease<? AND cooldown<=? RETURNING id",
      )
      .get(requestId, now + 90000, now, now);
    if (!locked) {
      this.db
        .prepare("UPDATE requests SET status='not_sent' WHERE id=?")
        .run(requestId);
      throw new BridgeError("BUSY_OR_COOLDOWN", 409);
    }
  }
  finish(id: string, status: string, cooldownMs = 2000) {
    this.db.prepare("UPDATE requests SET status=? WHERE id=?").run(status, id);
    this.db
      .prepare(
        "UPDATE lock SET request_id=NULL,lease=0,cooldown=MAX(cooldown,?) WHERE id=1 AND request_id=?",
      )
      .run(Date.now() + cooldownMs, id);
  }
  close() {
    this.db.close();
  }
}
