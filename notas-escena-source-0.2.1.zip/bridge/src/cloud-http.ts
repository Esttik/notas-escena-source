import { createHash, timingSafeEqual } from "node:crypto";
import {
  AppError,
  normalizePhone,
  validateResult,
  type QueryResult,
} from "../../lib/domain.ts";
import { BridgeError } from "./errors.ts";
export type CloudInput = {
  requestId: string;
  sessionId: string;
  phone: string;
};
type Lookup = (input: CloudInput, signal: AbortSignal) => Promise<QueryResult>;
export type Holder = {
  phone: string;
  scope: string;
  consentRef: string;
  ownershipVerifiedAt: string;
  expiresAt: string;
};
const UUID =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function validateHolder(value: unknown): Holder {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new BridgeError("CONSENT_CONFIG", 503);
  const h = value as Holder;
  if (
    typeof h.phone !== "string" ||
    normalizePhone(h.phone) !== h.phone ||
    h.scope !== "lookup" ||
    typeof h.consentRef !== "string" ||
    !/^owner-login:[a-f0-9-]{36}$/.test(h.consentRef) ||
    !Number.isFinite(Date.parse(h.ownershipVerifiedAt)) ||
    Date.parse(h.ownershipVerifiedAt) > Date.now() ||
    !Number.isFinite(Date.parse(h.expiresAt)) ||
    Date.parse(h.expiresAt) <= Date.now() ||
    Date.parse(h.expiresAt) - Date.parse(h.ownershipVerifiedAt) >
      7 * 86400000 + 1000
  )
    throw new BridgeError("CONSENT_EXPIRED_OR_INVALID", 403);
  return h;
}
function response(status: number, value: unknown) {
  return Response.json(value, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "X-Robots-Tag": "noindex, nofollow",
      "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    },
  });
}
async function readBody(req: Request) {
  if (Number(req.headers.get("content-length")) > 2048)
    throw new BridgeError("BODY_LIMIT", 413);
  const reader = req.body?.getReader();
  if (!reader) throw new BridgeError("INPUT", 400);
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.byteLength;
      if (size > 2048) {
        await reader.cancel();
        throw new BridgeError("BODY_LIMIT", 413);
      }
      chunks.push(part.value);
    }
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch (e) {
    if (e instanceof BridgeError) throw e;
    throw new BridgeError("INPUT", 400);
  } finally {
    reader.releaseLock();
  }
}
export function createCloudHandler(
  lookup: Lookup,
  getConfig: () => { secret: string; holder: unknown },
) {
  return async (req: Request) => {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 11000);
    const cancel = () => abort.abort();
    req.signal.addEventListener("abort", cancel, { once: true });
    if (req.signal.aborted) abort.abort();
    try {
      const { secret, holder } = getConfig();
      if (secret.length < 40) throw new BridgeError("BEARER_CONFIG", 503);
      const hash = (v: string) => createHash("sha256").update(v).digest();
      if (
        !timingSafeEqual(
          hash(req.headers.get("authorization") ?? ""),
          hash(`Bearer ${secret}`),
        )
      )
        throw new BridgeError("UNAUTHORIZED", 401);
      if (req.headers.has("origin")) throw new BridgeError("ORIGIN", 403);
      if (
        req.method !== "POST" ||
        !["/lookup", "/.netlify/functions/lookup"].includes(
          new URL(req.url).pathname,
        )
      )
        throw new BridgeError("NOT_FOUND", 404);
      if (req.headers.get("content-type") !== "application/json")
        throw new BridgeError("CONTENT_TYPE", 415);
      const value = await readBody(req);
      if (!value || typeof value !== "object" || Array.isArray(value))
        throw new BridgeError("INPUT", 400);
      const input = value as CloudInput;
      if (
        Object.keys(value).sort().join(",") !== "phone,requestId,sessionId" ||
        typeof input.phone !== "string" ||
        typeof input.requestId !== "string" ||
        typeof input.sessionId !== "string" ||
        !UUID.test(input.requestId) ||
        !UUID.test(input.sessionId) ||
        req.headers.get("idempotency-key") !== input.requestId ||
        normalizePhone(input.phone) !== input.phone
      )
        throw new BridgeError("INPUT", 400);
      if (input.phone !== validateHolder(holder).phone)
        throw new BridgeError("OWN_PHONE_ONLY", 403);
      if (abort.signal.aborted) throw new BridgeError("TIMEOUT", 504);
      const result = await lookup(input, abort.signal);
      if (abort.signal.aborted) throw new BridgeError("TIMEOUT", 504);
      return response(
        200,
        validateResult(result, input.requestId, input.phone),
      );
    } catch (error) {
      const e =
        error instanceof BridgeError
          ? error
          : error instanceof AppError
            ? new BridgeError(error.code, error.status)
            : new BridgeError("INTERNAL", 500);
      // Constants only: never log exception objects, request bodies or responses.
      if (e.status >= 500) console.error(e.code);
      return response(e.status, {
        code: e.code,
        error:
          "No se pudo completar la consulta. Revisa el diagnóstico del servidor.",
      });
    } finally {
      clearTimeout(timer);
      req.signal.removeEventListener("abort", cancel);
    }
  };
}
