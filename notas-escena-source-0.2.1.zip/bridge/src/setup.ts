import { createServer } from "node:http";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { normalizePhone } from "../../lib/domain.ts";
import { makeClient } from "./telegram-client.ts";
import { recordSession } from "./session-record.ts";
import { BridgeError, loginError } from "./errors.ts";
import { LoginChallenge } from "./login-challenge.ts";
import { setupPage } from "./setup-page.ts";
const port = 8790,
  host = `127.0.0.1:${port}`,
  origin = `http://${host}`,
  token = randomBytes(32).toString("hex");
const client = makeClient("", true);
type Stage = "phone" | "code" | "password" | "complete" | "error";
let stage: Stage = "phone",
  error = "",
  busy = false;
const challenge = new LoginChallenge();
function input(next: "code" | "password", length?: number, delivery?: string) {
  stage = next;
  return challenge.wait(next, length, delivery);
}
let expiry: ReturnType<typeof setTimeout> | undefined;
async function connect(phone: string) {
  try {
    await client.start({
      phoneNumber: async () => phone,
      phoneCode: (viaApp, info) =>
        input("code", info?.length, info?.type ?? (viaApp ? "app" : "sms")),
      password: () => input("password"),
      firstAndLastNames: async () => {
        throw new BridgeError("EXISTING_ACCOUNT_REQUIRED", 400);
      },
      reCaptchaCallback: async () => {
        throw new BridgeError("CAPTCHA_REQUIRES_OWNER", 403);
      },
      onError: (e) => {
        challenge.recover(e);
      },
    });
    await recordSession(client, phone);
    stage = "complete";
  } catch (e) {
    stage = "error";
    error = loginError(e).code;
  } finally {
    if (expiry) clearTimeout(expiry);
    busy = false;
    challenge.cancel();
    await client.disconnect();
  }
}
const server = createServer(async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  if (req.headers.host !== host) {
    res.writeHead(403);
    res.end();
    return;
  }
  if (req.method === "GET" && req.url === "/") {
    const nonce = randomBytes(18).toString("base64");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader(
      "Content-Security-Policy",
      `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'`,
    );
    res.end(setupPage(nonce, token));
    return;
  }
  const presented = String(req.headers["x-setup-token"] ?? "");
  if (
    !/^[a-f0-9]{64}$/.test(presented) ||
    !timingSafeEqual(Buffer.from(presented), Buffer.from(token)) ||
    (req.method === "POST" && req.headers.origin !== origin)
  ) {
    res.writeHead(403);
    res.end();
    return;
  }
  res.setHeader("Content-Type", "application/json");
  try {
    if (req.method === "GET" && req.url === "/status") {
      res.end(
        JSON.stringify({
          stage,
          error: error || challenge.error,
          waiting: !!challenge.pending,
          challengeId: challenge.id,
          length: challenge.length,
          delivery: challenge.delivery,
        }),
      );
      return;
    }
    if (
      req.method !== "POST" ||
      req.headers["content-type"] !== "application/json"
    )
      throw new BridgeError("INPUT", 400);
    let size = 0;
    const parts: Buffer[] = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 2048) throw new BridgeError("BODY_LIMIT", 413);
      parts.push(chunk);
    }
    const body = JSON.parse(Buffer.concat(parts).toString("utf8"));
    if (req.url === "/connect") {
      if (
        busy ||
        stage !== "phone" ||
        body.consent !== "AUTORIZO" ||
        typeof body.phone !== "string"
      )
        throw new BridgeError("CONSENT", 400);
      const phone = normalizePhone(body.phone);
      busy = true;
      expiry = setTimeout(() => {
        stage = "error";
        error = "LOGIN_TIMEOUT";
        challenge.cancel();
        void client.disconnect();
      }, 180000);
      void connect(phone);
      res.end('{"ok":true}');
      return;
    }
    if (req.url === "/input") {
      challenge.submit(body.id, body.value);
      res.end('{"ok":true}');
      return;
    }
    throw new BridgeError("INPUT", 400);
  } catch (e) {
    res.writeHead(e instanceof BridgeError ? e.status : 400);
    res.end('{"error":"INPUT"}');
  }
});
server.requestTimeout = 10000;
server.headersTimeout = 5000;
server.maxHeadersCount = 30;
server.listen(port, "127.0.0.1", () =>
  console.log(`Vinculación local: ${origin}/`),
);
server.on("error", () => {
  console.error("SETUP_LISTEN");
  process.exitCode = 1;
});
function stop() {
  if (expiry) clearTimeout(expiry);
  challenge.cancel();
  server.closeAllConnections();
  server.close(() => {
    void client.disconnect().finally(() => process.exit(0));
  });
}
process.once("SIGINT", stop);
process.once("SIGTERM", stop);
