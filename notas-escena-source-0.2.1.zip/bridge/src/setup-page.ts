export function setupPage(nonce: string, token: string) {
  return `<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vincular Notas Escena</title>
<style nonce="${nonce}">body{font:17px system-ui;background:#f3f3f6;color:#222;margin:0;padding:32px}main{max-width:580px;margin:auto;background:white;padding:28px;border-radius:22px}h1{font-size:28px}p{line-height:1.5}label{display:block;margin:22px 0 8px}input{box-sizing:border-box;width:100%;font:inherit;padding:14px;border:1px solid #bbb;border-radius:10px}button{font:600 17px system-ui;padding:14px 22px;margin-top:24px;background:#edbd00;border:0;border-radius:12px}button:disabled{opacity:.5}small{color:#666;line-height:1.5;display:block}#result{white-space:pre-wrap}</style>
<main><h1>Vincular tu cuenta</h1><p>Esta página local conecta una <b>sesión nueva</b> de tu cuenta de Telegram al servidor de Notas Escena. Como cualquier cliente de Telegram, tendrá acceso técnico amplio a tu cuenta. Nuestro programa consulta solo @TrueCalleRobot y tu propio teléfono.</p><small>Puedes revocar la sesión en Telegram → Ajustes → Dispositivos. Los códigos y la contraseña no se guardan. La sesión se cifra en el servidor; las credenciales de aplicación ya están configuradas y no llegan a esta página.</small>
<form id="form"><section id="phone"><label for="number">Tu móvil español</label><input id="number" type="tel" autocomplete="tel" placeholder="+34 …" required><label for="consent">Para autorizar la sesión y consultar tu teléfono, escribe AUTORIZO</label><input id="consent" autocomplete="off" required></section>
<section id="challenge" hidden><label id="challenge-label" for="value">Código de Telegram</label><p id="help"></p><input id="value" type="password" autocomplete="off" aria-describedby="help" required disabled></section><button id="submit">Conectar mi cuenta</button></form><p id="result" role="status" aria-live="polite"></p></main>
<script nonce="${nonce}">
const token=${JSON.stringify(token)}, $=id=>document.getElementById(id);
let current='phone',challengeId=0,submittedId=0,inFlight=false,refreshing=false;
const form=$('form'),result=$('result'),button=$('submit'),value=$('value');
async function request(path,body){
 const r=await fetch(path,{method:body?'POST':'GET',headers:{'X-Setup-Token':token,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store'});
 if(!r.ok)throw Error('Revisa el formato y espera a que termine el paso actual.');return r.json();
}
async function refresh(){
 if(refreshing)return;refreshing=true;
 try{const s=await request('/status');current=s.stage;
 if(s.stage==='code'||s.stage==='password'){
 $('phone').hidden=true;$('challenge').hidden=false;$('number').required=false;$('consent').required=false;
 if(challengeId!==s.challengeId){challengeId=s.challengeId;value.value='';value.disabled=false;value.inputMode=s.stage==='code'?'numeric':'text';value.maxLength=s.stage==='code'?30:511;value.focus();}
 $('challenge-label').textContent=s.stage==='code'?'Código de acceso de Telegram':'Contraseña de verificación en dos pasos';
 $('help').textContent=s.stage==='password'?'Es tu contraseña adicional de Telegram, no el código numérico. No se guardará.':(s.delivery==='app'?'Abre la app Telegram y busca el mensaje nuevo del servicio Telegram.':s.delivery==='sms'?'Telegram ha enviado el código nuevo por SMS.':'Utiliza el código del método que acaba de indicar Telegram.')+(s.length?' Tiene '+s.length+' dígitos.':'')+' Usa el código de ESTA vinculación, no el utilizado antes para my.telegram.org. No lo pegues en este chat.';
 button.textContent='Confirmar';button.disabled=inFlight||!s.waiting||submittedId===challengeId;value.disabled=!s.waiting||submittedId===challengeId;
 result.textContent=s.error==='PHONE_CODE_INVALID'?'Telegram ha rechazado el código. Puedes corregirlo aquí sin solicitar otro.':s.error==='PASSWORD_HASH_INVALID'?'Telegram ha rechazado la contraseña adicional. Puedes corregirla aquí.':s.waiting?'Esperando tu confirmación.':'Comprobando con Telegram…';
 }else if(s.stage==='complete'){form.hidden=true;result.textContent='Cuenta vinculada y sesión cifrada. Todavía no se ha consultado tu teléfono.';clearInterval(timer);
 }else if(s.stage==='error'){form.hidden=true;const messages={PHONE_CODE_EXPIRED:'El código ha caducado. Hay que iniciar una vinculación nueva.',PHONE_CODE_INVALID:'Telegram ha rechazado tres códigos. Se ha detenido la vinculación.',TELEGRAM_RATE_LIMIT:'Telegram exige esperar. No sigas intentando vincular la cuenta.',LOGIN_TIMEOUT:'Se agotó el tiempo de vinculación.'};result.textContent=(messages[s.error]||'Vinculación detenida: '+s.error)+ ' No se reintentará automáticamente.';clearInterval(timer);}
 }catch(e){result.textContent=e.message;}finally{refreshing=false;}
}
form.addEventListener('submit',async e=>{e.preventDefault();if(inFlight||button.disabled)return;inFlight=true;button.disabled=true;try{
 if(current==='phone')await request('/connect',{phone:$('number').value,consent:$('consent').value});
 else {const id=challengeId;await request('/input',{id,value:value.value});submittedId=id;value.value='';}
 result.textContent='Esperando a Telegram…';
 }catch(e){result.textContent=e.message;}finally{inFlight=false;await refresh();}});
const timer=setInterval(refresh,1000);refresh();
</script></html>`;
}
