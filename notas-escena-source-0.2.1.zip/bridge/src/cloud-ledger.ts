import { createHmac } from "node:crypto";
import { BridgeError } from "./errors.ts";
export interface SqlClient {
  query(
    sql: string,
    values?: unknown[],
  ): Promise<{ rows: Record<string, unknown>[] }>;
  release(): void;
}
export interface SqlPool {
  connect(): Promise<SqlClient>;
}
export class CloudLedger {
  private pool: SqlPool;
  private salt: string;
  private clock: () => number;
  constructor(pool: SqlPool, salt: string, clock = Date.now) {
    this.pool = pool;
    this.salt = salt;
    this.clock = clock;
  }
  async claim(requestId: string, phone: string, sessionId: string) {
    const client = await this.pool.connect();
    const now = this.clock();
    const fingerprint = createHmac("sha256", this.salt)
      .update(JSON.stringify([phone, sessionId]))
      .digest("hex");
    try {
      await client.query("BEGIN");
      // One row lock serializes claims and rate accounting across all instances.
      const {
        rows: [lock],
      } = await client.query("SELECT * FROM bridge_lock WHERE id=1 FOR UPDATE");
      if (!lock) throw new BridgeError("LEDGER_CONFIG", 503);
      await client.query("DELETE FROM bridge_requests WHERE created<$1", [
        now - 86400000,
      ]);
      await client.query("DELETE FROM bridge_limits WHERE id<$1", [
        Math.floor(now / 3600000),
      ]);
      const {
        rows: [old],
      } = await client.query(
        "SELECT fingerprint FROM bridge_requests WHERE id=$1",
        [requestId],
      );
      if (old)
        throw new BridgeError(
          old.fingerprint === fingerprint ? "DUPLICATE" : "PAYLOAD_MISMATCH",
          409,
        );
      const {
        rows: [rate],
      } = await client.query("SELECT count FROM bridge_limits WHERE id=$1", [
        Math.floor(now / 3600000),
      ]);
      if (Number(rate?.count ?? 0) >= 20)
        throw new BridgeError("RATE_LIMIT", 429);
      if (Number(lock.lease) >= now || Number(lock.cooldown) > now)
        throw new BridgeError("BUSY_OR_COOLDOWN", 409);
      await client.query(
        "INSERT INTO bridge_requests VALUES($1,$2,'pending',$3)",
        [requestId, fingerprint, now],
      );
      await client.query(
        "INSERT INTO bridge_limits VALUES($1,1) ON CONFLICT(id) DO UPDATE SET count=bridge_limits.count+1",
        [Math.floor(now / 3600000)],
      );
      await client.query(
        "UPDATE bridge_lock SET request_id=$1,lease=$2 WHERE id=1",
        [requestId, now + 90000],
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
  async finish(id: string, status: string, cooldownMs = 2000) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      await client.query("SELECT id FROM bridge_lock WHERE id=1 FOR UPDATE");
      await client.query("UPDATE bridge_requests SET status=$1 WHERE id=$2", [
        status,
        id,
      ]);
      await client.query(
        "UPDATE bridge_lock SET request_id=NULL,lease=0,cooldown=GREATEST(cooldown,$1) WHERE id=1 AND request_id=$2",
        [this.clock() + cooldownMs, id],
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}
