import { Api, TelegramClient } from "teleproto";
import { StringSession } from "teleproto/sessions";
import { Logger, LogLevel } from "teleproto/extensions/Logger.js";
import { createHash } from "node:crypto";
import { normalizePhone } from "../../lib/domain.ts";
import { BridgeError } from "./errors.ts";
import type { Message, Transport } from "./engine.ts";
export function incomingMessage(raw: Api.TypeMessage): Message | null {
  if (
    !(raw instanceof Api.Message) ||
    raw.out ||
    !(raw.peerId instanceof Api.PeerUser) ||
    raw.peerId.userId.toString() !== "6108968969" ||
    raw.fwdFrom ||
    raw.viaBotId ||
    (raw.fromId &&
      (!(raw.fromId instanceof Api.PeerUser) ||
        raw.fromId.userId.toString() !== "6108968969"))
  )
    return null;
  // Telegram may omit from_id in a private incoming message. The authenticated
  // peer, incoming flag and absence of forwarding identify the correspondent.
  return {
    id: raw.id,
    senderId: "6108968969",
    chatId: "6108968969",
    replyTo: raw.replyTo?.replyToMsgId,
    text: raw.message,
  };
}
export function applicationCredentials() {
  const apiId = Number(process.env.TELEGRAM_API_ID),
    apiHash = process.env.TELEGRAM_API_HASH ?? "";
  if (
    !Number.isSafeInteger(apiId) ||
    apiId < 1 ||
    !/^[a-f0-9]{32}$/i.test(apiHash)
  )
    throw new BridgeError("APPLICATION_CREDENTIALS", 503);
  return { apiId, apiHash };
}
export function makeClient(session: string, login = false) {
  const { apiId, apiHash } = applicationCredentials();
  return new TelegramClient(new StringSession(session), apiId, apiHash, {
    baseLogger: new Logger(LogLevel.NONE),
    requestRetries: login ? 3 : 1,
    floodSleepThreshold: 0,
    connectionRetries: 1,
    reconnectRetries: 1,
    autoReconnect: false,
    timeout: 5,
    deviceModel: "Notas Escena · servidor propio",
    appVersion: "0.1.0",
    securityChecks: true,
  });
}
export class UserTransport implements Transport {
  client: TelegramClient;
  peer: Api.InputPeerUser | null = null;
  constructor(client: TelegramClient) {
    this.client = client;
  }
  options(signal: AbortSignal, timeout = 3000): Api.ApiCallOptions {
    return {
      abortSignal: signal,
      timeout,
      maxRetryCount: 0,
      floodSleepThreshold: 0,
    };
  }
  async verify(signal: AbortSignal) {
    const [me] = await this.client.api.users.getUsers(
      { id: [new Api.InputUserSelf()] },
      this.options(signal),
    );
    const resolved = await this.client.api.contacts.resolveUsername(
      { username: "TrueCalleRobot" },
      this.options(signal),
    );
    const bot = resolved.users.find(
      (u) => u instanceof Api.User && u.id.toString() === "6108968969",
    );
    if (
      !(me instanceof Api.User) ||
      me.bot ||
      !me.phone ||
      !(bot instanceof Api.User) ||
      !bot.bot ||
      !bot.accessHash ||
      !(resolved.peer instanceof Api.PeerUser) ||
      resolved.peer.userId.toString() !== "6108968969"
    )
      throw new BridgeError("ACCOUNT_OR_TARGET", 503);
    this.peer = new Api.InputPeerUser({
      userId: bot.id,
      accessHash: bot.accessHash,
    });
    return {
      phone: normalizePhone("+" + me.phone),
      targetId: bot.id.toString(),
      targetBot: !!bot.bot,
      targetUsername: bot.username ?? "",
    };
  }
  async send(phone: string, signal: AbortSignal, requestId: string) {
    if (!this.peer) throw new BridgeError("TARGET", 503);
    const randomId = BigInt.asIntN(
      64,
      BigInt(
        "0x" +
          createHash("sha256").update(requestId).digest("hex").slice(0, 16),
      ),
    );
    const result = await this.client.api.messages.sendMessage(
      { peer: this.peer, message: phone, randomId, noWebpage: true },
      this.options(signal),
    );
    if (result instanceof Api.UpdateShortSentMessage) return result.id;
    if (
      result instanceof Api.Updates ||
      result instanceof Api.UpdatesCombined
    ) {
      const matching = result.updates.find(
        (u) =>
          u instanceof Api.UpdateMessageID &&
          u.randomId?.toString() === randomId.toString(),
      );
      if (matching instanceof Api.UpdateMessageID) return matching.id;
      const update = result.updates.find(
        (u) =>
          u instanceof Api.UpdateNewMessage &&
          u.message instanceof Api.Message &&
          u.message.out &&
          u.message.message === phone &&
          u.message.peerId instanceof Api.PeerUser &&
          u.message.peerId.userId.toString() === "6108968969",
      );
      if (
        update instanceof Api.UpdateNewMessage &&
        update.message instanceof Api.Message
      )
        return update.message.id;
    }
    throw new BridgeError("SEND_UNCONFIRMED");
  }
  async messages(sent: number, signal: AbortSignal): Promise<Message[]> {
    if (!this.peer) throw new BridgeError("TARGET", 503);
    const history = await this.client.api.messages.getHistory(
      {
        peer: this.peer,
        offsetId: 0,
        offsetDate: 0,
        addOffset: 0,
        limit: 20,
        maxId: 0,
        minId: sent,
        hash: 0n,
      },
      this.options(signal, 2000),
    );
    if (!("messages" in history)) return [];
    return history.messages
      .map(incomingMessage)
      .filter((m): m is Message => m !== null);
  }
}
