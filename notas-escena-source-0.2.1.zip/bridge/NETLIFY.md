# Conexión alojada en Netlify

Decisión: conservar la web privada actual y alojar su proveedor HTTP en un proyecto Netlify separado. No depende de un Mac, túnel ni Telegram abierto en el móvil. El navegador llama al backend autenticado de la web; este llama a la función protegida por un secreto de servidor.

La función abre la sesión nueva de Telegram que el titular vinculó voluntariamente, consulta únicamente su propio móvil con autorización vigente y cierra la conexión. Un registro transaccional Postgres compartido reserva la cuenta **antes** de conectar Telegram. No hay funciones de fondo, reintentos de envío ni caché de respuestas. La tabla conserva únicamente UUID, HMAC, estado y tiempo durante 24 horas.

La sesión se traslada cifrada a variables de entorno de Functions; no se publica ningún archivo de estado ni credencial. La conexión local debe detenerse antes de la primera consulta desde la nube para evitar usar simultáneamente la misma sesión desde direcciones distintas.

La disponibilidad de una función no demuestra el recorrido real: hay que verificar autenticación, rechazo de otro número, correlación, respuesta y peek, y después repetir con el puente local apagado. Safari/WebKit emulado no sustituye una prueba en iPhone físico.

## Configuración

Desde esta carpeta, instalar con `npm ci`. Migraciones bajo `netlify/database/migrations/` se aplican mediante el despliegue; no aplicar DDL manualmente a producción. `netlify.toml` publica exclusivamente `public/` y las funciones de `netlify/functions/`.

`netlify.env.example` enumera variables vacías sin secretos. No importar este ejemplo directamente sobre un servidor activo: sus valores vacíos reemplazarían la configuración. Los archivos reales deben permanecer fuera de Git.

Variables privadas, exclusivamente scope Functions y contexto production: `TELEGRAM_API_ID`, `TELEGRAM_API_HASH`, `BRIDGE_ENCRYPTION_KEY`, `BRIDGE_BEARER_TOKEN`, `TELEGRAM_SESSION_ENCRYPTED_BASE64` (session.enc codificado en base64), `BRIDGE_HOLDER_BASE64` (JSON de autorización en base64), `TELEGRAM_FINAL_SUFFIX_BASE64` y opcional `TELEGRAM_NO_RESULT_TEXT`. La base se aprovisiona mediante @netlify/database. `AWS_LAMBDA_JS_RUNTIME=nodejs24.x` se configura en Netlify, no en TOML.

Usar siempre `--site <ID-del-proyecto-Notas>` al operar la CLI: el directorio superior contiene otro proyecto. `.netlify/` queda excluido de Git. El perímetro HTTP necesita permitir peticiones servidor a servidor; el endpoint exige bearer, rechaza Origin y valida cada dato. La web del artista mantiene su autenticación independiente.

El consentimiento caduca siete días después de la vinculación. Renovarlo requiere una acción del titular; nunca se extiende automáticamente. Para revocar acceso: Telegram → Ajustes → Dispositivos → cerrar la sesión del servidor; borrar las variables de sesión y autorización en Netlify. El historial ya enviado puede permanecer en Telegram y en el proveedor.

Las pruebas `npm test` necesitan PostgreSQL 17 (POSTGRES_BIN configurable) y ejecutan un clúster temporal sin modificar servicios existentes. Proyecto preparado: https://app.netlify.com/projects/YOUR_PROJECT. Activo en producción. Verificados health 200, ausencia de clave 401, otro móvil 403, consulta real del titular 200 y UUID duplicado 409 con los procesos locales apagados. Previews privadas.
