import test from "node:test";
import assert from "node:assert/strict";
import { loginError } from "../src/errors.ts";

test("login: solo revela códigos permitidos; no expone solicitudes ni secretos", () => {
  assert.equal(
    loginError({ errorMessage: "PHONE_CODE_EXPIRED" }).code,
    "PHONE_CODE_EXPIRED",
  );
  assert.equal(
    loginError({ errorMessage: "PHONE_MIGRATE_4" }).code,
    "TELEGRAM_DC_MIGRATION",
  );
  assert.equal(
    loginError({ errorMessage: "FLOOD_WAIT_3600" }).code,
    "TELEGRAM_RATE_LIMIT",
  );
  const malicious = {
    errorMessage: "PHONE_CODE_INVALID token=private",
    message: "private code phone",
  };
  assert.equal(loginError(malicious).code, "TELEGRAM_LOGIN");
  assert.equal(loginError(null).code, "TELEGRAM_LOGIN");
});
