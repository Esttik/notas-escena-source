import test from "node:test";
import assert from "node:assert/strict";
import { Api } from "teleproto";
import bigInt from "big-integer";
import { incomingMessage } from "../src/telegram-client.ts";
function message(extra: Record<string, unknown> = {}) {
  return new Api.Message({
    id: 11,
    peerId: new Api.PeerUser({ userId: bigInt("6108968969") }),
    date: 1,
    message: "Ficticio",
    replyTo: new Api.MessageReplyHeader({ replyToMsgId: 10 }),
    ...extra,
  });
}
test("Telegram privado: from_id omitido conserva peer y reply exactos", () => {
  assert.deepEqual(incomingMessage(message()), {
    id: 11,
    senderId: "6108968969",
    chatId: "6108968969",
    replyTo: 10,
    text: "Ficticio",
  });
  assert.ok(
    incomingMessage(
      message({ fromId: new Api.PeerUser({ userId: bigInt("6108968969") }) }),
    ),
  );
});
test("Telegram privado: bloquea otro peer, remitente, reenvío y mensaje saliente", () => {
  for (const extra of [
    { peerId: new Api.PeerUser({ userId: bigInt(99) }) },
    { peerId: new Api.PeerChannel({ channelId: bigInt("6108968969") }) },
    { fromId: new Api.PeerUser({ userId: bigInt(99) }) },
    { out: true },
    { viaBotId: bigInt(99) },
    { fwdFrom: new Api.MessageFwdHeader({ date: 1 }) },
  ])
    assert.equal(incomingMessage(message(extra)), null);
});
