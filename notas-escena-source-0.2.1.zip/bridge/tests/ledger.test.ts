import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Ledger } from "../src/ledger.ts";
test("ledger durable: reinicio no duplica y dos instancias no envían a la vez", () => {
  const dir = mkdtempSync(join(tmpdir(), "notas-bridge-test-")),
    path = join(dir, "ledger.sqlite"),
    id = crypto.randomUUID();
  const a = new Ledger(path, "test-salt"),
    b = new Ledger(path, "test-salt");
  try {
    a.claim(id, "+34600000001", "session");
    assert.throws(
      () => b.claim(crypto.randomUUID(), "+34600000001", "session"),
      /BUSY_OR_COOLDOWN/,
    );
    a.finish(id, "complete", 0);
    a.close();
    const reopened = new Ledger(path, "test-salt");
    try {
      assert.throws(
        () => reopened.claim(id, "+34600000001", "session"),
        /DUPLICATE/,
      );
      assert.throws(
        () => reopened.claim(id, "+34600000001", "changed"),
        /PAYLOAD_MISMATCH/,
      );
    } finally {
      reopened.close();
    }
  } finally {
    b.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
test("límites de cuenta frenan consultas masivas sin hacer crecer el ledger", () => {
  const l = new Ledger(":memory:", "test-salt");
  try {
    for (let i = 0; i < 20; i++) {
      const id = crypto.randomUUID();
      l.claim(id, "+34600000001", "session");
      l.finish(id, "complete", 0);
    }
    for (let i = 0; i < 50; i++)
      assert.throws(
        () => l.claim(crypto.randomUUID(), "+34600000001", "session"),
        /RATE_LIMIT/,
      );
    assert.equal(
      l.db.prepare("SELECT COUNT(*) AS count FROM requests").get()?.count,
      20,
    );
  } finally {
    l.close();
  }
});
