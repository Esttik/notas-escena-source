import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createServer } from "node:net";
import { getDatabase } from "@netlify/database";
import { CloudLedger, type SqlPool } from "../src/cloud-ledger.ts";
import { BridgeEngine, type Transport } from "../src/engine.ts";
import { createCloudHandler } from "../src/cloud-http.ts";
const phone = "+34600000001",
  secret = "fictional-server-secret-".repeat(3);
const holder = () => ({
  phone,
  scope: "lookup",
  consentRef: "owner-login:" + crypto.randomUUID(),
  ownershipVerifiedAt: new Date().toISOString(),
  expiresAt: new Date(Date.now() + 86400000).toISOString(),
});
test("nube: autorización, tamaño, origen y resultado no confiable antes de exponer datos", async () => {
  let calls = 0;
  const input = {
    phone,
    requestId: crypto.randomUUID(),
    sessionId: crypto.randomUUID(),
  };
  let consent = holder();
  const handler = createCloudHandler(
    async (i) => {
      calls++;
      return {
        requestId: i.requestId,
        phone: i.phone,
        final: true as const,
        found: true,
        name: "<script>ficticio</script>",
      };
    },
    () => ({ secret, holder: consent }),
  );
  const request = (body: unknown = input, extra: Record<string, string> = {}) =>
    new Request("https://example.test/lookup", {
      method: "POST",
      headers: {
        authorization: `Bearer ${secret}`,
        "content-type": "application/json",
        "idempotency-key": input.requestId,
        ...extra,
      },
      body: JSON.stringify(body),
    });
  assert.equal(
    (await handler(request(input, { authorization: "wrong" }))).status,
    401,
  );
  assert.equal(
    (await handler(request(input, { origin: "https://example.test" }))).status,
    403,
  );
  assert.equal(
    (await handler(request({ ...input, phone: "+34700000002" }))).status,
    403,
  );
  assert.equal((await handler(request({ ...input, extra: "x" }))).status, 400);
  assert.equal(
    (await handler(request({ ...input, phone: "x".repeat(3000) }))).status,
    413,
  );
  consent.expiresAt = new Date(Date.now() - 1).toISOString();
  assert.equal((await handler(request())).status, 403);
  assert.equal(calls, 0);
  consent = holder();
  const result = await handler(request());
  assert.equal(result.status, 200);
  assert.equal(result.headers.get("cache-control"), "no-store");
  assert.equal(result.headers.get("access-control-allow-origin"), null);
  assert.equal((await result.json()).name, "<script>ficticio</script>");
  assert.equal(calls, 1);
});
test("nube: Postgres comparte bloqueo, UUID y límite entre instancias; no guarda datos personales", async () => {
  // PGlite is single-process and cannot prove cross-connection row locks. Start
  // an isolated genuine Postgres cluster; never alter the user's installed DB.
  const root = mkdtempSync(join(tmpdir(), "notas-ledger-test-"));
  const bin = process.env.POSTGRES_BIN || "/opt/homebrew/opt/postgresql@17/bin";
  const server = createServer();
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as { port: number }).port;
  await new Promise<void>((resolve) => server.close(() => resolve()));
  execFileSync(
    join(bin, "initdb"),
    ["-D", root, "-U", "notas_test", "-A", "trust", "--no-locale"],
    { stdio: "pipe" },
  );
  execFileSync(
    join(bin, "pg_ctl"),
    [
      "-D",
      root,
      "-l",
      join(root, "postgres.log"),
      "-o",
      `-h 127.0.0.1 -p ${port} -k ${root}`,
      "-w",
      "start",
    ],
    { stdio: "pipe" },
  );
  const url = `postgres://notas_test@127.0.0.1:${port}/postgres`;
  const database = getDatabase({ connectionString: url });
  const pool = database.pool as SqlPool;
  let now = Date.now();
  try {
    const migration = await pool.connect();
    try {
      await migration.query(
        readFileSync(
          "netlify/database/migrations/20261012013000_bridge_ledger.sql",
          "utf8",
        ),
      );
    } finally {
      migration.release();
    }
    const a = new CloudLedger(pool, secret, () => now),
      b = new CloudLedger(pool, secret, () => now);
    const first = crypto.randomUUID(),
      second = crypto.randomUUID(),
      session = crypto.randomUUID();
    const attempts = await Promise.allSettled([
      a.claim(first, phone, session),
      b.claim(second, phone, session),
    ]);
    assert.equal(attempts.filter((x) => x.status === "fulfilled").length, 1);
    assert.match(
      String(
        (attempts.find((x) => x.status === "rejected") as PromiseRejectedResult)
          .reason,
      ),
      /BUSY_OR_COOLDOWN/,
    );
    const winner = attempts[0].status === "fulfilled" ? first : second;
    await assert.rejects(b.claim(winner, phone, session), /DUPLICATE/);
    await assert.rejects(
      b.claim(winner, "+34700000002", session),
      /PAYLOAD_MISMATCH/,
    );
    await a.finish(winner, "complete", 2000);
    await assert.rejects(
      b.claim(crypto.randomUUID(), phone, session),
      /BUSY_OR_COOLDOWN/,
    );
    now += 2001;
    for (let i = 1; i < 20; i++) {
      const id = crypto.randomUUID();
      await b.claim(id, phone, session);
      await b.finish(id, "complete", 0);
    }
    await assert.rejects(
      a.claim(crypto.randomUUID(), phone, session),
      /RATE_LIMIT/,
    );
    const client = await pool.connect();
    try {
      const serialized = JSON.stringify(
        (await client.query("SELECT * FROM bridge_requests")).rows,
      );
      assert.equal(serialized.includes(phone), false);
      assert.equal(serialized.includes("name"), false);
      assert.equal(
        (await client.query("SELECT * FROM bridge_requests")).rows.length,
        20,
      );
    } finally {
      client.release();
    }
    now += 86400001;
    const id = crypto.randomUUID();
    await a.claim(id, phone, session);
    await a.finish(id, "complete", 0);
    const c = await pool.connect();
    try {
      assert.equal(
        (await c.query("SELECT * FROM bridge_requests")).rows.length,
        1,
      );
    } finally {
      c.release();
    }
  } finally {
    await database.pool.end();
    execFileSync(
      join(bin, "pg_ctl"),
      ["-D", root, "-m", "fast", "-w", "stop"],
      { stdio: "pipe" },
    );
    rmSync(root, { recursive: true, force: true });
  }
});
test("nube: reserva antes de conectar y cierra Telegram antes de liberar la cuenta", async () => {
  const events: string[] = [];
  const transport: Transport = {
    verify: async () => {
      events.push("connect");
      return {
        phone,
        targetId: "6108968969",
        targetBot: true,
        targetUsername: "TrueCalleRobot",
      };
    },
    send: async () => {
      events.push("send");
      return 10;
    },
    messages: async () => [
      {
        id: 11,
        senderId: "6108968969",
        chatId: "6108968969",
        replyTo: 10,
        text: `Number: ${phone}\nName: Ficticio\nFINAL`,
      },
    ],
    close: async () => {
      events.push("close");
    },
  };
  const ledger = {
    claim: async () => {
      events.push("reserve");
    },
    finish: async () => {
      events.push("release");
    },
  };
  const engine = new BridgeEngine(transport, ledger, { finalSuffix: "FINAL" });
  await engine.lookup(
    { phone, requestId: crypto.randomUUID(), sessionId: crypto.randomUUID() },
    new AbortController().signal,
  );
  assert.deepEqual(events, ["reserve", "connect", "send", "close", "release"]);
  events.length = 0;
  ledger.claim = async () => {
    throw new Error("DUPLICATE");
  };
  await assert.rejects(
    engine.lookup(
      { phone, requestId: crypto.randomUUID(), sessionId: crypto.randomUUID() },
      new AbortController().signal,
    ),
    /DUPLICATE/,
  );
  assert.deepEqual(events, []);
});
