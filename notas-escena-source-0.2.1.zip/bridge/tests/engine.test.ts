import test from "node:test";
import assert from "node:assert/strict";
import { BridgeEngine, type Transport, type Message } from "../src/engine.ts";
import { Ledger } from "../src/ledger.ts";
const phone = "+34600000001",
  target = "6108968969";
function setup(batches?: Message[][]) {
  let sends = 0,
    polls = 0;
  const transport: Transport = {
    verify: async () => ({
      phone,
      targetId: target,
      targetBot: true,
      targetUsername: "TrueCalleRobot",
    }),
    send: async () => {
      sends++;
      return 10;
    },
    messages: async () =>
      batches?.[polls++] ?? [
        {
          id: 11,
          senderId: target,
          chatId: target,
          replyTo: 10,
          text: `Number: ${phone}\nCountry: Spain\nName: Persona ficticia\nFINAL`,
        },
      ],
  };
  const ledger = new Ledger(":memory:", "test-salt");
  const engine = new BridgeEngine(transport, ledger, {
    finalSuffix: "FINAL",
    pollMs: 1,
    timeoutMs: 30,
  });
  const input = {
    requestId: crypto.randomUUID(),
    sessionId: crypto.randomUUID(),
    phone,
  };
  return { engine, ledger, transport, input, sends: () => sends };
}
test("puente: sesión de usuario, propio teléfono y origen/ID de respuesta exactos", async () => {
  const s = setup();
  const r = await s.engine.lookup(s.input, new AbortController().signal);
  assert.equal(r.name, "Persona ficticia");
  assert.equal(r.phone, phone);
  assert.equal(s.sends(), 1);
  s.ledger.close();
});
test("puente bloquea otro teléfono y destino alterado antes de enviar", async () => {
  const s = setup();
  await assert.rejects(
    s.engine.lookup(
      { ...s.input, phone: "+34700000002" },
      new AbortController().signal,
    ),
    /OWN_PHONE_ONLY/,
  );
  s.ledger.close();
  const c = setup();
  c.transport.verify = async () => ({
    phone,
    targetId: "999",
    targetBot: true,
    targetUsername: "TrueCalleRobot",
  });
  await assert.rejects(
    c.engine.lookup(c.input, new AbortController().signal),
    /TARGET/,
  );
  assert.equal(s.sends(), 0);
  assert.equal(c.sends(), 0);
  c.ledger.close();
});
test("puente: UUID duplicado nunca reenvía; ledger no contiene teléfono ni nombre", async () => {
  const s = setup();
  await s.engine.lookup(s.input, new AbortController().signal);
  await assert.rejects(
    s.engine.lookup(s.input, new AbortController().signal),
    /DUPLICATE/,
  );
  assert.equal(s.sends(), 1);
  const rows = JSON.stringify(
    s.ledger.db.prepare("SELECT * FROM requests").all(),
  );
  assert.equal(rows.includes(phone), false);
  assert.equal(rows.includes("Persona ficticia"), false);
  s.ledger.close();
});
test("puente ignora otra conversación, mensajes tardíos, duplicados y parciales", async () => {
  const good = {
    id: 11,
    senderId: target,
    chatId: target,
    replyTo: 10,
    text: `Number: ${phone}\nName: Persona ficticia`,
  };
  const s = setup([
    [
      { ...good, chatId: "other" },
      { ...good, replyTo: 9 },
      { ...good, id: 9 },
      good,
      good,
    ],
    [{ ...good, text: good.text + "\nFINAL" }],
  ]);
  const r = await s.engine.lookup(s.input, new AbortController().signal);
  assert.equal(r.name, "Persona ficticia");
  assert.equal(s.sends(), 1);
  s.ledger.close();
});
test("puente: timeout no reenvía, aborto no entrega resultado", async () => {
  const s = setup([[], [], [], []]);
  s.transport.messages = async () => [];
  await assert.rejects(
    s.engine.lookup(s.input, new AbortController().signal),
    /TIMEOUT/,
  );
  assert.equal(s.sends(), 1);
  s.ledger.close();
  const c = setup();
  const abort = new AbortController();
  abort.abort();
  await assert.rejects(c.engine.lookup(c.input, abort.signal), /TIMEOUT/);
  assert.equal(c.sends(), 0);
  c.ledger.close();
});
test("puente: texto malicioso es literal y número distinto se rechaza", async () => {
  const s = setup([
    [
      {
        id: 11,
        senderId: target,
        chatId: target,
        replyTo: 10,
        text: `Number: ${phone}\nName: <script>alert(1)</script>\nFINAL`,
      },
    ],
  ]);
  assert.equal(
    (await s.engine.lookup(s.input, new AbortController().signal)).name,
    "<script>alert(1)</script>",
  );
  s.ledger.close();
  const c = setup([
    [
      {
        id: 11,
        senderId: target,
        chatId: target,
        replyTo: 10,
        text: "Number: +34700000002\nName: Otra persona\nFINAL",
      },
    ],
  ]);
  await assert.rejects(
    c.engine.lookup(c.input, new AbortController().signal),
    /CORRELATION/,
  );
  c.ledger.close();
});
