import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { seal, unseal } from "../src/vault.ts";
test("sesión cifrada: no aparece en claro, clave equivocada y manipulación se rechazan", () => {
  const key = randomBytes(32).toString("base64");
  const secret = "SESSION-FICTICIA-NUNCA-REAL";
  const envelope = seal(secret, key);
  assert.equal(envelope.includes(secret), false);
  assert.equal(unseal(envelope, key), secret);
  assert.throws(() => unseal(envelope, randomBytes(32).toString("base64")));
  const value = JSON.parse(envelope);
  value.data = Buffer.from("alterado").toString("base64");
  assert.throws(() => unseal(JSON.stringify(value), key));
  assert.throws(() => seal(secret, "clave-corta"));
});
