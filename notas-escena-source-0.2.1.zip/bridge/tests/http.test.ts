import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { createHandler } from "../src/http.ts";
import { validateResult } from "../../lib/domain.ts";
test("HTTP: autentica, tamaño/forma/clave idempotente, sin CORS, error seguro y contrato válido", async () => {
  let called = 0;
  const secret = "test-bearer-" + "x".repeat(40);
  const server = createServer(
    createHandler(
      {
        lookup: async (input) => {
          called++;
          return {
            requestId: input.requestId,
            phone: input.phone,
            final: true,
            found: true,
            name: "Persona ficticia",
          };
        },
      },
      secret,
    ),
  );
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  const addr = server.address();
  if (!addr || typeof addr === "string") throw new Error();
  const url = `http://127.0.0.1:${addr.port}/lookup`;
  try {
    assert.equal((await fetch(url, { method: "POST" })).status, 401);
    const input = {
      requestId: crypto.randomUUID(),
      sessionId: crypto.randomUUID(),
      phone: "+34600000001",
    };
    const headers = {
      Authorization: `Bearer ${secret}`,
      "Content-Type": "application/json",
      "Idempotency-Key": input.requestId,
    };
    assert.equal(
      (
        await fetch(url, {
          method: "POST",
          headers: { ...headers, Origin: "https://untrusted.example" },
          body: JSON.stringify(input),
        })
      ).status,
      403,
    );
    assert.equal(
      (
        await fetch(url, {
          method: "POST",
          headers,
          body: JSON.stringify({ ...input, extra: true }),
        })
      ).status,
      400,
    );
    assert.equal(
      (await fetch(url, { method: "POST", headers, body: "x".repeat(2049) }))
        .status,
      413,
    );
    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(input),
    });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("access-control-allow-origin"), null);
    assert.equal(response.headers.get("cache-control"), "no-store");
    const result = validateResult(
      await response.json(),
      input.requestId,
      input.phone,
    );
    assert.equal(result.requestId, input.requestId);
    assert.equal(result.name, "Persona ficticia");
    assert.equal(called, 1);
  } finally {
    server.closeAllConnections();
    await new Promise<void>((r) => server.close(() => r()));
  }
});
