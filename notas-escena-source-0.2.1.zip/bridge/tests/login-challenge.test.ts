import test from "node:test";
import assert from "node:assert/strict";
import { LoginChallenge } from "../src/login-challenge.ts";

test("login: corrige el código inválido dentro del mismo intento y limita errores", async () => {
  const challenge = new LoginChallenge();
  let input = challenge.wait("code", 5);
  challenge.submit(challenge.id, "12 345");
  assert.equal(await input, "12345");
  challenge.recover({ errorMessage: "PHONE_CODE_INVALID" });
  input = challenge.wait("code", 5);
  assert.equal(challenge.error, "PHONE_CODE_INVALID");
  challenge.submit(challenge.id, "54321");
  assert.equal(await input, "54321");
  challenge.recover({ errorMessage: "PHONE_CODE_INVALID" });
  assert.throws(() =>
    challenge.recover({ errorMessage: "PHONE_CODE_INVALID" }),
  );
});

test("login: confirmación repetida o de otro desafío nunca se reutiliza", async () => {
  const c = new LoginChallenge();
  const code = c.wait("code", 5),
    oldId = c.id;
  assert.throws(() => c.submit(oldId, "bad"));
  assert.ok(c.pending);
  c.submit(oldId, "12345");
  await code;
  assert.throws(() => c.submit(oldId, "12345"));
  const password = c.wait("password");
  assert.throws(() => c.submit(oldId, "12345"));
  c.submit(c.id, " password with spaces ");
  assert.equal(await password, " password with spaces ");
});

test("login: código caducado, límites o fallos externos detienen; cancelación libera espera", async () => {
  const c = new LoginChallenge();
  for (const code of ["PHONE_CODE_EXPIRED", "FLOOD_WAIT_100", "unknown"])
    assert.throws(() => c.recover({ errorMessage: code }));
  const waiting = c.wait("code", 5);
  c.cancel();
  await assert.rejects(waiting, /LOGIN_TIMEOUT/);
  assert.equal(c.pending, null);
});
