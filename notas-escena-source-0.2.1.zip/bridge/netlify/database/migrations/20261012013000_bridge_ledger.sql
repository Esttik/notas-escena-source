CREATE TABLE bridge_requests (
  id uuid PRIMARY KEY,
  fingerprint text NOT NULL,
  status text NOT NULL,
  created bigint NOT NULL
);
CREATE INDEX bridge_requests_created ON bridge_requests(created);
CREATE TABLE bridge_lock (
  id integer PRIMARY KEY CHECK (id = 1),
  request_id uuid,
  lease bigint NOT NULL DEFAULT 0,
  cooldown bigint NOT NULL DEFAULT 0
);
INSERT INTO bridge_lock(id) VALUES(1);
CREATE TABLE bridge_limits (
  id bigint PRIMARY KEY,
  count integer NOT NULL
);
