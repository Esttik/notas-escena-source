import type { Config } from "@netlify/functions";
const health = async () =>
  Response.json(
    { ok: true, service: "telegram-user-bridge", version: "netlify-1" },
    {
      headers: {
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        "X-Robots-Tag": "noindex, nofollow",
      },
    },
  );
export default health;
export const config: Config = { path: "/health" };
