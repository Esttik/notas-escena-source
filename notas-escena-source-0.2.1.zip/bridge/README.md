# Telegram con tu cuenta — puente propio

Implementa el enfoque de cliente de usuario que sugiere el registro de Numeria. No usa su servidor ni copia su sesión/código. Usa teleproto 1.230.0 (sucesor mantenido recomendado por el paquete GramJS archivado) y Node 24. La PWA llama a este puente desde su backend mediante el adaptador HTTP existente; Telegram nunca se contacta desde el navegador.

## Vincular la cuenta

1. En https://my.telegram.org entra con TU cuenta y abre API development tools. Necesitas tu propio API ID y API hash; el token del bot de BotFather no sirve. No pegues claves, códigos ni contraseñas en chats. Si ya tienes una aplicación, reutiliza sus credenciales.
2. Con las credenciales ya configuradas en el `.env` privado del servidor, abre el asistente local:

```sh
cd /path/to/notas-escena/bridge
npm ci --ignore-scripts
npm run setup
```

Abre http://127.0.0.1:8790/ en ese mismo Mac. Introduce el móvil, escribe AUTORIZO y confirma la conexión. El código y la contraseña adicional se introducen únicamente en esta página local, sin enviarlos al sitio publicado. El asistente solo escucha en loopback, verifica Host, Origin y un token por proceso; no debe publicarse mediante un túnel. Una vinculación iniciada caduca a los tres minutos. Los códigos incorrectos pueden corregirse en el mismo intento (hasta tres errores); no se reenvía el código automáticamente. El formulario indica el método y longitud comunicados por Telegram y bloquea confirmaciones repetidas.

Alternativa en Terminal, con entradas ocultas:

```sh
cd /path/to/notas-escena/bridge
npm ci --ignore-scripts
npm run login
```

3. Lee la delegación y autorízala en el programa. Introduce API ID/hash, teléfono, código y contraseña adicional solo en las entradas ocultas locales. Se crea una sesión nueva. Si Telegram pide crear una cuenta o resolver CAPTCHA, se detiene; no se crean cuentas ni se eluden restricciones.

El programa guarda variables del servidor en `.env` (600), y la sesión AES-256-GCM en `.bridge-state/session.enc` (600) con directorio 700. El API hash y la clave de cifrado deben guardarse en un gestor de secretos del servidor de producción; copiar solo la sesión cifrada sin su clave no permite usarla. El registro `holder.json` acredita que la sesión corresponde al teléfono propio, con consentimiento explícito de siete días; renovar/revocar conforme al usuario. No se guarda el código ni la contraseña 2FA.

Este cliente puede acceder técnicamente a la cuenta completa, como cualquier cliente MTProto; el programa limita sus operaciones al chat fijo y al teléfono propio. No equivale a permisos limitados de Bot API. Se puede revocar desde Telegram → Dispositivos. Cerrar Notas o borrar una actuación no revoca la sesión de Telegram.

## Servidor

Configura el marcador final EXACTO de una respuesta completa comprobada en `TELEGRAM_FINAL_SUFFIX`. Si no está, el arranque queda bloqueado. No se considera que una pausa indique finalización. Se exige reply al mensaje enviado y campo Number coincidente. Si el bot no mantiene ese protocolo, hay que adaptar y volver a probar el parser; no aceptar simplemente el último mensaje.

```sh
npm start
```

Arranca en 127.0.0.1:8788. GET /health devuelve solo disponibilidad del proceso; no demuestra que Telegram o el bot hayan aceptado una consulta. POST /lookup requiere Bearer secreto, Idempotency-Key UUID y {requestId,sessionId,phone}. No admite Origin ni credenciales por URL. Solo consulta el teléfono actual de la cuenta autenticada. Las altas de otros participantes requieren ampliar el registro del puente con la autorización verificable del titular.

## Hosting Netlify

El proveedor tiene una implementación moderna de Functions con registro compartido Postgres. Configuración y estado en [NETLIFY.md](NETLIFY.md). El proceso de sesión local solo es necesario para vincular o renovar; el uso alojado no necesita Telegram abierto en el teléfono. La conexión real desde Netlify se comprobó con el puente y el túnel del Mac apagados.

## Conectar con Sites

Se necesita un servidor Node con almacenamiento privado persistente y URL HTTPS alcanzable desde Sites. El Worker de Sites no ejecuta este proceso Node persistente. Este repositorio incluye Dockerfile (contexto desde la raíz del proyecto); se debe preparar /data con permisos para UID 1000 y montar un volumen persistente privado. No usar varias instancias independientes con distintos ledger; todas deben compartir la base/bloqueo. No dejar este puente en un puerto público sin HTTPS. Un Mac local necesita un túnel HTTPS autorizado y debe permanecer encendido; no es un hosting permanente.

En las variables de servidor de Sites, después de probar el canal:

```text
PROVIDER_MODE=real
PROVIDER_TRANSPORT=http
PROVIDER_API_URL=https://tu-servidor/lookup
PROVIDER_API_TOKEN=<BRIDGE_BEARER_TOKEN>
PROVIDER_AUTHORIZED=true
AUTHORIZED_PARTICIPANTS_JSON=<registro del titular>
```

El registro de Sites usa su artistId autenticado, los datos de holder.json, id/label propios y provider igual a la URL exacta. Todas las variables sensibles son secretas. El consentimiento y titularidad siguen siendo obligatorios antes de contactar al proveedor. La app ya detecta el móvil y reserva la respuesta hasta pulsar los eslabones.

## Verificación y límites

```sh
npm test
npm run typecheck
```

Los tests usan transportes ficticios y el servidor HTTP real de loopback; no abren una cuenta ni envían teléfonos a Telegram. Solicitudes RPC de consulta tienen maxRetryCount=0, timeout y AbortSignal. Identificador randomId estable por petición de envío, ledger SQLite durable para duplicados, una consulta pendiente por cuenta y 20/hora. Tras fallo/resultado desconocido hay espera de 60 s, sin reintentar. FLOOD_WAIT se respeta y los errores externos se convierten a códigos constantes. No se guardan resultados ni textos recibidos en SQLite; se purgan los UUID/hash/estado después de 24 h por actividad.

Se ha registrado la aplicación propia en la página oficial de Telegram y guardado API ID/hash en el `.env` privado. El titular completó el login nuevo, se verificó su cuenta y el bot fijo, y se probó envío/recepción con su propio teléfono, reply y marcador final. El bot exigió unirse a @true_caller; lo realizó personalmente el titular. Se activó el adaptador HTTP del sitio privado a través de un túnel HTTPS temporal y se comprobó la inserción real en la nota. El proveedor ahora se ejecuta en Netlify Functions con Postgres compartido; el puente y el túnel del Mac se apagaron antes de comprobar una consulta real desde la nube. No necesitan permanecer encendidos. La disponibilidad de una sesión de usuario no demuestra permiso comercial del proveedor ni garantiza resultado, exactitud o retención; el cliente se detiene ante rechazo/limitación del servicio.
