declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    CONNECTORS?: import("./lib/connector-contract.mjs").ConnectorBinding;
    PROVIDER_MODE?: string;
    PROVIDER_API_URL?: string;
    PROVIDER_API_TOKEN?: string;
    PROVIDER_AUTHORIZED?: string;
    AUTHORIZED_PARTICIPANTS_JSON?: string;
    PROVIDER_TRANSPORT?: string;
    TELEGRAM_BOT_TOKEN?: string;
    TELEGRAM_TARGET_BOT_ID?: string;
    TELEGRAM_TARGET_USERNAME?: string;
    TELEGRAM_PROTOCOL_CONFIRMED?: string;
    TELEGRAM_FINAL_SUFFIX?: string;
    TELEGRAM_NO_RESULT_TEXT?: string;
  }
}
