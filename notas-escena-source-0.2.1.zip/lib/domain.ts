export class AppError extends Error {
  code: string;
  status: number;
  constructor(code: string, message: string, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}
export function normalizePhone(text: string): string {
  if (typeof text !== "string" || text.length > 20000)
    throw new AppError(
      "INVALID_PHONE",
      "Escribe un único móvil español completo.",
    );
  const matches = [...text.matchAll(/\+?\d[\d \u00a0-]*/g)];
  if (matches.length !== 1)
    throw new AppError(
      "AMBIGUOUS_PHONE",
      "La nota debe contener un solo número, sin otras cifras.",
    );
  const m = matches[0];
  const index = m.index!;
  if (
    /[\p{L}\d+.]/u.test(text[index - 1] ?? "") ||
    /[\p{L}\d+.]/u.test(text[index + m[0].length] ?? "")
  )
    throw new AppError("INVALID_PHONE", "Número incompleto o formato ambiguo.");
  const compact = m[0].replace(/[ \u00a0-]/g, "");
  const digits = compact.startsWith("+34")
    ? compact.slice(3)
    : compact.startsWith("0034")
      ? compact.slice(4)
      : compact;
  if (!/^[67]\d{8}$/.test(digits))
    throw new AppError(
      "INVALID_PHONE",
      "Usa nueve dígitos que comiencen por 6 o 7, con +34 o 0034 opcional.",
    );
  return "+34" + digits;
}
export type QueryResult = {
  requestId: string;
  phone: string;
  final: true;
  found: boolean;
  country?: string;
  carrier?: string;
  name?: string;
};
export function validateResult(
  value: unknown,
  requestId: string,
  phone: string,
): QueryResult {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new AppError("INVALID_RESULT", "Respuesta no válida.", 502);
  const v = value as Record<string, unknown>;
  if (v.requestId !== requestId || v.phone !== phone)
    throw new AppError(
      "CORRELATION",
      "La respuesta no corresponde a esta petición.",
      502,
    );
  if (v.final !== true)
    throw new AppError(
      "PARTIAL",
      "El proveedor devolvió una respuesta parcial.",
      502,
    );
  if (v.found !== undefined && typeof v.found !== "boolean")
    throw new AppError("INVALID_RESULT", "Respuesta no válida.", 502);
  const result: QueryResult = {
    requestId,
    phone,
    final: true,
    found: v.found !== false,
  };
  for (const key of ["country", "carrier", "name"] as const) {
    if (v[key] === undefined) continue;
    if (
      typeof v[key] !== "string" ||
      (v[key] as string).length > 200 ||
      /[\u0000-\u001f\u007f]/.test(v[key] as string)
    )
      throw new AppError(
        "INVALID_RESULT",
        "Campo de respuesta no válido.",
        502,
      );
    if ((v[key] as string).trim()) result[key] = v[key] as string;
  }
  if (result.found && !result.country && !result.carrier && !result.name)
    throw new AppError(
      "INVALID_RESULT",
      "Respuesta vacía sin estado de resultado.",
      502,
    );
  return result;
}
export function formatResult(r: QueryResult): string {
  return [
    `Número: ${r.phone}`,
    r.country && `País: ${r.country}`,
    r.carrier && `Operador: ${r.carrier}`,
    r.name && `Nombre: ${r.name}`,
  ]
    .filter(Boolean)
    .join("\n");
}
export type Context = {
  sessionId: string;
  noteId: string;
  revision: number;
  generation: number;
};
export function canInsert(a: Context, b: Context): boolean {
  return (
    a.sessionId === b.sessionId &&
    a.noteId === b.noteId &&
    a.revision === b.revision &&
    a.generation === b.generation
  );
}
export async function digest(text: string): Promise<string> {
  return [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)),
    ),
  ]
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
}
