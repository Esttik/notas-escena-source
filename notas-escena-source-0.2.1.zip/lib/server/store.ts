export interface Prepared {
  bind(...args: unknown[]): Prepared;
  first<T>(): Promise<T | null>;
  all<T>(): Promise<{ results: T[] }>;
  run(): Promise<unknown>;
}
export interface Database {
  prepare(sql: string): Prepared;
}
export class Store {
  db: Database;
  constructor(db: Database) {
    this.db = db;
  }
  one<T>(sql: string, ...args: unknown[]) {
    return this.db
      .prepare(sql)
      .bind(...args)
      .first<T>();
  }
  async rows<T>(sql: string, ...args: unknown[]) {
    return (
      await this.db
        .prepare(sql)
        .bind(...args)
        .all<T>()
    ).results;
  }
  run(sql: string, ...args: unknown[]) {
    return this.db
      .prepare(sql)
      .bind(...args)
      .run();
  }
}
export type SessionRow = {
  id: string;
  user_id: string;
  csrf: string;
  salt: string;
  mode: string;
  participants: string;
  created: number;
  expires: number;
  revoked: number;
  query_count: number;
  active_query: string | null;
  lease: number;
};
export type QueryRow = {
  id: string;
  session_id: string;
  note_id: string;
  revision: string;
  phone_hash: string;
  status: string;
  code: string | null;
  created: number;
  provider_ms: number | null;
};
