import { useEffect } from "react";

export function useKeyboardViewport() {
  useEffect(() => {
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const v = window.visualViewport;
        // Pinch zoom changes the viewport too; it must keep normal page panning.
        const inset =
          v && v.scale === 1
            ? Math.max(0, innerHeight - v.height - v.offsetTop)
            : 0;
        document.documentElement.style.setProperty(
          "--keyboard-inset",
          `${inset}px`,
        );
        document.documentElement.classList.toggle("keyboard-open", inset > 100);
      });
    };
    const keyboard = (e: KeyboardEvent) => {
      if (e.key === "Tab")
        document.documentElement.classList.add("keyboard-navigation");
    };
    const pointer = () =>
      document.documentElement.classList.remove("keyboard-navigation");
    window.addEventListener("keydown", keyboard);
    window.addEventListener("pointerdown", pointer);
    update();
    window.visualViewport?.addEventListener("resize", update);
    window.visualViewport?.addEventListener("scroll", update);
    window.addEventListener("resize", update);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("keydown", keyboard);
      window.removeEventListener("pointerdown", pointer);
      window.visualViewport?.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);
}
