import { canInsert, normalizePhone, type Context } from "../domain.ts";

export function eligiblePhone(
  text: string,
  allowed: ReadonlySet<string>,
): string | null {
  try {
    const phone = normalizePhone(text);
    return allowed.has(phone) ? phone : null;
  } catch {
    return null;
  }
}

// Only memory: neither responses nor the attempt ledger belong in PWA storage.
export class AutomaticLookup {
  private attempted = new Set<string>();
  private staged: { context: Context; block: string } | null = null;
  private holding: Context | null = null;
  startHold(context: Context) {
    this.holding = { ...context };
  }
  release() {
    this.holding = null;
  }
  reserve(context: Context, phone: string): boolean {
    const key = JSON.stringify([context.sessionId, context.noteId, phone]);
    if (this.attempted.has(key) || this.attempted.size >= 200) return false;
    this.attempted.add(key);
    return true;
  }
  stage(context: Context, block: string) {
    this.staged = { context: { ...context }, block };
  }
  result(current: Context): string | null {
    const value = this.staged;
    if (!value) return null;
    if (!canInsert(value.context, current)) {
      this.discard();
      return null;
    }
    return value.block;
  }
  peek(current: Context): string | null {
    return this.holding && canInsert(this.holding, current)
      ? this.result(current)
      : null;
  }
  clearResult() {
    this.staged = null;
  }
  discard() {
    this.staged = null;
    this.holding = null;
  }
  reset() {
    this.discard();
    this.attempted.clear();
  }
}
