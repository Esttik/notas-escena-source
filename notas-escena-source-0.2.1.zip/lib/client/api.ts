export async function api<T>(
  path: string,
  body?: unknown,
  csrf?: string,
  signal?: AbortSignal,
): Promise<T> {
  const res = await fetch(`/api/${path}`, {
    method: body === undefined ? "GET" : "POST",
    credentials: "same-origin",
    cache: "no-store",
    signal,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(csrf ? { "X-CSRF-Token": csrf } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const value = (await res.json()) as T & { error?: string; code?: string };
  if (!res.ok)
    throw new Error(
      `${value.error ?? "Error de comunicación"} (${value.code ?? res.status})`,
    );
  return value;
}
export type Config = {
  mode: "demo" | "real";
  transport: "demo" | "http" | "telegram";
  artist: string;
  artistId: string;
  participants: { id: string; label: string; phone: string }[];
  realConfigured: boolean;
};
export type Session = {
  id: string;
  csrf: string;
  mode: "demo" | "real";
  expires: number;
};
