export type Note = {
  id: string;
  text: string;
  pinned: boolean;
  updated: number;
  volatile?: boolean;
  // In-memory link to an ordinary original; never persisted with performance content.
  sourceId?: string;
  deleted?: number;
};
const STORAGE = "notas-escena.ordinary.v1";
export function seeds(now = Date.now()): Note[] {
  return [
    [
      "Ideas para el sábado",
      "Una libreta, una mesa y un poco de imaginación.",
      0,
      true,
    ],
    [
      "La maleta azul",
      "Revisar la luz y preparar el cuaderno antes de salir.",
      3,
      true,
    ],
    [
      "Pequeños recordatorios",
      "Respirar. Escuchar. Disfrutar del momento.",
      12,
      true,
    ],
    [
      "Un paseo por el mar",
      "Buscar un lugar tranquilo para ver el atardecer.",
      1,
      false,
    ],
    [
      "Lista de cosas bonitas",
      "El olor del café y una canción que vuelve.",
      1,
      false,
    ],
    ["Destellos ✨", "A veces una idea cabe en una sola línea.", 3, false],
    [
      "El próximo viaje",
      "Dejar un día libre para perderse por las calles.",
      5,
      false,
    ],
    ["Recetas de otoño", "Sopa de calabaza, pan tostado y romero.", 15, false],
  ].map(([title, body, days, pinned]) => ({
    id: crypto.randomUUID(),
    text: `${title}\n${body}`,
    pinned: !!pinned,
    updated: now - Number(days) * 86400000,
  }));
}
export function loadNotes(): Note[] {
  try {
    const value = localStorage.getItem(STORAGE);
    if (value === null) return seeds();
    const list = JSON.parse(value);
    if (!Array.isArray(list)) return seeds();
    const seen = new Set<string>();
    return list
      .filter(
        (n) =>
          n &&
          typeof n.id === "string" &&
          n.id.length > 0 &&
          n.id.length <= 100 &&
          !seen.has(n.id) &&
          typeof n.text === "string" &&
          n.text.length <= 20000 &&
          typeof n.updated === "number" &&
          Number.isFinite(n.updated) &&
          Math.abs(n.updated) <= 8.64e15 &&
          (!n.deleted ||
            (Number.isFinite(n.deleted) &&
              n.deleted > Date.now() - 30 * 86400000 &&
              n.deleted <= Date.now())) &&
          (seen.add(n.id), true),
      )
      .slice(0, 400)
      .map((n) => ({
        id: n.id,
        text: n.text,
        pinned: !!n.pinned,
        updated: n.updated,
        ...(n.deleted ? { deleted: n.deleted } : {}),
      }));
  } catch {
    return seeds();
  }
}
export class NoteConflict extends Error {
  constructor() {
    super(
      "Esta nota cambió en otra pestaña. Tu borrador sigue visible; conserva su texto antes de recargar.",
    );
  }
}
function sameNote(a: Note | undefined, b: Note | undefined) {
  return (
    a?.id === b?.id &&
    a?.text === b?.text &&
    a?.pinned === b?.pinned &&
    a?.updated === b?.updated &&
    a?.deleted === b?.deleted
  );
}
export function mergeOrdinaryNotes(
  base: Note[],
  next: Note[],
  stored: Note[],
): Note[] {
  const old = new Map(base.map((n) => [n.id, n]));
  const desired = new Map(next.map((n) => [n.id, n]));
  const merged = new Map(stored.map((n) => [n.id, n]));
  for (const id of new Set([...old.keys(), ...desired.keys()])) {
    const before = old.get(id),
      after = desired.get(id),
      current = merged.get(id);
    if (sameNote(before, after)) continue;
    if (!sameNote(current, before) && !sameNote(current, after))
      throw new NoteConflict();
    if (after) merged.set(id, after);
    else merged.delete(id);
  }
  return [...merged.values()];
}
export function persistNotes(notes: Note[], base?: Note[]): Note[] {
  const ordinary = notes.filter((n) => !n.volatile);
  const saved =
    base && localStorage.getItem(STORAGE) !== null
      ? mergeOrdinaryNotes(base, ordinary, loadNotes())
      : ordinary;
  localStorage.setItem(
    STORAGE,
    JSON.stringify(
      saved.map(({ id, text, pinned, updated, deleted }) => ({
        id,
        text,
        pinned,
        updated,
        ...(deleted ? { deleted } : {}),
      })),
    ),
  );
  return saved;
}
export function title(n: Note) {
  return n.text.split("\n")[0]?.trim() || "Nueva nota";
}
export function excerpt(n: Note) {
  return n.text.split("\n").slice(1).join(" ").trim() || "Sin texto adicional";
}

const calendar = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Andorra",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
const timeFormatter = new Intl.DateTimeFormat("es", {
  timeZone: "Europe/Andorra",
  hour: "2-digit",
  minute: "2-digit",
});
const weekdayFormatter = new Intl.DateTimeFormat("es", {
  timeZone: "Europe/Andorra",
  weekday: "long",
});
const dateFormatter = new Intl.DateTimeFormat("es", {
  timeZone: "Europe/Andorra",
  day: "numeric",
  month: "numeric",
  year: "2-digit",
});
function dayIndex(time: number) {
  const parts = calendar.formatToParts(time);
  const v = (k: string) => Number(parts.find((p) => p.type === k)?.value);
  return Math.floor(Date.UTC(v("year"), v("month") - 1, v("day")) / 86400000);
}
export function groups(notes: Note[], now = Date.now()) {
  const labels = [
    "Fijadas",
    "Hoy",
    "Ayer",
    "Últimos 7 días",
    "Últimos 30 días",
    "Anteriores",
  ];
  const map = new Map(labels.map((l) => [l, [] as Note[]]));
  const today = dayIndex(now);
  for (const note of [...notes]
    .filter((n) => !n.deleted)
    .sort((a, b) => b.updated - a.updated)) {
    const days = today - dayIndex(note.updated);
    const group = note.pinned
      ? "Fijadas"
      : days <= 0
        ? "Hoy"
        : days === 1
          ? "Ayer"
          : days < 7
            ? "Últimos 7 días"
            : days < 30
              ? "Últimos 30 días"
              : "Anteriores";
    map.get(group)!.push(note);
  }
  return [...map].filter(([, items]) => items.length);
}
export function dateLabel(time: number) {
  const days = dayIndex(Date.now()) - dayIndex(time);
  if (days === 0) return timeFormatter.format(time);
  if (days === 1) return "ayer";
  if (days < 7) return weekdayFormatter.format(time);
  return dateFormatter.format(time);
}
export function findNotes(notes: Note[], term: string) {
  const fold = (s: string) =>
    s
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase("es");
  const needle = fold(term);
  return notes.filter((n) => !n.deleted && fold(n.text).includes(needle));
}

export function deleteNote(
  notes: Note[],
  id: string,
  now = Date.now(),
): Note[] {
  const selected = notes.find((n) => n.id === id);
  if (!selected) return notes;
  const originalId = selected.sourceId ?? id;
  return notes.flatMap((n) => {
    if (n.volatile && (n.id === id || n.sourceId === originalId)) return [];
    if (n.id === originalId) return [{ ...n, deleted: now }];
    return [n];
  });
}
export function restoreNote(notes: Note[], id: string): Note[] {
  return notes.map((n) => {
    if (n.id !== id) return n;
    const restored = { ...n };
    delete restored.deleted;
    return restored;
  });
}
