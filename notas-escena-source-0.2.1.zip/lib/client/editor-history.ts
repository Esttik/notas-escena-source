export type Snapshot = { text: string; start: number; end: number };
/** Memory-only, per editor. Browser undo grouping varies between engines. */
export class EditorHistory<S extends Snapshot = Snapshot> {
  current: S;
  past: S[] = [];
  future: S[] = [];
  constructor(initial: S) {
    this.current = initial;
  }
  get depth() {
    return this.past.length;
  }
  get size() {
    return this.past.reduce((n, s) => n + s.text.length, 0);
  }
  record(next: S, previous?: S) {
    if (next.text === this.current.text) {
      this.current = next;
      return;
    }
    this.past.push(previous ?? this.current);
    this.future = [];
    this.current = next;
    while (this.past.length > 1 && (this.depth > 50 || this.size > 200000))
      this.past.shift();
  }
  undo() {
    const previous = this.past.pop();
    if (!previous) return null;
    this.future.push(this.current);
    this.current = previous;
    return previous;
  }
  redo() {
    const next = this.future.pop();
    if (!next) return null;
    this.past.push(this.current);
    this.current = next;
    return next;
  }
}
