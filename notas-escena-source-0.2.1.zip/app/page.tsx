import { requireChatGPTUser } from "./chatgpt-auth";
import { NotesApp } from "../components/NotesApp";
export const dynamic = "force-dynamic";
export default async function Home() {
  await requireChatGPTUser("/");
  return <NotesApp />;
}
