# Copia de código para lectura

Instantánea del proyecto Notas Escena 0.2.1, sin historial de Git, credenciales, sesión de Telegram, registros de participantes ni estado de ejecución.

Esta copia contiene el código de interfaz, servidor, puente, pruebas y documentación. Los identificadores de hosting y las rutas del equipo se sustituyen por ejemplos. Se omiten las dos capturas de auditoría. Las variables de entorno son ejemplos vacíos; la integración real necesita una configuración privada propia.

La autorización de participantes y la comprobación del titular se conservan sin cambios. Compartir esta copia no concede acceso a la aplicación publicada, Telegram, Netlify ni sus secretos.

Consulta README.md para arquitectura y ejecución. Esta copia pública no contiene el historial privado del desarrollo y no crea un despliegue de producción.
